/*Program to convert infix to postfix and evaluate it*/
#include<stdio.h>
#define MAX 20
#include<math.h>
struct stack
{
  int stk[10];
  int top;
};
 typedef struct stack ST;
 ST s1;
void create()
{
  int i;
  for(i=0;i<MAX;i++)
  s1.stk[i]=0;
  s1.top=-1;
  printf("\n Stack created");
}
int isfull()
{
  if(s1.top==MAX-1)
	return 1;
  else
	return 0;
}
int isempty()
{
  if(s1.top==-1)
	return 1;
  else
	return 0;
}
void push(char data)
{
  s1.top++;
  s1.stk[s1.top]=data;
}
char pop()
{
  char pop_data;
  pop_data=s1.stk[s1.top];
  s1.top--;
  return(pop_data);
}
int priority(char oprt)
{
  if(oprt=='^')
   return 3;
  else if((oprt=='*')||(oprt=='/')||(oprt=='%'))
   return 2;
  else if((oprt=='+')||(oprt=='-'))
   return 1;
  else
   return 0;
}
int operate(char symb,int op1,int op2)
{
  int op3;
  switch(symb)
  {
   case '+': op3=op1 + op2; break;
   case '-': op3=op1 - op2; break;
   case '*': op3=op1 * op2; break;
   case '/': op3=op1 / op2; break;
   case '^': op3= pow(op1,op2); break;
  }
   return op3;
}
int isdigit(char ch)
{
  if(ch>='0' && ch<='9')
	return 1;
  else
	return 0;
}
int isoper(char ch)
{
  if((ch=='+')||(ch=='-')||(ch=='/')||(ch=='^')||(ch=='*'))
	return 1;
  else
	return 0;
}
void disp()
{
  int i;
  for(i=0;i<=s1.top;i++)
  printf("%c",s1.stk[i]);
}
void postfx_eval(char *expr)
{
  int i,oprnd1,oprnd2,value,ans;
  for(i=0;expr[i]!='\0';i++)
  {
   if(isdigit(expr[i])==1)
	 push((int)expr[i]-48);
   else
	{
	  oprnd2=pop();
	  oprnd1=pop();
	  value=operate(expr[i],oprnd1,oprnd2);
	  push(value);
	}
  }
  ans=pop();
  printf("\n\n Answer is:%d",ans);
}
int disp_top()
{
  return(s1.stk[s1.top]);
}
void infx_pstfx(char *expr)
{
  ST opstk;
  char symb,topsymb,pst_str[MAX]="";
  int i,j;
  j=0;
  create();
  printf("\t Symb \t\tPost String\t");
  for(i=0;expr[i]!='\0';i++)
  {
	symb=expr[i];
	if(isoper(symb))
	{
	  while(!isempty()&&priority(disp_top()>=priority(symb)))
		 pst_str[j++]=pop();
	  push(symb);
	}
	else if(symb==')')
	{
	 topsymb=pop();
	 while(topsymb!='(')
	  {
		   pst_str[j++]=topsymb;
		   topsymb=pop();
	  }
	}
	 else if(symb=='(')
	   push(symb);
	 else
	   pst_str[j++]=symb;
	   pst_str[j]='\0';
	   printf("\n\t%c\t\t%s\t",symb,pst_str);
	   disp();
  }
	while(!isempty())
	{
	 pst_str[j++]=pop();
	 printf("\n\t%c\t\t%s\t",symb,pst_str);
	 disp();
	}
	 pst_str[j]='\0';
	 postfx_eval(pst_str);
}
main()
{
  char Expr[10];
  ST s;
  printf("\n\n Enter the Infix Expression :");
  scanf("%s",Expr);
  infx_pstfx(Expr);

}
/************** OUTPUT ************


 Enter the Infix Expression :3+(2^2)*4/4

 Stack created        Symb           Post String
		3               3
		+               3              	+
		(               3              	+(
		2               32             	+(
		^               32      		+(^
		2               322     		+(^
		)               322^    		+
		*               322^    		+*
		4               322^4   		+*
		/               322^4   		+*/
		4               322^44  		+*/
		4               322^44/         +*
		4               322^44/*        +
		4               322^44/*+

 Answer is:7
************************************************/
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                

