/* A program for static  dequeue (using an array) */
#include<stdlib.h>
#include<stdio.h>
#define MAX 10

typedef struct Q
{
	int R,F;
	int data[MAX];
}Q;

void initialise(Q *P);
int empty(Q *P);
int full(Q *P);
void enqueueF(Q *P,int x);//insert at front
void enqueueR(Q *p,int x);//insert at rear
int dequeueF(Q *P);//Delete the front element and return the same
int dequeueR(Q *P);//Delete the rear element and return the same
void print(Q *P);
int main()
{
	Q q;
	int op,x;
	initialise(&q);
	do
	   {
		printf("\n\n1)Insert(Rear)\n2)Insert(Front)\n3)Delete(Front)");
		printf("\n4)Delete(Rear)\n5)Print\n6)Quit");
		printf("\nEnter Your Choice:");
		scanf("%d",&op);
		switch(op)
		   {
			case 1: printf("\n Enter a value:");
				scanf("%d",&x);
				if(!full(&q))
					enqueueR(&q,x);
				else
					printf("\nQueue is full !!!!");
				break;
			case 2: printf("\n Enter a value:");
				scanf("%d",&x);
				if(!full(&q))
					enqueueF(&q,x);
				else
					printf("\nQueue is full !!!!");
				break;
			case 3: if(!empty(&q))
				   {
					x=dequeueF(&q);
					printf("\nDeleted Data=%d",x);
				   }
				else
				printf("\nQueue is empty !!!!");
				break;
			case 4: if(!empty(&q))
				   {
					x=dequeueR(&q);
					printf("\nDeleted Data=%d",x);
				   }
				else
				printf("\nQueue is empty !!!!");
				break;
			case 5: print(&q);break;
		   }
      }while(op!=6);
}

void initialise(Q *P)
{
	P->R=-1;
	P->F=-1;
}

int empty(Q *P)
{
	if(P->R==-1)
		return(1);
	return(0);
}

int full(Q *P)
{
	if((P->R+1)%MAX==P->F)
		return(1);
	return(0);
}

void enqueueR(Q *P,int x)
{
	if(P->R==-1)
	{
		P->R=P->F=0;
		P->data[P->R]=x;
	}
	else
	{
		P->R=(P->R+1)%MAX;
		P->data[P->R]=x;
	}
}
void enqueueF(Q *P,int x)
{
	if(P->R==-1)
	{
		P->R=P->F=0;
		P->data[P->F]=x;
	}
	else
	{
		P->F=(P->F - 1 + MAX)%MAX;
		P->data[P->F]=x;
	}
}

int dequeueF(Q *P)
{
	int x;
	x=P->data[P->F];
	if(P->R==P->F)//last data
	{
		P->R=-1;
		P->F=-1;
	}
	else
		P->F=(P->F+1)%MAX;
	return(x);
}
int dequeueR(Q *P)
{
	int x;
	x=P->data[P->R];
	if(P->R==P->F)//last data
	{
		P->R=-1;
		P->F=-1;
	}
	else
		P->R=(P->R - 1 + MAX)%MAX;
	return(x);
}

void print(Q *P)
{
	int i;
	if(!empty(P))
	{
		printf("\n");
		for(i=P->F;i!=P->R;i=(i+1)%MAX)
			printf("%d\t",P->data[i]);
		printf("%d\t",P->data[i]);
	}
}
