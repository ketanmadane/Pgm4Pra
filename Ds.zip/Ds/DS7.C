/*NAME:Chaitanya S.D.
CLASS:SYBCS
ROLL:s6920 */

/* program to implement for singly circular linked list */

#include<stdio.h>
#include<string.h>
struct node
{
	int data[20];
	struct node *next;
};
typedef struct node NODE;
NODE *create();
NODE *findlast(NODE *);
main()
{
	int ch,pos;
	int val[15];
	NODE *first;
	void display(NODE *);
	void insertval(NODE *,int[]);
	NODE * insertpos(NODE *,int);
	NODE * deleteval(NODE *,int[]);
	NODE * getnode();
	NODE * deletepos(NODE *,int);
	do
	{
	   printf("\nMenu");
	   printf("\n1.Createlist");
	   printf("\n2.Insert by value");
	   printf("\n3.Insert by position");
	   printf("\n4.Delete by value");
	   printf("\n5.Delete by position");
	   printf("\n6.Displaylist");
	   printf("\n7.Exit");
	   printf("\nEnter choice:");
	   scanf("%d",&ch);
	   switch(ch)
	   {
		case 1:
		first=create();
		display(first);
		break;
		case 2:
		printf("\nEnter the element after which you want to insert node:");
		scanf("%d",val);
		insertval(first,val);
		display(first);
		break;
		case 3:
		printf("\nEnter the position at which you want to insert node:");
		scanf("%d",&pos);
		first=insertpos(first,pos);
		display(first);
		break;
		case 4:
		printf("\nEnter the element the node of which you want to delete:");
		scanf("%d",val);
		first=deleteval(first,val);
		display(first);
		break;
		case 5:
		printf("\nEnter the position of node you want to delete:");
		scanf("%d",&pos);
		first=deletepos(first,pos);
		display(first);
		break;
		case 6:
		display(first);
		break;
		case 7:
		exit(0);
	   }
	}while(ch!=7);
}
NODE * getnode()
{
		NODE *temp;
		int ch;
		temp=(NODE *)malloc(sizeof(NODE));
		printf("\nEnter the element:");
	  scanf("%d",temp->data);
		temp->next=NULL;
		return(temp);
}
void display(NODE *h)
{
		NODE *ptr=h;
	  do
	  {
		 if(ptr==NULL)
		 {
		  printf("Linked list does not exist");
		  break;
		 }
		 printf("%d\t",ptr->data);
		 ptr=ptr->next;
	  }while(ptr!=h);
}
NODE * create()
{
		int i,n;
		NODE *ptr,*temp,*h=NULL;
		printf("How many nodes:");
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
		   temp=getnode();
		   if(h==NULL)
	   {
				h=temp;
		h->next=h;
	   }
		   else
		   {
				 ptr=findlast(h);
				 ptr->next=temp;
		 temp->next=h;
		   }
		}
		return(h);
}
NODE * findlast(NODE *h)
{
	NODE *temp;
	for(temp=h;temp->next!=h;temp=temp->next);
	   return(temp);
}
void insertval(NODE *h,int val[])
{
	NODE *ptr=h,*temp;
	int flag=0,a;
	do
	{
	  if(ptr->data==val);
	   {
		temp=getnode();
		temp->next=ptr->next;
		ptr->next=temp;
		flag=1;
		break;
	   }
	   ptr=ptr->next;
	}while(ptr!=h);
	if(ptr==h&&flag==0)
	   printf("Value not found\n");
}
NODE * insertpos(NODE *h,int pos)
{
	NODE *temp,*ptr=h;
	int i=2;
	if(h==NULL)
	{
	   temp=getnode();
	   h=temp;
	   temp->next=h;
	}
	if(pos==1&&h!=NULL)
	{
	   temp=getnode();
	   temp->next=h;
	   ptr=findlast(h);
	   h=temp;
	   ptr->next=h;
	}
	else
	{
	  do
	  {
		if(pos==i)
		{
		   temp=getnode();
		   temp->next=ptr->next;
		   ptr->next=temp;
		   break;
		}
		i++;
		ptr=ptr->next;
	  }while(ptr!=h);
	   if(ptr==h)
	   printf("Position not found\n");
	}
	return(h);
}
NODE * deleteval(NODE *h,int val[])
{
	NODE *prev=h,*ptr=h;
   	if(ptr->data==val);
	
	{
	   ptr=findlast(h);
	   h=h->next;
	   ptr->next=h;
	   free(prev);
	}
	else
	{
	   do
	   {
	  	if(ptr->data==val);
		
		{
		   prev->next=ptr->next;
		   free(ptr);
		   break;
		}
		prev=ptr;
		ptr=ptr->next;
	   }while(ptr!=h);
	   if(ptr==h)
		  printf("Value not found\n");
	}
	return(h);
}
NODE * deletepos(NODE *h,int pos)
{
	int i=1;
	NODE *prev=h,*ptr=h;
	if(pos==1)
	{
	   ptr=findlast(h);
	   h=h->next;
	   ptr->next=h;
	   free(prev);
	}
	else
	{
	   do
	   {
		if(pos==i)
		{
		   prev->next=ptr->next;
		   free(ptr);
		   break;
		}
		i++;
		prev=ptr;
		ptr=ptr->next;
	   }while(ptr!=h);
	   if(ptr==h)
		  printf("Position not found\n");
	}
	return(h);
}

/************************* OUTPUT ************************
Menu
1.Createlist
2.Insert by value
3.Insert by position
4.Delete by value
5.Delete by position
6.Displaylist
7.Exit
Enter choice:1
How many nodes:7

Enter the element:10

Enter the element:20

Enter the element:30
 
Enter the element:40
 
Enter the element:50
 
Enter the element:60
 
Enter the element:70
10	20	30	40	50	60	70
Menu
1.Createlist
2.Insert by value
3.Insert by position
4.Delete by value
5.Delete by position
6.Displaylist
7.Exit
Enter choice:2
 
Enter the element after which you want to insert node:40
 
Enter the element:45
10	20	30	40	45	50	60	70
Menu
1.Createlist
2.Insert by value
3.Insert by position
4.Delete by value
5.Delete by position
6.Displaylist
7.Exit
Enter choice:3
 
Enter the position at which you want to insert node:1
 
Enter the element:5
5	10	20	30	40	45	50	60	70
Menu
1.Createlist
2.Insert by value
3.Insert by position
4.Delete by value
5.Delete by position
6.Displaylist
7.Exit
Enter choice:4
 
Enter the element the node of which you want to delete:30
5	10	20	40	45	50	60	70    
Menu
1.Createlist
2.Insert by value
3.Insert by position
4.Delete by value
5.Delete by position
6.Displaylist
7.Exit
Enter choice:5
 
Enter the position of node you want to delete:5
5	10	20	30	40	45	60	70
Menu
1.Createlist
2.Insert by value
3.Insert by position
4.Delete by value
5.Delete by position
6.Displaylist
7.Exit
Enter choice:6
5	10	20	30	40	45	60	70
Menu
1.Createlist
2.Insert by value
3.Insert by position
4.Delete by value
5.Delete by position
6.Displaylist
7.Exit
Enter choice:7                                                      
****************************************************************/




































