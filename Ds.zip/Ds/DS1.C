/*WRITE PROGRAM TO SORT N NUMBER USING QUICK SORT METHOD*/

#include<stdio.h>
#include<conio.h>
int n, i = 1;
int swco=0,stco=0,comco=0;
void display (int a[])
{
  int i;
  printf ("\n");
  for (i = 0; i < n; i++)
  printf ("\t%d", a[i]);
}
int partition (int a[], int lb, int ub)
{
  int up, down, temp, pivot;
 
  up =ub;
  stco++;
  down = lb + 1;
  stco++;
  pivot = a[lb];
  stco++;
  do
  {
    stco++;
    while ((a[down] <pivot) && (down <= ub))
    {
       stco++;
       down++;
       stco++;
    }
    stco++;
    while ((a[up] > pivot) && (up > lb))
    {
       stco++;
       up--;
       stco++;
    }
    stco++;
    comco++;
    stco++;
    if (down < up)
    {
       stco++;
       comco++;
       stco++;
       swco++;
       stco++;
       temp = a[down];
       stco++;
       a[down] = a[up];
       stco++;
       a[up] = temp;
       stco++;
     }
     stco++;
     display (a);
  }while (down < up);
    swco++;
    stco++;
    a[lb] = a[up];
    stco++;
    a[up] = pivot;
    stco++;
    display (a);
    stco++;
    return (up);
   }
int quicksort (int a[], int lb, int ub)
{
   int j;

   if (lb < ub)
   {
     comco++;
     stco++;
     printf ("\nIteration %d\n", i);
     display (a);
     i++;
     stco++;
     j = partition (a, lb, ub);
     stco++;
     quicksort (a, lb, j - 1);
     stco++;
     quicksort (a, j + 1, ub);
     stco++;
   }
   stco++;
}
void main ()
{
   int a[20],i;
   clrscr();
   printf ("\nEnter number of elements: ");
   scanf ("%d", &n);
   printf ("\nEnter the unsorted numbers: ");
   for (i = 0; i < n; i++)
   scanf ("%d", &a[i]);
   quicksort (a, 0, n - 1);
   printf ("\nThe sorted list: ");
   display (a);
   printf("\n The total cmparisons = %d",comco);
   printf("\n The  total swap count =%d",swco);
   printf("\n The  total step count = %d",stco++);
   
}
/*************************OUTPUT********************

Enter number of elements: 5

Enter the unsorted numbers: 1 90 6 8 3

Iteration 1

	1       90      6       8       3
	1       90      6       8       3
	1       90      6       8       3
Iteration 2

	1       90      6       8       3
	1       90      6       8       3
	1       3       6       8       90
Iteration 3

	1       3       6       8       90
	1       3       6       8       90
	1       3       6       8       90
Iteration 4

	1       3       6       8       90
	1       3       6       8       90
	1       3       6       8       90
The sorted list:
	1       3       6       8       90
 The total cmparisons = 8
 The  total swap count =4
 The  total step count = 97
 ********************************************************************/

