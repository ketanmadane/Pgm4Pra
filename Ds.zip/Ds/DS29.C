Name:Chaitanya D.
CLASS:SYBCS
ROLL:s6920
Program:Menu driven program for union,intersection and
	difference of two linklist*/

#include<stdio.h>
#include<conio.h>
struct node
{
		int data;
		struct node *next;
};
typedef struct node NODE;

//create a node
NODE* getnode()
  {
		NODE *temp;
	int data;
        temp=(NODE *)malloc(sizeof(NODE));
		printf("Enter the data->");
		scanf("%d",&data);
	temp->data=data;
		temp->next=NULL;
		return(temp);
  }
//for finding address of a last node
NODE* findlast(NODE *list1)
  {
		NODE* ptr;
		for(ptr=list1;ptr->next!=NULL;ptr=ptr->next);
		return(ptr);
  }
//To display a nodes
void display(NODE *list1)
  {
		NODE *ptr;
	for(ptr=list1;ptr!=NULL;ptr=ptr->next)
		{
		  printf("%d ",ptr->data);
		}
		  printf("\n");
  }
//function for getnodedata
NODE *getnodedata(int data)
  {
	NODE *temp;
	temp=(NODE *)malloc(sizeof(NODE));
	temp->data=data;
	temp->next=NULL;
	return(temp);
  }
//To create a list
NODE * create(NODE *list1)
  {
		NODE *temp,*ptr;
		int i,n;
		printf("\nEnter the number of elements in the list:");
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
		   temp=getnode();
		   if(list1==NULL)
			  list1=temp;
		   else
		   {
			 ptr=findlast(list1);
			 ptr->next=temp;
		   }
		}
			return(list1);
  }

//Union of two link list
NODE *Union(NODE *list1,NODE *list2)
{
	NODE *ptr1,*ptr2,*ptr3,*temp,*list3=NULL;
	for(ptr1=list1;ptr1!=NULL;ptr1=ptr1->next)
	 {
	   temp=getnodedata(ptr1->data);
	   if(list3==NULL)
			 list3=temp;
	   else
			{
		 ptr3=findlast(list3);
		 ptr3->next=temp;
		}
		 }
	for(ptr2=list2;ptr2!=NULL;ptr2=ptr2->next)
		  {
		   if(list1!=NULL)
			{
		   for(ptr1=list1;ptr1!=NULL;ptr1=ptr1->next)
			 {
			   if(ptr2->data==ptr1->data)
				 break;
			 }
			   if(ptr1==NULL)
				 {
				  temp=getnodedata(ptr2->data);
				  if(list3==NULL)
					 list3=temp;
				   else
					 {
					   ptr3=findlast(list3);
					   ptr3->next=temp;
					 }
				  }
		   }
				   else
					   for(ptr2=list2;ptr2!=NULL;ptr2=ptr2->next)
						{
						 temp=getnodedata(ptr2->data);
						 if(list3==NULL)
							list3=temp;
						 else
							{
							 ptr3=findlast(list3);
							 ptr3->next=temp;
							}
						  }
		   }return(list3);
	  }
//Intersection of two linklist
NODE *intersection(NODE*list1,NODE*list2)
   {
	NODE*ptr1,*ptr2,*ptr3,*temp,*list3=NULL;
	for(ptr1=list1;ptr1!=NULL;ptr1=ptr1->next)
		  {
		   for(ptr2=list2;ptr2!=NULL;ptr2=ptr2->next)
			{
		   if(ptr1->data==ptr2->data)
			{
				 temp=getnodedata(ptr1->data);
				 if(list3==NULL)
					list3=temp;
				 else
				   {
					 ptr3=findlast(list3);
					 ptr3->next=temp;
				   }
				 }
			 }
		  }return(list3);
   }
//Difference of two link list
NODE *difference(NODE*list1,NODE*list2)
   {
		NODE *ptr1,*ptr2,*ptr3,*temp,*list3=NULL;
		for(ptr1=list1;ptr1!=NULL;ptr1=ptr1->next)
		  {
		   for(ptr2=list2;ptr2!=NULL&&ptr1->data!=ptr2->data;ptr2=ptr2->next);
		{
			 if(ptr2==NULL)
			 {
			   temp=getnodedata(ptr1->data);
				   if(list3==NULL)
					  list3=temp;
				   else
					  {
					   ptr3=findlast(list3);
					   ptr3->next=temp;
					  }
				  }
		 }
		}return(list3);
   }
main()
{
	NODE *list1=NULL,*list2=NULL,*list3=NULL;
	int n,i,ch;
	do
	{
	  printf("**********MENU********");
	  printf("\n 1:create a list:");
	  printf("\n 2:Union of two list:");
	  printf("\n 3:intersection of two list:");
	  printf("\n 4:difference of two list:");
	  printf("\n 5:Exit:");
	  printf("\nEnter your choice:");
	  scanf("%d",&ch);
	  switch(ch)
	  {
	 case 1:
			printf("\n create first linklist:");
			list1=create(list1);
		display(list1);
		printf("\n create second linklist:");
		list2=create(list2);
		display(list2);
		break;
	 case 2:
			printf("\n The union of two linklist is:");
			list3=Union(list1,list2);
			display(list3);
			break;
	 case 3:
		printf("\n The intersection of two linklist is:");
		list3=intersection(list1,list2);
			display(list3);
			break;
	 case 4:
		printf("\n The difference of two linklist is:");
		list3=difference(list1,list2);
		display(list3);
		break;
	 case 5:
			exit(0);
			break;
	  }
	}while(ch!=5);
}
/******************************OUTPUT***************************
**********MENU********
 1:create a list:
 2:Union of two list:
 3:intersection of two list:
 4:difference of two list:
 5:Exit:
Enter your choice:1
 
 create first linklist:
Enter the number of elements in the list:5
Enter the data->5
Enter the data->6
Enter the data->2
Enter the data->4
Enter the data->8
5 6 2 4 8

 create second linklist:
Enter the number of elements in the list:3
Enter the data->2
Enter the data->7
Enter the data->6
2 7 6
**********MENU********
 1:create a list:
 2:Union of two list:
 3:intersection of two list:
 4:difference of two list:
 5:Exit:
Enter your choice:2

 The union of two linklist is:5 6 2 4 8 7
**********MENU********
 1:create a list:
 2:Union of two list:
 3:intersection of two list:
 4:difference of two list:
 5:Exit:
Enter your choice:3

 The intersection of two linklist is:6 2
**********MENU********
 1:create a list:
 2:Union of two list:
 3:intersection of two list:
 4:difference of two list:
 5:Exit:
Enter your choice:4

 The difference of two linklist is:5 4 8
**********MENU********
 1:create a list:
 2:Union of two list:
 3:intersection of two list:
 4:difference of two list:
 5:Exit:
Enter your choice:5
******************************************************************/



