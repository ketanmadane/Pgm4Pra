/*
NAME:Chaitanya Deshpande
CLASS:SYBCS
ROLL:S6920
Program to impliment singly list list of array
*/
#include<stdio.h>
#define MAX 20
int arr[MAX];
int n;


void create()
{
  int i;
  for(i=0;i<n;i++)
  {
	printf("\n Enter the value for element %d :",i+1);
	scanf("%d",&arr[i]);
  }
}
int search(int item)
{
  int i;
  for(i=0;i<n;i++)
  {
	if(item==arr[i])
	 return(i+1);
  }
  return(0);
}
void insert()
{
  int temp,item,position;
  if(n==MAX)
  {
	printf("List overflow");
	return;
  }
  printf("\n Enter position for insertion :");
  scanf("%d",&position);
  printf("\n Enter the value:");
  scanf("%d",&item);
  if(position>n+1)
  {
   printf("Enter the position less than or equal to%d",n+1);
   return;
   }
   if(position==n+1)
   {
	arr[n]=item;
	n=n+1;
	return;
   }
   temp=n-1;
   while(temp>=position-1)
   {
	arr[temp+1]=arr[temp];
	temp--;
   }
   arr[position-1]=item;
   n=n+1;
 }
void del()
{
 int temp,position,item;
 if(n==0)
 {
   printf("list underflow");
   return;
 }
 printf("\n Enter the element to be deleted:");
 scanf("%d",&item);
 if(item==arr[n-1])
 {
   n=n-1;
   return;
 }
 position=search(item);
 if(position==0)
 {
   printf("\n element not present in array");
   return;
 }
 temp=position-1;
 while(temp<=n-1)
 {
  arr[temp]=arr[temp+1];
  temp++;
 }
 n=n-1;
}
void display()
{
 int i;
 if(n==0)
 {
  printf("list is empty");
  return;
 }
 for(i=0;i<n;i++)
  printf("\n Value at position %d : %d",i+1,arr[i]);
 }
 main()
{
 int ch,item,pos;
 while(1)
 {
   printf("\n 1:create list");
   printf("\n 2:Insert");
   printf("\n 3:search");
   printf("\n 4:delete");
   printf("\n 5:display");
   printf("\n 6:Exit");
   printf("\n Enter your choice :");
   scanf("%d",&ch);
   switch(ch)
   {
	case 1:
			printf("\n Enter the number of element  :");
			scanf("%d",&n);
		   create(n);
			break;
	case 2:
			insert();
			break;
	case 3:
			printf("\n Enter the number of element to be search :");
			scanf("%d",&item);
			pos=search(item);
			if(pos>=1)
			 printf("\n %d Element found at %d position ",item,pos);
			else
			 printf("\n Element does not found");
			break;
	case 4:
			del();
			printf("\n Element is deleted");
			break;
	case 5:
			display();
			break;
	case 6:
			exit(0);
   }
}

}

/********************** OUTPUT ********************
 Value at position 2 : 1
 Value at position 3 : 2                                                        
 Value at position 4 : 3                                                        
 Value at position 5 : 4                                                        
 Value at position 6 : 7                                                        
 Value at position 7 : 5                                                        
 1:create list                                                                  
 2:Insert                                                                       
 3:search                                                                       
 4:delete                                                                       
 5:display                                                                      
 6:Exit
 Enter your choice :3

 Enter the number of element to be search :3

 3 Element found at 4 position
 1:create list
 2:Insert
 3:search
 4:delete
 5:display
 6:Exit
 Enter your choice :4

 Enter the element to be deleted:7

 Element is deleted
 1:create list
 2:Insert
 3:search
 4:delete
 5:display
 6:Exit
 Enter your choice :5

 Value at position 1 : 6
 Value at position 2 : 1
 Value at position 3 : 2
 Value at position 4 : 3
 Value at position 5 : 4
 Value at position 6 : 5
 1:create list
 2:Insert
 3:search
 4:delete
 5:display
 6:Exit
 Enter your choice :6
******************************************/

