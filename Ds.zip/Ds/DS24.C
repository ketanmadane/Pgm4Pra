/*LINEAR SEARCH  for cities*/

#include <stdio.h>
#include<string.h>

int stepcount=0,swapcount=0,compcount=0;


int linsearch(char a[][30],int n , char key[30]);
int main()
 {
   int n,i,result;
   char a[30][30],key[30];
  printf("\n Enter No. of cities : ");
  scanf("%d" ,&n);
  printf("\n Enter a  list of %d cities : ",n);
  for(i=0;i<n;i++)
	scanf("%s",a[i]);
  printf("\n Enter the city to be searched :");
  scanf("%s",key);
  result=linsearch(a,n,key);
  if(result==-1)
	printf("\n Not found. ");
  else
	printf("\n Found at location= %d",result);
  printf("\n No. of steps= %d",stepcount);
  printf("\n No. of swaps= %d", swapcount);
  printf("\n No. of comparisons= %d",compcount);
 }

int linsearch(char a[][30],int n , char key[30])
{
    int i;
    for(i=0;i<n;i++)
      {
		compcount++;
		stepcount+=2;
		if(strcmpi(a[i],key)==0)
			{
				stepcount++;
				return(i+1);
			}
      }

   return(-1);
}

