/*
NAME :Chaitanya Deshpande
CLASS:SYBCS
ROLL:s6920
Program to reverse string using stack*/
#include<stdio.h>
#define MAX 20
#include"stack.h"
main()
{
	char str[25];
	int i;
	create(&s1);
	printf("\nEnter the string:");
	gets(str);
	for(i=0;str[i]!='\0';i++)
	{
	   if(str[i]==' ')
	   {
		while(!isempty(&s1))
		{
		   printf("%c",pop(&s1));
		}
		printf(" ");
	   }
	   else
	   {
		if(isfull(&s1)!=1)
		   push(str[i],&s1);
	   }
	}
	while(isempty(&s1)==0)
	   printf("%c",pop(&s1));
}
/***********************Output*************************

Enter the string:this is college
siht si egelloc
*******************************************************/









                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                
                                                                                








