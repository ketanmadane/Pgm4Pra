/*WRITE PROGRAM TO SORT N NUMBER USING INSERTION SORT METHOD*/
#include<stdio.h>
void dis (int[], int);
void isort (int[], int);
main ()
{
  int i, n, a[10];
  printf ("Enter how many element which you want to sort ");
  scanf ("%d", &n);
  printf ("Enter the element ");
  for (i = 0; i < n; i++)
    {
      scanf ("%d", &a[i]);
    }
  isort (a, n);
  dis (a, n);
 
}

void dis (int a[10], int n)
{
  int i;

  printf ("\nThe sorted elements are :");
  for (i = 0; i < n; i++)
    printf ("\t\n%d", a[i]);
}
void isort (int a[10], int n)
{
  int i, newele, j, st_co = 0, swco = 0, comco = 0;
  st_co++;
  for (i = 1; i < n; i++)
    {
      st_co++;
      printf ("\n Pass  = %d", i);
      newele = a[i];
      st_co++;
      for (j = i - 1; j >= 0 && newele < a[j]; j--,comco++)
	{
	  a[j + 1] = a[j];
	  st_co++;
	  swco++;
	  st_co++;
	}
      st_co++;
      a[j + 1] = newele;
      st_co++;
    }
  st_co++;
  printf ("\n Comparision count is = %d ", comco);
  printf ("\n Swap count is = %d", swco);
  printf (" \n Step count is = %d", st_co);
}


/******************** OUTPUT *******************
Enter how many element which you want to sort 6
Enter the element 12 7 9 0 34 3

 Pass  = 1
 Pass  = 2
 Pass  = 3
 Pass  = 4
 Pass  = 5
 Comparision count is = 9
 Swap count is = 9
 Step count is = 40
The sorted elements are :
0
3
7
9
12
34
***********************************************/
