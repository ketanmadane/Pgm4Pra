/*WRITE PROGRAM TO SORT N NUMBER USING BUBBLE SORT METHOD*/

#include<stdio.h>
void bsort(int[], int);
void dis(int[], int);
main ()
{
  int i,n,a[10];
  printf("Enter how many element which you want to sort ");
  scanf("%d", &n);
  printf ("Enter the element ");
  for (i = 0; i < n; i++)
    {
      scanf ("%d",&a[i]);
    }
  bsort (a, n);
  dis (a, n);
  
}

void dis (int a[10], int n)
{
  int i;

    printf("The sorted elements are :");
    for(i=0;i<n;i++)
    printf ("\t\n%d", a[i]);
}

void bsort (int a[10], int n)
{
  int i, com_co = 0, swap_co = 0, st_co = 0, temp = 0,pass;
   st_co++;
   for (pass = 1; pass < n; pass++)
    {
      printf ("\n Pass =  %d", pass);
      st_co++;

      for (i = 0; i < n - pass; i++)
	{
	  com_co++;
	  st_co++;
	  if (a[i] > a[i + 1])
	    {
	      swap_co++;
	      st_co++;
	      temp = a[i];
	      st_co++;
	      a[i] = a[i + 1];
	      st_co++;
	      a[i + 1] = temp;
	      st_co++;
	    }
	    st_co++;
}
	st_co++;
    }
    st_co++;

  printf ("\n Comparision count is = %d ", com_co);
  printf ("\n Swap count is = %d", swap_co);
  printf (" \n Step count is = %d", st_co);
}
/********************* OUTPUT ***********************************************
Enter how many element which you want to sort 5
Enter the element 24 56 1 5 99

 Pass =  1
 Pass =  2
 Pass =  3
 Pass =  4
 Comparision count is = 10
 Swap count is = 4
 Step count is = 46
 The sorted elements are :
1
5
24
56
99
************************************************************************/
