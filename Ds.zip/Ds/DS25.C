/* A program for static ascending priority queue of integers */
#include<stdlib.h>
#include<stdio.h>
#define MAX 5

typedef struct Q
{
	int R,F;
	int data[MAX];
}Q;

void initialise(Q *P);
int empty(Q *P);
int full(Q *P);
void enqueue(Q *P,int x);
int  dequeue(Q *P);
void print(Q *P);
int main()
{	Q q;
       int op;
       int x;
     initialise(&q);
        do{
	printf("\n\n1)Insert\n2)Delete\n3)Print\n4)Quit");
	printf("\nEnter Your Choice:");
	scanf("%d",&op);
	switch(op)
	 { case 1: printf("\n Enter a number:");
		   scanf("%d",&x);
		   if(!full(&q))
			enqueue(&q,x);

		   else
			printf("\nQueue is full !!!!");
		   break;
	   case 2:if(!empty(&q))
		    {
			x=dequeue(&q);
			printf("\nDeleted Data=%d",x);
		    }
		   else
			printf("\nQueue is empty !!!!");
		   break;
	   case 3: print(&q);break;
	}
      }while(op!=4);
}

void initialise(Q *P)
{
	int i;
	P->R=-1;
	P->F=-1;
}

int empty(Q *P)
{
	if(P->R==-1)
		return(1);
	return(0);
}

int full(Q *P)
{       int places,i;
	if(P->R==MAX-1)
	  {
		places=P->F;
		if(places > 0)  //shift the queue
		    {
			for(i=P->F;i<=P->R;i++)
				P->data[i-places]=P->data[i];
			P->F=0;
			P->R=P->R-places;
			for(i=P->R+1;i<MAX;i++)
				P->data[i]=NULL;
		    }
	   }
	if(P->R==MAX-1)
		return(1);
	return(0);
}

void enqueue(Q *P,int x)
{       int i;

	if(P->R==-1)
	{
		P->R=P->F=0;
		P->data[P->R]=x;
	}
	else
	{
		for(i=P->R;i>=P->F && x<P->data[i];i--)
			P->data[i+1]=P->data[i];
		P->R=P->R+1;
		P->data[i+1]=x;
	}
}

int  dequeue(Q *P)
{
	int x;
	x=P->data[P->F];
	if(P->R==P->F)
	{
		P->R=-1;
		P->F=-1;
	}
	else
		P->F=P->F+1;
	return(x);
}

void print(Q *P)
{
	int i;
	if(!empty(P))
	{
		printf("\n");
		for(i=P->F ; i <= P->R ; i=i+1)
			printf("%d\t",P->data[i]);
	}
}
