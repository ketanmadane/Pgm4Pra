/*program to implement dynamic stack for palindrom*/
#include<stdio.h>
#include"stack.h"
void main()
{
   char string[MAX],str[MAX];
  int i,j=0;;
   top=NULL;
  printf("\nInput string: ");
  gets(string);

	for(i=0;string[i]!='\0';i++)
	 push(string[i]);
  while(!isempty())
	str[j++]=pop();
  str[j]='\0';
  if(strcmp(string,str))
	printf("\nstring is not palindrom");
  else
	printf("\nstring is palindrom");

}
/******** OUTPUT *******

Input string: madam

string is palindrom

Input string: xpress

string is not palindrom
**************************/
                                                                                
