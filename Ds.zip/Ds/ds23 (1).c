/* NAME: Chaitanya Deshpande
   CLASS:S.Y. B.C.S
   ROLL NO.  : 20 
WRITE PROGRAM TO ACCEPT N SORTED NUMBER & SEARCH GIVEN NUMBER USING BINARY SEARCH*/

#include <stdio.h>
main ()
{
  int arr[20], start, end, mid, n, i, item,stco=0,comco=0,swco=0;

  stco++;
  printf ("How many element you want to enter in the array : ");
  scanf ("%d", &n);
  for (i = 0; i < n; i++)
    {
      printf ("Enter the  element %d :", i + 1);
      scanf ("%d", &arr[i]);
    }

  printf ("Enter the element to be searched  :");
  scanf ("%d", &item);
  start = 0;
  stco++;
  end = n - 1;
  stco++;
  mid = (start + end) / 2;
  stco++;
  while (item != arr[mid] && start <= end)
    {
      stco++;
      if (item > arr[mid]){
	comco++;
	stco++;
	start = mid + 1;
	stco++;
     }
      else{
	end=mid - 1;
	stco++;
     }
     mid = (start + end) / 2;
     stco++;
    }
    stco++;
  if (item == arr[mid])
    printf ("%d found at posotion %d \n ", item, mid + 1);
  if (start > end)
    printf ("%d not found in array \n ", item);
   printf("The step count is : %d",stco);
   printf("The compa count is :%d",comco) ;
   printf("The swap count is :%d",swco);
  

}

/******************** OUTPUT *****************
How many element you want to enter in the array : 5
Enter the  element 1 :34
Enter the  element 2 :56
Enter the  element 3 :12
Enter the  element 4 :3
Enter the  element 5 :9
Enter the element to be searched  :12
12 found at posotion 3
 The step count is : 5
 The compa count is :0
 The swap count is :0
***************************************************/
