/*Program to add two polynomials*/
#include<stdio.h>
struct poly
{
	int coef,exp;
	struct poly *next;
};
typedef struct poly POLY;

POLY * getnode(int c,int e)
{
	POLY *temp;
	temp=(POLY *)malloc(sizeof(POLY));
	temp->coef=c;
	temp->exp=e;
	temp->next=NULL;
	return(temp);

}
POLY * findlast(POLY *h)
{
	POLY *ptr;
	for(ptr=h;ptr->next!=NULL;ptr=ptr->next);
	   return(ptr);
}
POLY * search(POLY *poly3,int e)
{
	POLY *ptr;
	for(ptr=poly3;ptr!=NULL&&ptr->exp!=e;ptr=ptr->next);
	   return(ptr);
}
POLY * create()
{
	POLY *h=NULL,*temp,*ptr;
	int i,n,c,e;
	printf("How many terms in polynomial : ");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	   printf("\n\n Enter the coefficient & exponent:");
	   scanf("%d %d",&c,&e);
	   temp=getnode(c,e);
	   if(h==NULL)
		h=temp;
	   else
	   {
		ptr=findlast(h);
		ptr->next=temp;
	   }
	}
	return(h);
}

void display(POLY *h)
{
	POLY *ptr;
	for(ptr=h;ptr!=NULL;ptr=ptr->next)
	   printf("%dx%d+ ",ptr->coef,ptr->exp);
	   printf("\b\b \n");
}


POLY * addpoly(POLY *poly1,POLY *poly2)
{
	POLY *poly3=NULL,*ptr1=poly1,*ptr2=poly2,*ptr3,*temp;
	while(ptr1!=NULL&&ptr2!=NULL)
	{
	   if(ptr1->exp==ptr2->exp)
	   {
		temp=getnode(ptr1->coef+ptr2->coef,ptr1->exp);
		ptr1=ptr1->next;
		ptr2=ptr2->next;
	   }
	   else
	   {
		if(ptr1->exp>ptr2->exp)
		{
		   temp=getnode(ptr1->coef,ptr1->exp);
		   ptr1=ptr1->next;
		}
		else
		{
		   temp=getnode(ptr2->coef,ptr2->exp);
		   ptr2=ptr2->next;
		}
	   }
	   if(poly3==NULL)
		poly3=temp;
	   else
	   {
		ptr3=findlast(poly3);
		ptr3->next=temp;
	   }
	}
	while(ptr1!=NULL)
	{
	   temp=getnode(ptr1->coef,ptr1->exp);
	   if(poly3==NULL)
		poly3=temp;
	   else
	   {
		ptr3=findlast(poly3);
		ptr3->next=temp;
	   }
	   ptr1=ptr1->next;
	}
	while(ptr2!=NULL)
		{
		   temp=getnode(ptr2->coef,ptr2->exp);
		   if(poly3==NULL)
				poly3=temp;
		   else
		   {
				ptr3=findlast(poly3);
				ptr3->next=temp;
		   }
		   ptr2=ptr2->next;
		}
	return(poly3);
}
main()
{

		POLY *poly1,*poly2,*poly3;
		poly1=create();
		poly2=create();
		printf("\n Polynomial 1 is as follows:");
		display(poly1);
		printf("\n Polynomial 2 is as follows:");
		display(poly2);
		poly3=addpoly(poly1,poly2);
		printf("\n The Addition of polynomials is:");
		display(poly3);

}
/****************** OUTPUT *******************
How many terms in polynomial : 3


 Enter the coefficient & exponent:3 2


 Enter the coefficient & exponent:2 1


 Enter the coefficient & exponent:5 0
How many terms in polynomial : 3


 Enter the coefficient & exponent:6 2


 Enter the coefficient & exponent:9 1


 Enter the coefficient & exponent:3 0

 Polynomial 1 is as follows:3x2+ 2x1+ 5x0

 Polynomial 2 is as follows:6x2+ 9x1+ 3x0

 The Addition of polynomials is:9x2+ 11x1+ 8x0
**********************************************/









