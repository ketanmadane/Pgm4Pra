/* NAME: Chaitanya Deshpande
   CLASS:S.Y. B.C.S
   ROLL NO.  : 20 
WRITE PROGRAM TO ACCEPT N NUMBER & SEARCH GIVEN NUMBER USING LINEAR SEARCH*/

#include<stdio.h>
main ()
{
  int a[10], n, i, item,swco=0,stco=0,comco=0;
  stco++;
  printf ("How many element do you want to enter in array : ");
  scanf ("%d", &n);
  for (i = 0; i < n; i++)
    {
      stco++;
      printf ("\n Enter element %d : ", i + 1);
      scanf ("%d",&a[i]);
    }
  printf ("Enter the element to be search :");
  scanf ("%d", &item);
  for (i = 0; i < n; i++)
    {
      if (item == a[i])
	{
	  comco++;
	  stco++;
	  printf ("%d found at position %d ", item, i + 1);
	  break;

	}
	stco++;
    }
    stco++;
  if (i == n)
    printf ("Item %d not in array \n", item);
    printf("\nThe step count is : %d",stco++);
    printf("\nThe comparision count is :%d",comco);

    printf("\nThe swap count is :%d",swco);
    
}


/************** OUTPUT **************************
 How many element do you want to enter in array : 5
 Enter element 1 : 23
 Enter element 2 : 56
 Enter element 3 : 78
 Enter element 4 : 12
 Enter element 5 : 9
Enter the element to be search :78
78 found at position 3
The step count is : 10
The comparision count is :1
The swap count is :0
***************************************************/
