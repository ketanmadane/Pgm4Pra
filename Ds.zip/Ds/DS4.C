/* NAME:Chaitanya Deshpande
CLASS:SYBCS
ROLL:s6920
WRITE PROGRAM TO SORT N NUMBER USING MERGE SORT METHOD*/ 


#include<stdio.h>
#include<conio.h>
int n;
int stco=0,swco=0,comco=0;
void display(int a[])
{
  int i;
  printf("\n  The sorted list is : ");
  for(i=0;i<n;i++)
    printf("\t%d",a[i]);
}
void merge(int a[],int low,int mid,int high)
{
  int i,j,k,b[20];
  
  i=low;
  stco++;
  j=mid+1;
  stco++;
  k=0;
  stco++;
  while ((i<=mid) && (j<=high))
  {
    stco++;
    if (a[i]<=a[j]){
	stco++;
	b[k++]=a[i++];
	stco++;
     }
    else
    {
	stco++;
	b[k++]=a[j++];
	stco++;
     }
}
  while (i<=mid){
	stco++;
	b[k++]=a[i++];
	stco++;
  }
  stco++;
  while (j<=high){
	stco++;
	b[k++]=a[j++];
	stco++;
  }
  stco++;
  for(j=low,k=0;j<=high;j++,k++){
	stco++;
	a[j]=b[k];
	stco++;
 }
 stco++;
}

void mergesort(int a[],int low,int high)
{

  int mid;
  
  if(low<high)
  {
    stco++;
    comco++;
    stco++;
    mid=(low+high)/2;
    stco++;
    mergesort(a,low,mid);
    stco++;
    mergesort(a,mid+1,high);
    stco++;
    merge(a,low,mid,high);
    stco++;
  }
    stco++;
}

main()
{
  int a[20],i;
  clrscr();
  printf("\n   How many numbers: ");
  scanf("%d",&n);
  printf("\n   Enetr the unsorted numbers: ");
  for(i=0;i<n;i++)
     scanf("%d",&a[i]);
  mergesort(a,0,n-1);
  display(a);
  printf("\n\n   The total cmparions  = %d",comco);
  printf("\n   The  total swap count  is =%d",swco);
  printf("\n   The  total step count is = %d",stco++);

}



/**********************************OUTPUT***********************************

   How many numbers: 5

   Enetr the unsorted numbers: 32 54 1 8 0

  The sorted list is :  0       1       8       32      54

   The total cmparions  = 4
   The  total swap count  is =0
   The  total step count is = 11
 *****************************************************************************/
