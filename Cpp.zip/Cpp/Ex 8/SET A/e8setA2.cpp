#include<iostream>

using namespace std;

int main()
{
char line[100];
int i,vcnt=0,ccnt=0,scount=0;

cout<<"Enter a line of string :: ";
cin.getline(line,150);
try
{
for(i=0;line[i]!='\0';++i)
    {
	if(line[i]=='a' || line[i]=='e' || line[i]=='i' || line[i]=='o' || line[i]=='u' || line[i]=='A' || line[i]=='E' || line[i]=='I' || line[i]=='O' || line[i]=='U')
            ++vcnt;
        else if((line[i]>='a'&& line[i]<='z') 
                 || (line[i]>='A'&& line[i]<='Z'))
            ++ccnt;
	else if(line[i]>='0'&&line[i]<='9')
	{
		throw "Digit is present in given sentence";
	}
	else if(line[i]==' '|| line[i]=='#'|| line[i]=='*'|| line[i]=='@'|| line[i]=='^')
	{
		throw "Special symbol is present in given sentence";
	}
    }
}
catch(const char *msg)
{
	cerr<<msg<<endl;
}

cout<<"\nVowels:   "<<vcnt;
cout<<"\nConsonents:  "<<ccnt;
}
