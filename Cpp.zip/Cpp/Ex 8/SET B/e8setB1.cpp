#include<iostream>
using namespace std;
int main()
{
int a,b,no;
cout<<"\nAccept values of a & b : ";
cin>>a>>b;
do{
	cout<<"\n\n\n*****Menu*****\n1.Addition\n2.Substraction\n3.Multiplication\n4.Division\n5.Exit\n6.Enter your choice :";
	cin>>no;
	switch(no)
	{
		case 1:	cout<<"Addition of  "<<a<<" & "<<b<<" is : "<<a+b;
			break;
		case 2:	cout<<"substraction of  "<<a<<" & "<<b<<" is : "<<a-b;
			break;
		case 3:	cout<<"Multiplication of  "<<a<<" & "<<b<<" is : "<<a*b;
			break;
		case 4:
			try
			{
				if(b!=0)
				{
					cout<<"Division of  "<<a<<" & "<<b<<" is : "<<a/b;
				}
				else
				{	
					throw b;
				}
			}
			catch(int i)
			{
				cerr<<"Error : Divide by zero error "<<i<<endl;
			}
			break;
	}
}while(no!=5);
return 0;
}
