#include<iostream>

using namespace std;

class cricketplayer
{
//public:
int pcode,runs,innings_played,not_out_no;
char pname[20];
float avg,avg1;

public:	void cpaccept()
	{
		cout<<"\nAccept\n";
		cout<<"Accept Player code = ";
		cin>>pcode;
		cout<<"Accept Player Name = ";
		cin>>pname;		
		cout<<"Accept Runs = ";
		cin>>runs;
		cout<<"Accept Number of inning's played = ";
		cin>>innings_played;
		cout<<"Accept Number of times not out = ";
		cin>>not_out_no;
	}
	void cpdisplay()
	{
		cout<<"\n\tSimple Display\n";
		avg=(runs/(innings_played-not_out_no));
		cout<<"\nPlayer code = "<<pcode<<"\nPlayer Name = "<<pname<<"\nRuns = "<<runs<<"\nNumber of inning's played = "<<innings_played<<"\nNumber of times not out = "<<not_out_no<<"\nAverage ::"<<avg<<endl;
	}

	void avgofall()
	{
		int i,total=0;
		for(i=0;i<2;i++)
		{
			total=total+runs;//(innings_played-not_out_no);
		}
		avg1=total/2;
		cout<<"\nAverage runs = "<<pcode<<"::"<<avg1;
	}
};
int main()
{
	cricketplayer c1[10];
	int i;
	for(i=0;i<2;i++)
	{
		c1[i].cpaccept();
	}
	for(i=0;i<2;i++)
	{
		c1[i].cpdisplay();
	}
		c1[1].avgofall();

}
