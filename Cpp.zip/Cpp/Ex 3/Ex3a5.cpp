#include<iostream>

using namespace std;

class dist1
{
float meter,centim;
public:	
}
class dist2
{
float feet,inches;
public:	
}
