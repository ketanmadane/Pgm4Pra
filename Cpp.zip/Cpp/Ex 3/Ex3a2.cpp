#include<iostream>
#include<stdlib.h>
using namespace std;
class REPORT
{
	private:
		int adno;
		char name[20];
		float marks[5],average;
		void GETAVG()
		{
			float sum=0;
			for(int i=0;i<5;i++)
			{
				sum=sum+marks[i];
			}
			average=sum/5;
		}
	public:
		void READINFO()
		{	
				cout<<"\nEnter the Admission Number :: ";
				cin>>adno;
			while(adno<1000 || adno>9999)
			{				
				cout<<"\nEnter 4 digit Addmission number :: ";				
				cin>>adno;
			}
			cout<<"\nEnter Your name :: ";
			cin>>name;
			cout<<"\nEnter your Marks\n";
			for(int i=0;i<5;i++)
			{
				cin>>marks[i];
			}
			GETAVG();
		}
		void DISPLAYINFO()
		{
			system("clear");
			cout<<"\nThe Admission Number :: "<<adno;
			cout<<"\nYour name :: "<<name;
			cout<<"\nYour Marks\n";
			for(int i=0;i<5;i++)
			{
				 cout<<"\n"<<marks[i];
			}
			cout<<"\nPercentage ::"<<average;
		}
};
int main()
{
	REPORT r;
	r.READINFO();r.DISPLAYINFO();return 0;
}				
