#include<iostream>
#include<stdlib.h>
#include<string.h>
class Airline
{
	private:
		struct air
		{
			int Fno;
			char Orignination[3],Destination[3];
			int Dtime,Atime;
		};
	public:
		void Input()
		{
			cout<<"\nEnter the flight number :: ";
			cin>>Fno;
			cout<<"\nEnter the Orgination Code :: ";
			cin>>Orignination;
			cout<<"\nEnter the Destination Code :: ";
			cin>>Destination;
			cout<< "\nEnter the Departure time :: ";
			cin>>Dtime;
			cout<<"\nEnter the Arrival time :: ";
			cin>>Atime;
		}
		void check(Airline &a,char *aa,char *b,int n)
		{
			for(int i=0;i<n;i++)
			{
				if(strcmp(a[i].Orignination,aa)==0&&strcmp(a[i].Orignination,b)==0)
				{
					cout<<"\n Given Data Found Details are :";
					display(a);
				}
				else
				{
					cout<<"\nGiven Data not found";
				}
			}
		}
		void display(Airline &a)
		{
			cout<<"\nFlight number :: "<<a.Fno;
			cout<<"\nOrgination Code :: "<<a.Orignination;
			cout<<"\nDestination Code :: "<<a.Destination;
			cout<< "\nDeparture time :: "<<a.Dtime;
			cout<<"\nArrival time :: "<<a.Atime;
		}
};
int main()
{
	Airline a[10];
	int n;
	char origin[3],destinaiton[3];
	cout<<"Enter how many Records do you want to Enter :: ";
	cin>>n;
	for(int i=0;i<n;i++)
	{
		a[i].Input();
	}
	system("clear");
	cout<<"\nEnter The Orgination Code ::";
	cin>>origin;
	cout<<"\nEnter The Destination Code ::";
	cin>>destinaiton;
	check(a,origin,destinaiton);
	return 0;
}
