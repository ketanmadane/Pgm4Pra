#include<iostream>
#include<stdlib.h>
using namespace std;
class Aeroplane
{
	private:
		int Fno;
		char Destination[100];
		float Distance,Fuel;
		void CALFUEL()
		{
			if(Distance<=1000)
			Fuel=500;
			else if(Distance>1000 && Distance <=2000)
			Fuel=1100;
			else if(Distance>2000)
			Fuel=2200;
		}
	public:
		void FEEDINFO()
		{
			cout<<"\nEnter the Flight Number :: ";
			cin>>Fno;
			cout<<"\nEnter the Destination :: ";
			cin>>Destination;
			cout<<"\nEnter the Distance :: ";
			cin>>Distance;
			CALFUEL();
		}
		void SHOWINFO()
		{
			system("clear");
			cout<<"\nThe Flight Number :: "<<Fno;
			cout<<"\nDestination :: "<<Destination;
			cout<<"\nDistance :: "<<Distance;
			cout<<"\nRequired Fuel :: "<<Fuel<<endl;
		}
};
int main()
{
	Aeroplane a;
	a.FEEDINFO();
	a.SHOWINFO();
	return 0;
}
		
