#include<iostream>
using namespace std;
class Complex
{
	int a,b,c,d;
public:
	Complex()
	{
		a=5;b=10;
		c=5;d=10;
	}
	Complex()
