#include<iostream>
#include<string.h>

using namespace std;

class Plant
{
char p_name[30],p_type[20];
int p_code,price;
public:

//default constructor

	Plant()
	{
		strcpy(p_name,"Not specified");
		strcpy(p_type,"flowering");
		p_code=4567;
		price=200;
	}

//copy constructor

	Plant(Plant &k)
	{
		strcpy(p_name,k.p_name);
		strcpy(p_type,k.p_type);
		p_code=k.p_code;
		price= k.price;
	}

//Parameterize constructor

	Plant(char name[30],char type[20],int code,int pri)
	{
		strcpy(p_name,name);
		strcpy(p_type,type);
		p_code=code;
		price=pri;
	}


	void accept()
	{
		cout<<"Accept Plant Name & Plant type : ";
		cin>>p_name>>p_type;
		cout<<"Accept Plant code & price of that plant : ";
		cin>>p_code>>price;
	}


	void display()
	{
		cout<<"\nPlant name = "<<p_name<<"\nPlant type = "<<p_type<<"\nPlant code = "<<p_code<<"\nPrice = "<<price<<endl;
	}
};
int main()
{
Plant p1,p2,p3(p1);
p1.accept();
p2.accept();
p1.display();
p2.display();
p3.display();
}
