#include<iostream>

using namespace std;

class machine
{
int cnt_dm,cnt_mh,cnt_pr,cnt_el;
public:	machine()
	{
		cnt_dm=5;
		cnt_mh=6;
		cnt_pr=5;
		cnt_el=8;
	}
	void accept()
	{
		cout<<"Accept\nAccept how many Dairy milk you want : ";
		cin>>cnt_dm;
		cout<<"Accept how many Munch you want : ";
		cin>>cnt_mh;
		cout<<"Accept how many Perk you want : ";
		cin>>cnt_pr;
		cout<<"Accept how many Echlairs you want : ";
		cin>>cnt_el;
	}

};
int main()
{
machine m1;
cout<<"***Menu***\n1.Dairy Milk ... 15 Rs.\n2.Munch ... 20 Rs.\n3.Perk ...15 Rs.\nEchlairs ...10 Rs.\n";
