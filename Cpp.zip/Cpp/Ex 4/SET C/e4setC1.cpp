#include<iostream>

using namespace std;

class candy
{
int candies,chips,gum,cookies,ans,ans1,moneyacc;
public:
candy()
{
	candies=1;
	chips=1;
	gum=1;
	cookies=1;
}
void accept()
{
	cout<<"Accept\nHow many no of candies you want :";
	cin>>candies;
	cout<<"How many no of chips you want :";
	cin>>chips;
	cout<<"How many no of gum you want :";
	cin>>gum;
	cout<<"How many no of cookies you want :";
	cin>>cookies;
	dispamount();
}

void dispamount()
{
	ans=(2*candies)+(10*chips)+(5*gum)+(15*cookies);
	cout<<"\nCost of the selected item's is :"<<ans;
}

void acceptm()
{
	cout<<"\nPlease give "<<ans<<" Rs. for selected items : ";
	cin>>moneyacc;
	if(moneyacc==ans)
	{
		cout<<"Your bill for selected item is paid ...\n...Thanks for comming ...\n";
	}
	else if(moneyacc<ans)
	{
		ans1=ans-moneyacc;
		cout<<"You have left with "<<ans1<<" Rs. from "<<ans<<" Rs. :";
	}
	else
	{
		ans1=moneyacc-ans;
		cout<<"You have credited more amount with "<<ans1<<" Rs. as your main balence is "<<ans<<" Rs. :";
	}
}

~candy()
{
	if(ans==moneyacc)
		cout<<"\nItem's are released \n";
	else
		cout<<"\nItem is not released\n";
}

};
int main()
{
candy c1;
cout<<"****Menu****\n1.candies --- 2 Rs.\n2.chips --- 10 Rs.\n3.gum --- 5 Rs.\n4.cookies --- 15 Rs.\n";
c1.accept();
c1.acceptm();
}
