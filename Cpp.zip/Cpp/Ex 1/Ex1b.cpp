#include<iostream>
using namespace std;
int printDate(int,int,int);
int checkLargest(int,int,int);
void cEO(int);
void waterCondition(int);
char studentGrade(int,int);
int main()
{
	int ch,ch1;
	do
	{	
		cout<<"\n+++++MENU+++++\n1.Switch Questions\n2.Date Specification\n3.Exit\nEnter your choice::";
		cin>>ch;
		switch(ch)
		{
		case 1:
			system("clear");
			cout<<"\n+++++MENU+++++\n1.Largest of Three number\n2.To find Even or Odd\n3.Water Condition\n4.To find Grade of Student\nEnter your choice::";
			cin>>ch1;
			switch(ch1)
			{
			case 1:	system("clear");
				int a,b,c;
				cout<<"Enter the Three number::";
				cin>>a>>b>>c;
				cout<<"\nThe Largest among them is ::\n"<<checkLargest(a,b,c);
				break;
			case 2:
				system("clear");
				cout<<"\nEnter any number to check::";	
				cin>>a;
				cEO(a);
				break;
			case 3:
				system("clear");
				cout<<"Enter the temprature of water::";
				cin>>a;
				waterCondition(a);
				break;
			case 4:
				system("clear");
				cout<<"Enter total marks of student::";
				cin>>a;
				cout<<"Enter total number of subjects::";
				cin>>b;
				cout<<"The student has scored :: "<<studentGrade(a,b)<<" Grade";
				break;
			default:
				cout<<"Enter correct choice";		
			}	
			break;
		case 2: int a,b,c,d;
			system("clear");
			cout<<"Enter Month,Day,Year";
			cin>>a>>b>>c;
			if(b!=0)
			{
				d=printDate(a,b,c);
				if(d==0)
				{
					cout<<"Please Enter a Valid Date";
				}
				else
				{
					cout<<a<<"/"<<b<<"/"<<c;
				}
			}
			break;
		case 3: break;
		default:
				cout<<"Enter the Correct choice";
		}
	}while(ch!=3);
}
int printDate(int d,int m,int y)
{
	if(m<1||m>12||d<1||d>31||y<0)
		return 0;
	else
		 return 1;
}
int checkLargest(int a,int b,int c)
{
	if(a>b)
	{
		if(a>c)
		{return a;}
		else
		{return c;}
	}else if(b>c)
	return b;
	else
		return c;
}
void cEO(int a)
{
	if(a%2==0)
	{
		cout<<"\nThe number is Even\n";
	}else
		cout<<"\nThe number is ODD\n";
}
void waterCondition(int a)
{
	if(a<4)
	{cout<<"\nWater is in Solid state,i.e. ICE\n";
	}else if(a>4 && a<100)
	{cout<<"\nWater is in Liquid state,i.e. water\n";
	}else if(a>=100)
	{cout<<"\nWater is in Gas state,i.e. water vapour\n";
	}
}
char studentGrade(int a,int b)
{
	int c=a/b;
	if(c>74)
	return 'O';
	else if(c<74 && c>65)
	return 'A';
	else if(c<65 && c>60)
	return 'B';
	else if(c<60 && c>50)
	return 'C';
	else if(c<50 && c>45)
	return 'D';
	else if(c<45 && c>40)
	return 'E';
	else if(c<40)
	return 'F';
}
