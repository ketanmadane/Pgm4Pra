#include <iostream>      
#include <stdlib.h>
using namespace std;
void rGen()
{
	int iSecret, iGuess;
	iSecret = rand() % 100 + 1;
  	cout<<endl<<iSecret;
  	do
	{
    		cout<<endl<<"Guess the number (1 to 100): ";
    		cin>>iGuess;
    		if (iSecret<iGuess) cout<<"The secret number is lower";
    		else if (iSecret>iGuess) cout<<"The secret number is higher";
  	}while (iSecret!=iGuess);
  	cout<<"Congratulations!";
}
void pDisp(int row)
{
	int i=1,m=1;
	while(i<=row)
	{
		int j=1;
		while(j<=i)
		{
			cout<<j<<" ";
			j++;
		}
		int k=1;
		cout<<"\t";
		while(k<=i)
		{
			cout<<i<<" ";
			k++;
		}
		cout<<"\t";
		j=1;
		while(j<=i)
		{
			cout<<m<<" ";
			m++;
			j++;
		}
		cout<<"\t\t";
		
		cout<<endl;
		i++;
	}
}
		
int main ()
{
 int ch,n;
	do
	{
		cout<<"\n++++++MENU+++++++\n1.Random number generator\n2.To display pattern\n3.Exit\nEnter your choice::";
		cin>>ch;
		switch(ch)
		{
			case 1:
				rGen();
				break;
			case 2:
				cout<<"Enter the numner of rows";
				cin>>n;
				pDisp(n);
				break;
			case 3:
				break;
			default:
				cout<<"Invalid choice";
		}
	}while(ch!=3); 	
  return 0;
}
