#include<iostream>
#include<stdlib.h>
using namespace std;
int d1,d2,m1,m2,y1,y2,res=0;double cost=0;
float calc(float,float);
float calp1(float,float);
int cala(int,int);
int calp(int,int);
void acceptd1();
void acceptd2();
void compute(int,int,int,int,int,int);
void nocall(int);
void print();
int main()
{
	int ch,noc;
	do
	{
		cout<<"\n+++++MENU+++++\n1.To calculate of the area and perimeter\n2.Date difference\n3.Total Call Rate\n4.To print size of Fundamental datatype and pointer.\n5.Exit\nEnter your choice::";
		cin>>ch;
		switch(ch)
		{
			case 1:
				system("clear");
				cout<<"Area of given Rectangle is::"<<cala(3,5)<<endl;
				cout<<"Perimeter of given Rectangle is::"<<calp(3,5)<<endl;
				cout<<"Area of given Rectangle is::"<<calc(6.8,2.3)<<endl;
				cout<<"Perimeter of given Rectangle is::"<<calp1(6.8,2.3)<<endl;
				break;
			case 2:
				system("clear");
				acceptd1();
				if(res!=0)
				{
					cout<<"Total days between\t::"<<d1<<"/"<<m1<<"/"<<y1<<"\tTo\t"<<d2<<"/"<<m2<<"/"<<y2<<"=="<<res<<endl;
				}
				break;
			case 3:	
				system("clear");
				cout<<"\nEnter how many number of Call::";
				cin>>noc;
				nocall(noc);
				cout<<"Total charges::"<<cost;
				break;
			case 4:	system("clear");
				print();
				break;
			case 5:
				break;
			default:
				cout<<"Invalid input\nEnter again";
			
		}
	}while(ch!=5);
	return 0;
}
//Q1.functions
float calc(float a,float b){return a*b;}
float calp1(float a,float b){return 2*(a+b);}
int cala(int a,int b){return a*b;}
int calp(int a,int b){return 2*(a+b);}
//Q2.functions
void acceptd1()
{
	cout<<"\nEnter the MONTH for first year::";
	cin>>m1;
	if(m1>=1 && m1<13)
	{
		cout<<"\nEnter the YEAR of first year::";
		cin>>y1;
		if(y1>=1000 && y1<=9999)
		{
			cout<<"\nEnter the DATE of first year";
			cin>>d1;
			if(y1%4==0 && y1%400==0 && y1%100!=0 && m1==2)
			{
				if(d1<=29 && d1>=1)
				{
					acceptd2();
				}
				else
				{
					cout<<"Entered date for the month is incorrect.\n"; 
				}
			}
			else
			{
				if(m1==1||m1==3||m1==5||m1==7||m1==8||m1==10||m1==12)
				{
					if(d1<=31 && d1>0)
					{
						acceptd2();
					}
					else
					{
						cout<<"Invalid date";
					}			
				}
				else if(m1==4||m1==6||m1==9||m1==11)
				{
					if(d1<=30 && d1>0)
					{
						acceptd2();				
					}
					else
					{
						cout<<"Invalid Date";
					}
				}
				else if(m1==2)
				{
					if(d1<=28 && d1>0)
					{
						acceptd2();				
					}
					else
					{
						cout<<"Invalid Date";
					}
				}
			}
		}
		else
		{
			cout<<"Enter only 4 digit Year";
		}
	}
	else
	{
	cout<<"Invalid month";
	}
}
void acceptd2()
{
	cout<<"\nEnter the MONTH for SECOND year::";
	cin>>m2;
	if(m2>=1 && m2<13)
	{
		cout<<"\nEnter the YEAR of SECOND year::";
		cin>>y2;
		if(y2>=1000 && y2<=9999 && y2>=y1)
		{
			cout<<"\nEnter the DATE of SECOND year";
			cin>>d2;
			if(y2%4==0 && y2%400==0 && y2%100!=0 && m2==2)
			{
				if(d2<=29 && d2>=1)
				{
					compute(d1,m1,y1,d2,m2,y2);
				}
				else
				{
					cout<<"Entered date for the month is incorrect.\n"; 
				}
			}
			else
			{
				if(m2==1||m2==3||m2==5||m2==7||m2==8||m2==10||m2==12)
				{
					if(d2<=31 && d2>0)
					{
						compute(d1,m1,y1,d2,m2,y2);
					}
					else
					{
						cout<<"Invalid date";
					}			
				}
				else if(m2==4||m2==6||m2==9||m2==11)
				{
					if(d2<=30 && d2>0)
					{
						compute(d1,m1,y1,d2,m2,y2);
					}
					else
					{
						cout<<"Invalid Date";
					}
				}
				else if(m2==2)
				{
					if(d2<=28 && d2>0)
					{
						compute(d1,m1,y1,d2,m2,y2);
					}
					else
					{
						cout<<"Invalid Date";
					}
				}
			}
		}
		else
		{
			cout<<"Enter only 4 digit Year";
		}
	}
	else
	{
	cout<<"Invalid month";
	}
}
void compute(int d1,int m1,int y1,int d2,int m2,int y2)
{
	int y3,m3,d3,l1,l2,tempm2=0,tempm1=0;
	l1=(y1-1)/4;
	l2=(y2-1)/4;
	y3=((y2-1)*365+l2)-((y1-1)*365+l1);
	d3=d2-d1;
	for(int i=1;i<m1;i++)
	{
		if(i==1||i==3||i==5||i==7||i==8||i==10||i==12)
		{
			tempm1=tempm1+31;
		}
		else if(i==4||i==6||i==9||i==11)
		{
			tempm1=tempm1+30;
		}
		if(i==2)
		{
			tempm1=tempm1+28;
		}
	}
	for(int i=1;i<m2;i++)
	{
		if(i==1||i==3||i==5||i==7||i==8||i==10||i==12)
		{
			tempm2=tempm2+31;
		}
		else if(i==4||i==6||i==9||i==11)
		{
			tempm2=tempm2+30;
		}
		if(i==2)
		{
			tempm2=tempm2+28;
		}
	}
	m3=tempm2-tempm1;
	res=y3+m3+d3;
}
//Q3.Functions
void nocall(int noc)
{
	cost=0;
	if(noc<100)
	{
	cost=cost+200;
	}else if(noc>100)
	{
		cost=cost+200;
		noc=noc-100;
		if(noc<=50 && noc>0)
		{
			cost=cost+(noc*0.6);
		}
		else
		{	
			cost=cost+(50*0.6);
			noc=noc-50;
		}
		if(noc<=50 && noc>0)
		{
			cost=cost+(noc*0.5);
		}
		else
		{	
			cost=cost+(50*0.5);
			noc=noc-50;
		}
	}
	if(noc>0)
	{
		cost=cost+(noc*0.4);
	}
}			
		
//Q4.function
void print()
{
	cout<<"\nSize of Fundamental datatype 'int'== "<<sizeof(int);
	cout<<"\nSize of Fundamental datatype 'float'== "<<sizeof(float);
	cout<<"\nSize of Fundamental datatype 'double'== "<<sizeof(double);
	cout<<"\nSize of Fundamental datatype 'char'== "<<sizeof(char);
	cout<<"\nSize of Fundamental datatype 'int pointer'== "<<sizeof(int *);
	cout<<"\nSize of Fundamental datatype 'float pointer'== "<<sizeof(float *);
	cout<<"\nSize of Fundamental datatype 'double pointer'== "<<sizeof(double *);
	cout<<"\nSize of Fundamental datatype 'char pointer'== "<<sizeof(char *);
}
