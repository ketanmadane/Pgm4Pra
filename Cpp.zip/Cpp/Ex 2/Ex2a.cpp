#include<iostream>
#include<stdlib.h>
using namespace std;
void zero_small(int &a,int &b)
{
	int &a1=a,b1=b;
	if(a1>b1)
	{
		b1=0;
	}
	a1=0;
}
float Simple_int(double p,float i=10,int y=2)
{
	float result;
		result=p*i*y;
		return result/100;

}
int power(double base = 2,int pow = 2)
{
	int result=1;
		for(int i=0;i<pow;i++)
		{
			result=result*base;
		}
return result;
}

int power(int base = 2,int pow = 2)
{
	int result=1;
		for(int i=0;i<pow;i++)
		{
			result=result*base;
		}
return result;
}
	
int main()
{
	int ch;
	do
	{	
		cout<<"\n++++++MENU+++++\n1.Compare two numbers and init smaller to '0'\n2.To calculate simple intrest\n3.Power Function\n4.Exit\nEnter Your choice :: ";
		cin>>ch;
		switch(ch)
		{
			case 1:	
				system("clear");
				int a,b;
				cout<<"\nEnter any two numbers::";
				cin>>a>>b;
				cout<<"\nValue of a = "<<a<<"\nValue of b = "<<b;	
				zero_small(a,b);
				cout<<"\nValue of a = "<<a<<"\nValue of b = "<<b;	
				break;
			case 2:
				system("clear");
				double price;
				float intrest;
				int year;
				cout<<"\nEnter the amount :: ";
				cin>>price;
				cout<<"\nEnter the Intrest rate :: ";
				cin>>intrest;
				cout<<"\nEnter total number of years :: ";
				cin>>year;
				cout<<"\nSimple intrest : "<<Simple_int(price,intrest,year);
				break;
			case 3:
				system("clear");
				double b2;int b1,p;
				cout<<"\nEnter the base value : ";
				cin>>b2;
				cout<<"\nEnter the power value : ";
				cin>>p;
				//cout<<"Calling power function with default arguments : "<<power();
				cout<<"Calling power function with values : "<<b2<<" & "<<p<<" = "<<power(b2,p);
				cout<<"\nEnter the base value : ";
				cin>>b1;
				cout<<"Calling power function with values : "<<b1<<" & "<<p<<" = "<<power(b1,p);
				
				
				break;
			case 4:
				break;
			default:
				cout<<"\nInvalid Choice";
		}
	}while(ch!=4);
			
	return 0;
}
	
