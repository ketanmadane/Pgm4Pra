#include<iostream>
#include<stdlib.h>
#include<string.h>
using namespace std;
struct student
{
int roll;
float percentage;
char name[100];
};
void sorting(int n,int a[100])
{
int temp;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<" "<<a[i];
	}
}
void sorting(int a[100],int n)
{
int temp;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(a[j]<a[j+1])
			{
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		cout<<" "<<a[i];
	}

}
float area(float r)
{
	return 3.142*r*r;
}
float area(int b,int l)
{
	return l*b;
}
float area(float r,float h)
{
	return ((2*(3.142*r*r))+(2*3.142*r*h));
}
int search(struct student *s,int n,int r)
{
	for(int i=0;i<n;i++)
	{
		if(s[i].roll==r)
		{return i+1;}
	}
return 0;
}
int search(struct student *s,int n,char *na)
{
	for(int i=0;i<n;i++)
	{
		if(strcmp(s[i].name,na)==0)
		{return i+1;}
	}
return 0;
}
int search(struct student *s,int n,float per)
{
	for(int i=0;i<n;i++)
	{
		if(s[i].percentage==per)
		{return i+1;}
	}
return 0;
}
void print(struct student *s,int n)
{
	for(int i=0;i<n;i++)
	{
	cout<<s[i].name;
	}
}
int main()
{
	int ch;
	do
	{	
		cout<<"\n++++++MENU+++++\n1.Sorting\n2.To calculate Area\n3.Student Structure\n4.Exit\nEnter Your choice :: ";
		cin>>ch;
		switch(ch)
		{
			case 1:	
				system("clear");
				int n,s,a[100];
				cout<<"\nEnter many numbers do you want::";
				cin>>n;
				
				cout<<"\nEnter "<<n<<" numbers ::";
				for(int i=0;i<n;i++)
				{
					cin>>a[i];
				}
				system("clear");
				cout<<"Enter '1' to sort in decending order else enter any number for asscending order sorting";
				cin>>s;
				if(s==1)
				{
					sorting(a,n);
				}
				else
				{
					sorting(n,a);	
				}
				break;
			case 2:
				system("clear");
				int ch1;
				cout<<"\n+++++MENU+++++\n1.Area of Circle\n2.Area of Rectangle\n3.Area of Cylinder\nEnter your choice :: ";
				cin>>ch1;
				switch(ch1)
				{
					case 1:
						float cr;
						cout<<"\nEnter the Radius : ";
						cin>>cr;
						cout<<"Area of Circle :: "<<area(cr);
						break;
					case 2:
						int rl,rb;
						cout<<"\nEnter the Length of Rectangle :: ";
						cin>>rl;
						cout<<"\nEnter the Breath of Rectangle :: ";
						cin>>rb;
						cout<<"\nArea of Rectangle : "<<area(rb,rl);
						break;
					case 3:
						float cyr,cyh;
						cout<<"\nEnter the Radius : ";
						cin>>cyr;
						cout<<"\nEnter the Height : ";
						cin>>cyh;
						cout<<"\nArea of Cylinder : "<<area(cyr,cyh);
						break;
					default:
						cout<<"\nEnter Valid choice";
				}
				break;
			case 3:
				system("clear");
				int sn;
				cout<<"\nHow many Records do you want to insert :: ";
				cin>>sn;
				student stud[100];
				for(int ii=0;ii<sn;ii++)
				{
					cout<<"\nEnter the Roll Number :: ";
					cin>>stud[ii].roll;
					cout<<"\nEnter the Name :: ";
					cin>>stud[ii].name;
					cout<<"\nEnter the Percentage :: ";
					cin>>stud[ii].percentage;
				}
				do
				{
					system("clear");
					cout<<"\n+++++MENU+++++\n1.Search By Roll Number\n2.Search By Name\n3.Search By Percentage\n4.Back\nEnter your choice :: ";
					cin>>ch1;
					switch(ch1)
					{
						case 1:
							int sroll,sresult;
							cout<<"\nEnter the Roll Number : ";
							cin>>sroll;
							sresult=search(stud,sn,sroll);
							if(sresult!=0)
							{
								cout<<"Given Data found at location "<<sresult;	
							}else
							{cout<<"Sorry the Given Data could not be found";}	
						break;
						case 2:
							char sname[100];
							cout<<"\nEnter the Name : ";
							cin>>sname;
							sresult=search(stud,sn,sname);
							if(sresult!=0)
							{
								cout<<"Given Data found at location "<<sresult;	
							}else
							{cout<<"Sorry the Given Data could not be found";}	
						break;
						case 3:
							float sper;
							cout<<"\nEnter the Name : ";
							cin>>sper;
							sresult=search(stud,sn,sper);
							if(sresult!=0)
							{
								cout<<"Given Data found at location "<<sresult;	
							}else
							{cout<<"Sorry the Given Data could not be found";}	
						break;
						case 4: 
							break;
						default:
							cout<<"\nEnter Valid choice";				
					}
				}while(ch1!=4);
				break;
			case 4:
				break;
			default:
				cout<<"\nInvalid Choice";
		}
	}while(ch!=4);
			
	return 0;
}
	
