#include<iostream>

using namespace std;

class Fraction
{
int num,den;
public:	Fraction()
	{
		num=20;
		den=8;
	}
	Fraction(int n,int d)
	{
		num=n;
		den=d;
	}
	void accept()
	{
		cout<<"Accept value of numnerator & Denominator : ";
		cin>>num>>den;
	}
	
	//addition

	void add(Fraction f1[2])
	{
		cout<<"num "<<f1[0].num<<"\tden "<<f1[0].den;
		cout<<"\nnum "<<f1[1].num<<"\tden "<<f1[1].den;
		if(f1[0].den != f1[1].den)
		{
			cout<<"\nDenominator not same\n";
			int sumN=(f1[0].num*f1[1].den+f1[1].num*f1[0].den);
			int sumD=(f1[0].den*f1[1].den);
			cout<<"\nAddition is = "<<sumN<<" / "<<sumD<<endl;
		}
		else
		{
			cout<<"\ndenominator same\n";
			int sumN=(f1[0].num+f1[1].num);
			int sumD=(f1[0].den+f1[1].den);
			cout<<"\nAddition is = "<<sumN<<" / "<<sumD<<endl;
		}
	}

	//Substraction
	void sub(Fraction f1[2])
	{
		cout<<"num "<<f1[0].num<<"\tden "<<f1[0].den;
		cout<<"\nnum "<<f1[1].num<<"\tden "<<f1[1].den;
		if(f1[0].den && f1[1].den !=0)
		{
			cout<<"\nDenominator not same\n";
			int sumN=(f1[0].num*f1[1].den-f1[1].num*f1[0].den);
			int sumD=(f1[0].den*f1[1].den);
			cout<<"\nSubstraction is = "<<sumN<<" / "<<sumD<<endl;
		}
		else
		{
			cout<<"\ndenominator same\n";
			int sumN=(f1[0].num-f1[1].num);
			int sumD=(f1[0].den-f1[1].den);
			cout<<"\nSubstraction is = "<<sumN<<" / "<<sumD<<endl;
		}
		
	}


	//Multiplication

	void mult(Fraction f1[2])
	{
		cout<<"num "<<f1[0].num<<"\tden "<<f1[0].den;
		cout<<"\nnum "<<f1[1].num<<"\tden "<<f1[1].den;
		if(f1[0].den && f1[1].den !=0)
		{
			int sumN=(f1[0].num*f1[1].num);
			int sumD=(f1[0].den*f1[1].den);
			if(sumD<=0)
			{
				cout<<"\nDenominator is 0\n";
			}
			cout<<"\nMultiplication is = "<<sumN<<" / "<<sumD<<endl;
		}
		else
		{
			cout<<"\nBoth the values of denominator are zero\n";
		}
	}


	//Division


	void div(Fraction f1[2])
	{
		cout<<"num "<<f1[0].num<<"\tden "<<f1[0].den;
		cout<<"\nnum "<<f1[1].num<<"\tden "<<f1[1].den;
		if(f1[0].den && f1[1].den !=0)
		{
			int sumN=(f1[0].num*f1[1].den);
			int sumD=(f1[0].den*f1[1].num);
			if(sumD<=0)
			{
				cout<<"\nDenominator is 0\n";
			}
			cout<<"\nDivision is = "<<sumN<<" / "<<sumD<<endl;
		}
		
		else
		{
			cout<<"\nBoth the values of denominator are zero\n";
		}
	}

};
int main()
{
int i,ch;
Fraction f1[2],f3;
for(i=0;i<2;i++)
f1[i].accept();

cout<<"****MENU****\n1.Addition\n2.Substraction\n3.Multiplication\n4.Division\n\n..Enter your choice :- ";
cin>>ch;
switch(ch)
{
case 1:	f3.add(f1);
	break;
case 2:	f3.sub(f1);
	break;
case 3:	f3.mult(f1);
	break;
case 4:	f3.div(f1);
	break;
case 5:	exit(0);
default:cout<<"Error :: Enter correct choice\n";
	break;
}
}
