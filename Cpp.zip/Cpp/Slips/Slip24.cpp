#include<iostream>

using namespace std;

class book
{
int bno;
char btitle[30];
float price;
float total_cost(int k)
{
	float total=0.0;
	total=k*price;
	return total;
}
public:	void input()
	{
		cout<<"Accept Book_number --- book_title --- Price \n";
		cin>>bno>>btitle>>price;
	}
	float purchase()
	{
		int n;
		cout<<"\nEnter no of copies you want : ";
		cin>>n;
		cout<<"\nTotal cost = "<<total_cost(n)<<"\n";
	}
	void display()
	{
		cout<<"\nBook number		= "<<bno;
		cout<<"\nBook title 		= "<<btitle;
		cout<<"\nPrice of that book 	= "<<price<<endl;
	}
};
int main()
{
book b;
b.input();
b.purchase();
b.display();
return 0;
}
