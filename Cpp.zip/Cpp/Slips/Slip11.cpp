#include<iostream>

using namespace std;

class emp
{
	char empnm[30];
	int code;
	char desg[30];
public:	void eaccept()
	{
		cout<<"Accept name,code,desg : ";
		cin>>empnm>>code>>desg;
	}
	void edisplay()
	{
		cout<<"\nEmployee name = "<<empnm<<"\nCode = "<<code<<"\nDesignation = "<<desg<<endl;
	}
};
class manager:public emp
{
	int yoe;
	float sal;
public:	void maccept()
	{
		cout<<"\nAccept year_of_exp & sal : ";
		cin>>yoe>>sal;
	}
	void mdisplay()
	{
		cout<<"\nYear_of_experience = "<<yoe<<"\nSalary = "<<sal;
	}
};
int main()
{
	manager m1[20];
	int i,n;
	cout<<"How many man you want : ";
	cin>>n;
	for(i=0;i<n;i++)
	{
		m1[i].eaccept();
		m1[i].maccept();
	}
	for(i=0;i<n;i++)
	{
		m1[i].edisplay();
		cout<<"\n******************\n\n";
		m1[i].mdisplay();
		cout<<"\n******************\n\n";
	}
return 0;
}
