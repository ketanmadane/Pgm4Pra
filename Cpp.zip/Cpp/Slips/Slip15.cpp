#include<iostream>

using namespace std;

class shape
{
protected:double a;
public:	void get_data(double x)
	{
		a=x;
	}
	virtual void disp_data()=0;
};

class circle:public shape
{
public:	void disp_data()
	{
		cout<<"Area of circle : "<<3.14*a*a<<" sqcm"<<endl;
	}
};

class sphere:public shape
{
public:	void disp_data()
	{
		cout<<"Area of sphere : "<<(4/3)*3.14*a*a*a<<" sqcm"<<endl;
	}
};

int main()
{
	double r;
	shape *s1;
	circle c1;
	s1=&c1;
	cout<<"Enter radius of circle : ";
	cin>>r;
	s1->get_data(r);
	s1->disp_data();

	sphere sp1;
	s1=&sp1;
	cout<<"Enter radius of sphere : ";
	cin>>r;
	s1->get_data(r);
	s1->disp_data();
	return 0;
}
