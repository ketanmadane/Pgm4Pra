#include<iostream>
#include<stdlib.h>
using namespace std;
class Complex
{
	private:
		int real,img;
	public:
		Complex()
		{
		}
		Complex(int x,int y)
		{
			real=x;
			img=y;
		}
		void display()
		{
			cout<<real<<" + "<<img<<"i "<<endl;
		}
		Complex operator +(Complex z)
		{
			Complex t;
			t.real=real+z.real;
			t.img=img+z.img;
			return t;
		}
		Complex operator -(Complex z)
		{
			Complex t;
			t.real=real+z.real;
			t.img=img+z.img;
			return t;
		}
		void ddisplay()
		{
			cout<<real<<" - "<<img<<"i "<<endl;
		}
		Complex operator *(Complex z)
		{
			Complex t;
			t.real=(real*z.real)-(img*z.img);
			t.img=(img*z.img)+(real*z.real);
			return t;
		}
};
int main()
{
	int a,b;
	cout<<"Enter the first complex  number:: ";
	cin>>a>>b;
	Complex c1(a,b);
	cout<<"Enter the Second complex  number:: ";
	cin>>a>>b;
	Complex c2(a,b),c3,c4,c5;
	c3=c1+c2;
	c3.display();
	c4=c1-c2;
	c4.ddisplay();
	c5=c1*c2;
	c5.display();
	return 0;
}
							
