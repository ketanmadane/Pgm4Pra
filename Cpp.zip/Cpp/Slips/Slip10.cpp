#include<iostream>
using namespace std;

class shape
{
protected:double a,b;
public:	void get_data(double x,double y=0)
	{
		a=x;
		b=y;
	}
	virtual void disp_area()=0;
};

class square:public shape
{
public:	void disp_area()
	{
		cout<<"Area of square : "<<a*a<<" sqcm"<<endl;
	}
};

class rectangle:public square
{
public:	void disp_area()
	{
		cout<<"Area of rectangle : "<<a*b<<endl;
	}
};
int main()
{
	double l,m;
	square s1;
	shape *sh1;
	sh1=&s1;
	cout<<"Enter side of square :";
	cin>>l;
	sh1->get_data(l);
	sh1->disp_area();

	rectangle r1;
	sh1=&r1;
	cout<<"Enter length & breadth of rect : ";
	cin>>l>>m;
	sh1->get_data(l,m);
	sh1->disp_area();
	return 0;
}
