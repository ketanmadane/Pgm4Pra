#include<iostream>
#include<string.h>
#include<stdlib.h>
using namespace std;
class Competition
{
	private:
		int Event_no,Score;
		char Qualified,Description[30];
	public:
		Competition()
		{
			Event_no=101;
			Score=50;
			strcpy(Description,"State Level");
			Qualified='N';
		}
		void Input()
		{
			system("clear");
			cout<<"\nEnter the Event_no :: ";
			cin>>Event_no;
			cout<<"\nEnter the Description :: ";
			cin>>Description;
			cout<<"\nEnter the Score :: ";
			cin>>Score;
		}
		void Award(int cut)
		{
			if(Score>cut)
			{
				Qualified='Y';
			}
		}
		void Show()
		{
			system("clear");
			cout<<"\nEvent_no :: "<<Event_no;
			cout<<"\nDescription :: "<<Description;
			cout<<"\nScore :: "<<Score;
			cout<<"\nQualified :: "<<Qualified;
		}
};
int main()
{
	Competition c1,c2;
	c1.Show();
	int c;
	cout<<"\nEnter the Cutoff Score :: ";
	cin>>c;
	c2.Input();
	c2.Award(c);
	c2.Show();
	return 0;
}
