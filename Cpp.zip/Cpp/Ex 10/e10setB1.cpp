#include<iostream>

using namespace std;

template<class T>

T swap(T &a,T &b)
{
T temp=a;
a=b;
b=temp;
}
int main()
{
int x1=4,y1=7;
float x2=4.5,y2=7.5;
std::cout<<"Before swap : ";
std::cout<<"\nx1= "<<x1<<"\ny1= "<<y1<<endl;
std::cout<<"\nx2= "<<x2<<"\ny2= "<<y2<<endl;

swap(x1,y1);
//swap(x2,y2);
std::cout<<"\nAfter swap\n";
std::cout<<"\nx1= "<<x1<<"\ny1= "<<y1<<endl;
std::cout<<"\nx2= "<<x2<<"\ny2= "<<y2<<endl;
return 0;
}
