#include<iostream>
using namespace std;
class Date
{
	int no;
	public:	Date()
	{
		mm=1;
		dd=1;
		yyyy=2000;
	}
	void accept()
	{
		cout<<"Accept how many days you have to shift :: ";
		cin>>no;
	}		
};
int main()
{
Date d1;
return 0;
}
