#include<iostream>
using namespace std;
class rational
{
int num,den;
public:	rational()
	{
		num=4;
		den=7;
	}
	rational(int n,int d)
	{
		num=n;
		den=d;
	}	
};
int main()
{
	char ch;
	rational r1(5,2),r2(4,7),r3;
	cout<<"enter the opreation to be performed:: ";
	cin>>ch;
	switch(ch)
	{
		case '+':r3=r1+r2;
			r3.disp();
		case '-':r3=r1-r2;
			r3.disp();
		case '*':r3=r1*r2;
			r3.disp();
		case '/':r3=r1/r2;
			r3.disp();
		default:cout<<"Please ...enter correct choice\n";
	}
}
