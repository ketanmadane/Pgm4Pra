#include<iostream>
using namespace std;
class fact
{
int no,factn;
public:	fact()
	{
		factn=1;
		cout<<"In default constructor\n";
		no=1;
	}
	fact(int n)
	{
		factn=1;
		no=n;
		cout<<"In parameterise constructor\n";
	}
	void operator !()
	{
		int i;
		cout<<"In operator overloading\n";
		for(i=1;i<=no;i++)
		{
			factn=factn*i;
		} 
	}
	void disp()
	{
		cout<<"Factorial = "<<factn<<endl;
	}
};
int main()
{
fact f1,f2(10);
!f1;
f1.disp();
!f2;
f2.disp();
}
