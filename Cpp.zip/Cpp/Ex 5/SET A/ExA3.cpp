#include<iostream>
#include<string.h>

using namespace std;

class String
{
	char name[50];
public:	String()
	{
		strcpy(name,"Rahul");
	}
	String(char n[50])
	{
		strcpy(name,n);
	}
	void accept()
	{
		cout<<"Accept name = ";
		cin>>name;
	}
	void operator <=(String z)
	{
		if(strlen(name)<=strlen(z.name))
		{
			cout<<"String in ' <= '\nstring -> "<<name<<" <- is less than "<<z.name<<" <-\n";
		}
		else
			cout<<"String in ' <= '\nstring -> "<<name<<" <- is not less than "<<z.name<<" <-\n";
	}
	void operator ==(String z)
	{
		if(strlen(name)==strlen(z.name))
		{
			if(strcmp(name,z.name)==0)
				cout<<"String in ' == '\nstring -> "<<name<<" <- is equal to "<<z.name<<" <-\n";
			else
				cout<<"String in '=='\nstring -> "<<name<<" <- is not equal to -> "<<z.name<<" <-\n";
		}
		else
			cout<<"String in ' == '\nstring -> "<<name<<" <- is not equal to "<<z.name<<" <-\n";
	}
	void operator >=(String z)
	{
		if(strlen(name)>=strlen(z.name))
		{
				cout<<"String in ' >= '\nstring >- "<<name<<" <- is greater than "<<z.name<<" <-\n";
		}
		else
			cout<<"String in ' >= '\nstring -> "<<name<<" <- is not greater than "<<z.name<<" <-\n";
	}
	void operator +(String z)
	{
		strcat(name,z.name);
		cout<<"\nConcatenated string is :: "<<name<<endl;
	}
};
int main()
{
String s1,s2("Rahul"),s3,s4,s5,s6;
s1<=s2;
s1.accept();
s2.accept();
s1==s2;
s3.accept();
s4.accept();
s3>=s4;
s5.accept();
s6.accept();
s5+s6;
return 0;
}
