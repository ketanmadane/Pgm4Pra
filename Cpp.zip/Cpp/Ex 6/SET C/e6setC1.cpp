#include<iostream>

using namespace std;

class person
{
int id;
char name[20];
public:	void paccept()
	{
		cout<<"\n* In person *\n";
		cout<<"\nenter person id = ";
		cin>>id;
		cout<<"\nenter name = ";
		cin>>name;
	}
	void pdisplay()
	{
		cout<<"\n* In person *\n";
		cout<<"\nPerson-id = "<<id<<"\nName = "<<name<<endl;
	}
};
class teaching:public person
{
char sub[20],name[25];
public:	void taccept()
	{
		cout<<"\n * In Teaching *\n";
		paccept();
		cout<<"\nenter subject = ";
		cin>>sub;
		cout<<"\nenter name = ";
		cin>>name;
	}
	void tdisplay()
	{
		cout<<"\n * In Teaching *\n";
		pdisplay();
		cout<<"\nSubject = "<<sub;
		cout<<"\nName = "<<name;
	}
};
class instructor:public person
{
char iname;
public:	
	void iaccept()
	{
		cout<<"\n* In instructor *\n";
		paccept();
		cout<<"Enter ins name = ";
		cin>>iname;
	}
	void idisplay()
	{
		cout<<"\n* In instructor *\n";
		pdisplay();
		cout<<"Ins Name = "<<iname;
	}
};
class nonteaching:public person
{
char dept[20];
public:	void naccept()
	{
		cout<<"\n* In Non-Teaching *\n";
		paccept();
		cout<<"\nenter department name = ";
		cin>>dept;
	}
	void ndisplay()
	{
		cout<<"\n* In Non-Teaching *\n";
		pdisplay();
		cout<<"\nDepartment Name = "<<dept;
	}
};
int main()
{
int n,i;
instructor ins[20];
teaching tea[20];
nonteaching nont[20];
cout<<"Enter how many records yow want :: ";
cin>>n;
for(i=0;i<n;i++)
{
	tea[i].taccept();
	nont[i].naccept();
	ins[i].iaccept();
}
for(i=0;i<n;i++)
{
	tea[i].tdisplay();
	nont[i].ndisplay();
	ins[i].idisplay();
}
}
