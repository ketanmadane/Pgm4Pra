#include<iostream>

using namespace std;

class publication
{
	char title[20];
	float price;
	public:	void paccept()
		{
			cout<<"\nEnter the title :: ";
			cin>>title;
			cout<<"\nEnter price :: ";
			cin>>price;
		}
		void pdisplay()
		{
			cout<<"\nTitle is :: "<<title<<endl;
			cout<<"Price is :: "<<price<<endl;
		}
};
class book:public publication
{
	int pg_cnt;
	public:	void baccept()
		{
			paccept();
			cout<<"Enter pages book :: ";
			cin>>pg_cnt;
		}
		void bdisplay()
		{
			pdisplay();
			cout<<"Pages of the book :: "<<pg_cnt<<endl;
		}			
			
};
class tape:public publication
{
	int min;
	public:	void taccept()
		{
			paccept();
			cout<<"Enter time in minutes :: ";
			cin>>min;
		}
		void tdisplay()
		{
			pdisplay();
			cout<<"The time is "<<min<<" minutes"<<endl;
		}
};
int main()
{
	int bno,ch,i,tno,n,mn;
	book b1[20];
	tape t1[20];
	cout<<"Enter how many books yow want :: ";
	cin>>bno;
	for(i=0;i<bno;i++)
		b1[i].baccept();
	cout<<"Enter how many tapes yow want :: ";
	cin>>tno;
	for(i=0;i<tno;i++)
		t1[i].taccept();
	cout<<"\n**MENU**\n1.Display all books\n2.Display all tapes\n3.All books having pages>n\n4.All tapes having playing time >= n min\n5.exit\nEnter your choice :: ";
	cin>>ch;
	switch(ch)
	{
	case 1:	bdisplay();
		break;
	case 2:	tdisplay();
		break;
	case 3:	cout<<"Accept value of n :: ";
		cin>>n;
		dispbookhaving(n);
		break;
	case 4:	cout<<"Accept value of n in minute :: ";
		cin>>mn;
		disptapehaving(mn);
		break;
	case 5:	exit(0);
}
return 0;
}
