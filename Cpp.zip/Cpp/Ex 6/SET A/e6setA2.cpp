#include<iostream>

using namespace std;

class employee
{
int code;
char name[100],desig[100];
public:	void eaccept()
	{
		cout<<"\nEnter Employee name = ";
		cin>>name;
		cout<<"\nEnter Employee code = ";
		cin>>code;
		cout<<"\nEnter Employee designation = ";
		cin>>desig;
	}
	void edisplay()
	{
		cout<<"\nEmployee name = "<<name;
		cout<<"\nEmployee code = "<<code;
		cout<<"\nEmployee designation = "<<desig;
	}
};
class manager:public employee
{
	int yoe;
	float sal;
	public:void maccept()
		{
			eaccept();
			cout<<"Enter Year_of_experience = ";
			cin>>yoe;
			cout<<"Enter salary = ";
			cin>>sal;
		}
		void mdisplay()
		{	edisplay();
			cout<<"\nYear_of_experience = "<<yoe;
			cout<<"\nSalary = "<<sal<<endl;
		}
};
int main()
{
	manager m1;
	m1.maccept();
	m1.mdisplay();
	return 0;
}
