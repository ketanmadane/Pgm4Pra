#include<iostream>
using namespace std;

class shape
{
protected:double a,b;
			float r;
public:	void get_data(double x,double y=0)
	{
		a=x;
		b=y;
	}
	void getdatac(float rno=0)
	{
		r=rno;
	}
	virtual void disp_area()=0;
};

class triangle:public shape
{
public:	void disp_area()
	{
		cout<<"Area of triangle : "<<0.5*a*b<<" sqcm"<<endl;
	}
};

class rectangle:public shape
{
public:	void disp_area()
	{
		cout<<"Area of rectangle : "<<a*b<<endl;
	}
};
class circle:public shape
{
public: void disp_area()
	{
	 cout<<"Area of circle:"<<3.14*r*r<<endl;
	}
};
int main()
{ 	int r;
	double l,m;
	triangle s1;
	shape *sh1;
	sh1=&s1;
	
	cout<<"Enter lenth and breadth of triangle :";
	cin>>l>>m;
	sh1->get_data(l,m);
	sh1->disp_area();

	rectangle r1;
	sh1=&r1;
	cout<<"Enter length & breadth of rect : ";
	cin>>l>>m;
	sh1->get_data(l,m);
	sh1->disp_area();
	
	 circle c;
	sh1=&c;
	 cout<<"Enter the radius";
	cin>>r;
	sh1->getdatac(r);
	sh1->disp_area();

	return 0;
}
/*
output
Enter lenth and breadth of triangle :4 2
Area of triangle : 4 sqcm
Enter length & breadth of rect : 4 2
Area of rectangle : 8
Enter the radius 4
Area of circle:50.24

*/
