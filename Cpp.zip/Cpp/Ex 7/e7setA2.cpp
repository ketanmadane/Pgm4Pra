#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
	char name[30];
	int mk1,mk2,mk3,mk4;
	cout<<"Accept Name = ";
	cin.get(name);
	cout<<"Accept marks of physics = ";
	cin>>mk1;
	cout<<"Accept marks of chemistry = ";
	cin>>mk2;
	cout<<"Accept marks of maths = ";
	cin>>mk3;
	cout<<"Accept marks of biology = ";
	cin>>mk4;
}
	
	
