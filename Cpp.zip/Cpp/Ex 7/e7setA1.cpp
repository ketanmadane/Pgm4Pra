#include <iostream>
#include <iomanip>
#define MAX_ROW 5
#define MAX_COL 80

using namespace std;


int main()
{
    char name[MAX_ROW][MAX_COL],c;
    int lines=1,chars=1,words=1;
    cout<<"===Input Status===\n";
    cout<<"Enter string termanate by # : \n";
    cin.get(c);

	while(c != '#')
	{
        	cin.get(c);
        	chars++;
        	if(c==' ' || c=='\n')
        		words++;
        	if(c=='\n')
            		lines++;
    	}

    cout<<"\n"<<setw(20)<<"Particulars"<<setw(20)<<"Details\n";
    cout<<"-------------------------------------\n";

    cout.setf(ios::left,ios::adjustfield);
    cout<<"\n"<<setw(20)<<"No. of lines  ";
    cout.setf(ios::right,ios::adjustfield);
    cout<<setw(15)<<lines;

    cout.setf(ios::left,ios::adjustfield);
    cout<<"\n"<<setw(20)<<"No. of Words  ";
    cout.setf(ios::right,ios::adjustfield);
    cout<<setw(15)<<words;

    cout.setf(ios::left,ios::adjustfield);
    cout<<"\n"<<setw(20)<<"No. of Characters  ";
    cout.setf(ios::right,ios::adjustfield);
    cout<<setw(15)<<chars<<endl;

}

/*
output
===Input Status===
Enter string termanate by # : 
khushi
modern college
chinchwad 
151392 
#

         Particulars            Details
-------------------------------------

No. of lines                      5
No. of Words                      6
No. of Characters                40

*/
