#include<iostream>
#include<fstream>

using namespace std;

class myfile
{
fstream in_out;
char fn[80];
public:myfile(char fname[80])
		{
			strcpy(fn,fname);
		}

//display contents

		void display()
		{
			char ch[80];
			in_out.open(fn,ios::in);
			while(in_out)
			{
				in_out.getline(ch,80);
				cout<<ch<<endl;
			}
			fclose();
			cout<<"file is successfully appended : ";
		}

//append content

		void append()
		{
			char ch;
			in_out.open(fn,ios::in|ios::out|ios::ate);
			while(1)
			{
				cin.get(ch);
				if(ch=='#')
					break;
				in_out<<ch;
			}
			fclose();
			cout<<"File is successfully appended \n";
		}

//closing 

		void fclose()
		{
			in_out.close();
		}
};

int main()
{
	int ch;
	myfile mf("abc.txt");
	while(ch!=3)
	{
		cout<<"\nMENU\n1.Display\n2.Append\n3.Exit\nEnter your choice : ";
		cin>>ch;
		switch(ch)
		{
			case 1:mf.display();
					break;
			case 2:mf.append();
					break;
			case 3:mf.fclose();
					break;
		}
	}
}
