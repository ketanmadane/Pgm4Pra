#include<iostream>
#include<fstream>
using namespace std;

void copyupper(char a)
{
	char d;
	ifstream fin("first.txt");
	ofstream fout("second.txt");
	while(fin)
	{
		fin.get(d);
		cout<<d;
		fout.put(toupper(d));
	}
	cout<<"\ncopied";
}
int main()
{
	char ch;
	copyupper(ch);
	return 0;
}
