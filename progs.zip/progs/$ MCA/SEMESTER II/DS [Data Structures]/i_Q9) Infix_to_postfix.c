/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#define SIZE 100

struct PriorityTable {
	char opr;
	int priority;
};

struct PriorityTable ptable[5] = { { '$', 3 }, { '*', 2 }, { '/', 2 },
		{ '+', 1 }, { '-', 1 } };

int n = 5; //no of operators in priority table

char stack[SIZE]; //character stack
int top = -1; //intially stack is empty so index is -1

int getPriority(char opr) //this function returns priority for given opr from above 'ptable'
{
	int i;

	for (i = 0; i < n; i++) {
		if (ptable[i].opr == opr)
			return ptable[i].priority;
	}

	return -1;

}

int isEmpty() {
	if (top == -1)
		return 1;
	else
		return 0;
}

int isFull() {
	if (top == SIZE - 1)
		return 1;
	else
		return 0;
}

void push(char data) {
	if (isFull()) {
		printf("STACK IS FULL \n");
	} else {
		top++;
		stack[top] = data;

	}
}
char pop() {
	float data;
	data = stack[top];
	top--;
	return data;
}

int main() {
	char exp[80];
	int i;
	char ch;

	printf("Enter infix Expression : ");
	scanf("%s", exp);

	printf("Postfix Expression : ");

	for (i = 0; exp[i] != '\0'; i++) {
		if (exp[i] == '(') {
			push(exp[i]);
			continue;
		}

		if (exp[i] == ')') {
			while (!isEmpty() && (ch = pop()) != '(') {
				printf("%c", ch);
			}
			continue;
		}

		if (getPriority(exp[i]) == -1) {
			printf("%c", exp[i]);
			continue;
		}

		/*Remove higher & equal precedance operator from stack */
		while (!isEmpty() && getPriority(exp[i]) <= getPriority(stack[top])) {
			printf("%c", pop());
		}

		push(exp[i]);

	} //for

	while (!isEmpty()) {
		printf("%c", pop());
	}
	printf("\n");
	return 0;
}

/*		OUTPUT

 [sachin@localhost DS]$ gcc Q9_Infix_to_postfix.c
 [sachin@localhost DS]$ ./a.out

 [sachin@localhost DS]$ ./a.out
 Enter infix Expression : a*(b+c)*((d-a)/b)
 Postfix Expression : abc+*da-b/*



 Enter infix Expression : (a+b)*(c-d)
 Postfix Expression : ab+cd-*

 [sachin@localhost DS]$ ./a.out

 Enter infix Expression : a+b/c-d*2
 Postfix Expression : abc/+d2*-

 [sachin@localhost DS]$

 */
