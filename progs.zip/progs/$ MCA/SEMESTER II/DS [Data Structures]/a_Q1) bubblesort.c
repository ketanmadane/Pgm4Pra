/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<string.h>

struct Emp {
	char name[10];
	float salary;
};

struct Emp e[100]; //array to store 'n' records
int n; //to store no. of records

void accept() {
	int i;

	printf("How many recods you want to store : ");
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		printf("\nAccepting Info for Emp %d\n", i + 1);

		printf("Enter Emp Name :");
		scanf("%s", e[i].name);

		printf("Enter Salary :");
		scanf("%f", &e[i].salary);
	}

}
void display() {
	int i;
	printf("\nEMP NAME \t EMP SALARY\n");

	for (i = 0; i < n; i++) {
		printf("%10s \t %4.2f\n", e[i].name, e[i].salary);
	}

}
void sortByName() {
	int i, j;
	struct Emp temp;

	for (i = n - 1; i > 0; i--) {
		for (j = 0; j < i; j++) {
			if (strcmp(e[j].name, e[j + 1].name) > 0) {
				temp = e[j];
				e[j] = e[j + 1];
				e[j + 1] = temp;
			}
		}
	}
}

void sortBySalary() {
	int i, j;
	struct Emp temp;

	for (i = n - 1; i > 0; i--) {
		for (j = 0; j < i; j++) {
			if (e[j].salary < e[j + 1].salary) {
				temp = e[j];
				e[j] = e[j + 1];
				e[j + 1] = temp;
			}
		}
	}
}

int main() {
	accept();
	sortByName();
	printf("Displaing Data in Descending Order sorted on Emp Names \n");
	display();

	sortBySalary();
	printf("Displaing Data in Asecending Order sorted on Emp Salary \n");
	display();

	return 0;
}
