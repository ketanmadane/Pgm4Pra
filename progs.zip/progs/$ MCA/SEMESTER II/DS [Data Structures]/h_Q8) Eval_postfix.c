/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<ctype.h>

#define SIZE 100

struct VarTable //used to store variable and value
{
	char varName;
	float value;
};

struct VarTable v[10]; // table to store varaibles and its value
int n; //used to maintain count of  no. of variables

float stack[SIZE]; //character stack
int top = -1; //intially stack is empty so index is -1

int isEmpty() {
	if (top == -1)
		return 1;
	else
		return 0;
}

int isFull() {
	if (top == SIZE - 1)
		return 1;
	else
		return 0;
}

void push(float data) {
	if (isFull()) {
		printf("STACK IS FULL \n");
	} else {
		top++;
		stack[top] = data;

	}
}
float pop() {
	float data;
	data = stack[top];
	top--;
	return data;
}

float search(char var) //this function search given variable in table & returns value of it
{
	int i;

	for (i = 0; i < n; i++) {
		if (v[i].varName == var) {
			return v[i].value;
		}
	}

	return (-1); //given var is not found

}

int main() {
	char exp[80];
	int i;
	float opnd1, opnd2, val;

	printf("Enter Postfix Expression : ");
	scanf("%s", exp);

	for (i = 0; exp[i] != '\0'; i++) {
		switch (exp[i]) {
		case '+':
			opnd2 = pop();
			opnd1 = pop();
			push(opnd1 + opnd2);
			break;
		case '-':
			opnd2 = pop();
			opnd1 = pop();
			push(opnd1 - opnd2);
			break;
		case '/':
			opnd2 = pop();
			opnd1 = pop();
			push(opnd1 / opnd2);
			break;
		case '*':
			opnd2 = pop();
			opnd1 = pop();
			push(opnd1 * opnd2);
			break;

		default: //means i'th character is variable
			if (isdigit(exp[i])) {
				push(exp[i] - 48); //bcz '0' has ascci value 48, '1' has 49
			} else {
				val = search(exp[i]);
				if (val == -1) {
					printf("Enter value for variable [%c]:", exp[i]);
					scanf("%f", &v[n].value);
					v[n].varName = exp[i];
					push(v[n].value);
					n++;
				} else {
					push(val);
				}

			}

		} //switch
	} //for

	printf("Postfix Expression :  %s\n", exp);
	printf("Value =%.2f\n", pop());
	return 0;
}

/*		OUTPUT

 [sachin@localhost DS]$ gcc Q8_Eval_postfix.c
 [sachin@localhost DS]$ ./a.out

 Enter Post Expression : ab/cd+*
 Enter value for variable [a]:1
 Enter value for variable [b]:2
 Enter value for variable [c]:3
 Enter value for variable [d]:4

 Postfix Expression :  ab/cd+*
 Value =3.50



 [sachin@localhost DS]$ ./a.out

 Enter Post Expression : 12/34+*
 Postfix Expression :  12/34+*
 Value =3.50

 [sachin@localhost DS]$

 */
