/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<string.h>

struct Emp {
	char name[10];
	float salary;
};

struct Emp e[100]; //array to store 'n' records
int n; //to store no. of records

void accept() {
	int i;

	printf("How many recods you want to store : ");
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		printf("\nAccepting Info for Emp %d\n", i + 1);

		printf("Enter Emp Name :");
		scanf("%s", e[i].name);

		printf("Enter Salary :");
		scanf("%f", &e[i].salary);
	}

}
void display() {
	int i;
	printf("\nEMP NAME \t EMP SALARY\n");

	for (i = 0; i < n; i++) {
		printf("%10s \t %4.2f\n", e[i].name, e[i].salary);
	}

}
int searchByName(char name[]) {
	int i;
	for (i = 0; i < n; i++) {
		if (strcmp(e[i].name, name) == 0) {
			return i; //returnning position i.e index
		}
	}
	return -1;

}
int searchFirstOccurance(float salary) {
	int i;
	for (i = 0; i < n; i++) {
		if (e[i].salary == salary)
			return i;
	}

	return -1;
}

int searchLastOccurance(float salary) {
	int i, pos;
	pos = -1;
	for (i = 0; i < n; i++) {
		if (e[i].salary == salary)
			pos = i;
	}

	return pos;
}

int main() {
	char name[10];
	float salary;
	int pos;

	accept();
	printf("EMP INFORMATION\n");
	display();

	printf("Enter Name to search : ");
	scanf("%s", name);
	pos = searchByName(name);
	if (pos == -1) {
		printf("Record for [%s]  is not found\n ", name);
	} else {
		printf("Record for [%s] is found at [%d] position \n", name, pos);
	}

	printf("Enter Salary : ");
	scanf("%f", &salary);

	pos = searchFirstOccurance(salary);
	if (pos == -1) {
		printf("Record for [%s]  is not found\n ", name);
	} else {
		printf(
				"FIRST OCCURANCE : Record for salary [%f] is found at [%d] position \n",
				salary, pos);
	}

	pos = searchLastOccurance(salary);
	if (pos == -1) {
		printf("Record for [%s]  is not found\n ", name);
	} else {
		printf(
				"LAST OCCURANCE : Record for salary[%f] is found at [%d] position \n",
				salary, pos);
	}

	return 0;
}
