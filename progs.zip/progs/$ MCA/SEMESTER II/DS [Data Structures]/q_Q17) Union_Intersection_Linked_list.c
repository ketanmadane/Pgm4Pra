/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/*
 Write a C program to perform union and intersection on two sorted linked list
 (Accept values in ascending order) to give sorted linked list
 */
#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>

#define NEWNODE (struct node *)malloc(sizeof(struct node))

struct node {
	int data;
	struct node *next;
};

struct node * create(int n) {
	struct node *f, *s, *t;
	int i;
	f = NEWNODE;
	printf("\nENTER THE DATA :");
	scanf("%d", &f->data);
	f->next = NULL;
	s = f;
	for (i = 2; i <= n; i++) {
		t = NEWNODE;
		printf("ENTER THE DATA : ");
		scanf("%d", &t->data);
		t->next = NULL;
		s->next = t;
		s = s->next;
	}
	return f;
}

void display(struct node *f) {
	struct node *s;
	for (s = f; s != NULL; s = s->next) {
		printf(" %d ", s->data);
	}
	printf("\n");
}
int search(struct node *l, int data) {

	while (l != NULL) {
		if (l->data == data)
			return 1;
		l = l->next;
	}

	return 0;

}
struct node * unionLL(struct node *l1, struct node *l2) {
	struct node *f, *s, *t, *l3 = NULL, *last;

	l3 = NEWNODE;
	l3->data = l1->data;
	l3->next = NULL;
	last = l3;
	for (s = l1->next; s != NULL; s = s->next) {
		if (!search(l3, s->data)) {
			t = NEWNODE;
			t->data = s->data;
			t->next = NULL;
			last->next = t;
			last = last->next;
		}
	}

	for (s = l2; s != NULL; s = s->next) {
		if (!search(l3, s->data)) {
			t = NEWNODE;
			t->data = s->data;
			t->next = NULL;
			last->next = t;
			last = last->next;
		}
	}
	return l3;
}
struct node *intersectionLL(struct node *l1, struct node *l2) {
	struct node *l3, *last, *t, *s;

	l3 = NEWNODE;
	l3->data = l1->data;
	l3->next = NULL;
	last = l3;
	for (s = l1->next; s != NULL; s = s->next) {
		if (search(l2, s->data) && !search(l3, s->data)) {

			t = NEWNODE;
			t->data = s->data;
			t->next = NULL;
			last->next = t;
			last = last->next;
		}
	}

	return l3;

}
int main() {
	struct node *l1 = NULL, *l2 = NULL, *l3, *l4;
	int n;

	printf("HOW MANY NODE U WANT TO CREATE  FOR LINKED LIST 1: ");
	scanf("%d", &n);
	l1 = create(n);

	printf("HOW MANY NODE U WANT TO CREATE  FOR LINKED LIST 2: ");
	scanf("%d", &n);
	l2 = create(n);

	printf("Linked List 1 : ");
	display(l1);

	printf("Linked List 2 :");
	display(l2);

	l3 = unionLL(l1, l2);

	printf("Union :");
	display(l3);

	l4 = intersectionLL(l1, l2);
	printf("Intersection : ");
	display(l4);

} //main
/*
 HOW MANY NODE U WANT TO CREATE  FOR LINKED LIST 1: 5
 ENTER THE DATA :1
 ENTER THE DATA : 2
 ENTER THE DATA : 2
 ENTER THE DATA : 3
 ENTER THE DATA : 4

 HOW MANY NODE U WANT TO CREATE  FOR LINKED LIST 2: 6
 ENTER THE DATA :2
 ENTER THE DATA : 3
 ENTER THE DATA : 3
 ENTER THE DATA : 4
 ENTER THE DATA : 5
 ENTER THE DATA : 5

 Linked List 1 :  1  2  2  3  4

 Linked List 2 : 2  3  3  4  5  5

 Union : 1  2  3  4  5

 Intersection :  1  2  3  4
 */
