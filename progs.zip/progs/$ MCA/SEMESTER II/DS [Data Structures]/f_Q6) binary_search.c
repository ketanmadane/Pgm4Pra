/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
void bubblesort(int a[], int n) {
	int i, j, temp;
	;
	for (i = n - 1; i > 0; i--) {
		for (j = 0; j < i; j++) {
			if (a[j + 1] < a[j]) // for decending write condition: a[j+1]>a[j]
					{
				temp = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp;
			}
		}
	}
}

int binarySearch(int a[], int n, int key) {
	int lb, ub, mid;

	lb = 0;
	ub = n - 1;

	while (lb <= ub) {
		mid = (lb + ub) / 2;
		if (a[mid] == key)
			return mid;
		else if (key < a[mid])
			ub = mid - 1;
		else
			lb = mid + 1;
	}

	return -1;

}
void accept(int a[], int n) {
	int i;
	printf("\nACCEPTING %d ELEMENTS\n", n);
	for (i = 0; i < n; i++) {
		printf("Enter number=");
		scanf("%d", &a[i]);
	}
}

void display(int a[], int n) {
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", a[i]);
}

int main() {
	int a[100], n, key, pos;

	printf("\nHow many numbers u want to accept=");
	scanf("%d", &n);

	accept(a, n);

	bubblesort(a, n);

	printf("\nAfter Sort Array is =");
	display(a, n);

	printf("\nEnter data to search :");
	scanf("%d", &key);

	pos = binarySearch(a, n, key);

	if (pos == -1) {
		printf("%d is not found \n", key);
	} else {
		printf("[%d] is found at [%d] position \n", key, pos);
	}

	return 0;
}

