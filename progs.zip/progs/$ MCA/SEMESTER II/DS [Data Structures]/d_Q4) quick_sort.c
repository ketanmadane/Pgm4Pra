/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>

int quicksortcnt = 0; //to count how many times quick_sort() is called

void quick_sort(int[], int, int);
int partition(int[], int, int);

int main() {
	int a[50], n, i;
	printf("\nEnter no of elements :");
	scanf("%d", &n);

	printf("\nEnter array elements \n");
	for (i = 0; i < n; i++) {
		printf("Enter Data :");
		scanf("%d", &a[i]);
	}

	printf("\nUnsorted Data:");
	for (i = 0; i < n; i++)
		printf("%d ", a[i]);

	quicksortcnt++;
	quick_sort(a, 0, n - 1);

	printf("\nSorted array is :");
	for (i = 0; i < n; i++)
		printf("%d ", a[i]);

	printf("\n No. of times quick_sort() is called = %d\n", quicksortcnt);
	return 0;
}

void quick_sort(int a[], int l, int u) {
	int j;
	if (l < u) {
		j = partition(a, l, u);

		quicksortcnt++;
		quick_sort(a, l, j - 1);

		quicksortcnt++;
		quick_sort(a, j + 1, u);
	}
}
int partition(int a[], int l, int u) {
	int pivot, i, j, temp;
	pivot = a[l];
	printf("\nSelected Pivot element= %d", pivot);

	i = l + 1;
	j = u;
	do {
		while (a[i] < pivot && i <= u) {
			i++;
		}

		while (a[j] > pivot) {
			j--;
		}

		if (i < j) {
			temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	} while (i < j);

	a[l] = a[j];
	a[j] = pivot;
	return (j);
}

