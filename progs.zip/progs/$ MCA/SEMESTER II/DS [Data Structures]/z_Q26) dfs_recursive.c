/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/* FINDING DFS OF UNDIRECTED GRAPH */

#include<stdio.h>
#define SIZE 50
int g[SIZE][SIZE], visited[SIZE], n, e; // data structure related to graph

void accept() {
	int i, j, k;
	printf("\nHOW MANY VERTICES YOUR GRAPH HAS= ");
	scanf("%d", &n);
	printf("\nHOW MANY EDGES YOUR GRAPH HAS= ");
	scanf("%d", &e);
	printf("\nACCEPTING EDGES\n");
	for (k = 1; k <= e; k++) {
		printf("\nenter edge in the form of(vi,vj)=");
		scanf("%d%d", &i, &j);
		g[i - 1][j - 1] = 1;
		g[j - 1][i - 1] = 1;
	}
}
/*	DISPLAYING GRAPH 	*/
void display() {
	int i, j;
	printf("\nGRAPH IS = \n\t");
	for (i = 0; i < n; i++) {
		printf("v%d\t", i + 1); // dispplaying header row of matrix i.e V1 V2 V3.... etc
	}
	printf("\n");
	for (i = 0; i < n; i++) {
		printf("v%d\t", i + 1);
		for (j = 0; j < n; j++) {
			printf("%d\t", g[i][j]);
		}
		printf("\n");
	}

}
/*	THIS FUNCTION CHECKS WHEATHER ALL VERTICES ARE VISITED OR NOT	*/
int isvisited() {
	int i;
	for (i = 0; i < n; i++) {
		if (visited[i] == 0)
			return 0;
	}
	return 1;
}
/*	THIS FUNCTION FINDS BFS OF GRAPH	*/
void dfs(int i) {
	int j;
	printf(" V%d ", i + 1);
	visited[i] = 1;

	for (j = 0; j < n; j++) {
		if (g[i][j] == 1 && visited[j] == 0) {
			visited[j] = 1;
			dfs(j);
		}
	}
}

int main() {
	accept(); //accepting graph
	display(); //displaying graph
	printf("\n DFS = ");
	dfs(0);

	if (!isvisited())
		printf("\nGRAPH IS DISCONNECTED!!!");

}
/* OUTPUT 1 :
 * [sachin@localhost graph]$ ./a.out
 *
 * 		HOW MANY VERTICES YOUR GRAPH HAS= 8
 *
 * 		HOW MANY EDGES YOUR GRAPH HAS= 10
 *
 * 		ACCEPTING EDGES
 *
 * 		enter edge in the form of(vi,vj)=1 2
 *
 * 		enter edge in the form of(vi,vj)=1 3
 *
 * 		enter edge in the form of(vi,vj)=2 4
 *
 * 		enter edge in the form of(vi,vj)=2 5
 *
 * 		enter edge in the form of(vi,vj)=3 6
 *
 * 		enter edge in the form of(vi,vj)=3 7
 *
 * 		enter edge in the form of(vi,vj)=4 8
 *
 * 		enter edge in the form of(vi,vj)=5 8
 *
 * 		enter edge in the form of(vi,vj)=6 8
 *
 * 		enter edge in the form of(vi,vj)=7 8
 *
 * 		GRAPH IS = 
 * 				v1	v2	v3	v4	v5	v6	v7	v8	
 * 			v1	0	1	1	0	0	0	0	0	
 * 			v2	1	0	0	1	1	0	0	0	
 * 			v3	1	0	0	0	0	1	1	0	
 * 			v4	0	1	0	0	0	0	0	1	
 * 			v5	0	1	0	0	0	0	0	1	
 * 			v6	0	0	1	0	0	0	0	1	
 * 			v7	0	0	1	0	0	0	0	1	
 * 			v8	0	0	0	1	1	1	1	0	
 *
 * 			 DFS =  V1  V2  V4  V8  V5  V6  V3  V7 
 * OUTPUT 2 :
 * [sachin@localhost graph]$ ./a.out
 *
 * 			 HOW MANY VERTICES YOUR GRAPH HAS= 6
 *
 * 			 HOW MANY EDGES YOUR GRAPH HAS= 5
 *
 * 			 ACCEPTING EDGES
 *
 * 			 enter edge in the form of(vi,vj)=1 2
 *
 * 			 enter edge in the form of(vi,vj)=1 3
 *
 * 			 enter edge in the form of(vi,vj)=2 4
 *
 * 			 enter edge in the form of(vi,vj)=3 4
 *
 * 			 enter edge in the form of(vi,vj)=5 6
 *
 * 			 GRAPH IS = 
 * 				 	v1	v2	v3	v4	v5	v6	
 * 			 	v1	0	1	1	0	0	0	
 * 			 	v2	1	0	0	1	0	0	
 * 			 	v3	1	0	0	1	0	0	
 * 			 	v4	0	1	1	0	0	0	
 * 			 	v5	0	0	0	0	0	1	
 * 			 	v6	0	0	0	0	1	0	
 *
 * 			 	 DFS =  V1  V2  V4  V3 
 * 			 	 GRAPH IS DISCONNECTED!!!
 *
 *
 * */
