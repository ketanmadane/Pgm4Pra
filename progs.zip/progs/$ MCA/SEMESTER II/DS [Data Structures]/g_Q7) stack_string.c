/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<string.h>

#define SIZE 100

char stack[SIZE]; //character stack
int top = -1; //intially stack is empty so index is -1

char data[100][20]; //2-D array to store 'n' strings
int n; //no of string acceptiing

int isEmpty() {
	if (top == -1)
		return 1;
	else
		return 0;
}

int isFull() {
	if (top == SIZE - 1)
		return 1;
	else
		return 0;
}

void push(char ch) {
	if (isFull()) {
		printf("STACK IS FULL \n");
	} else {
		top++;
		stack[top] = ch;

	}
}
char pop() {
	char ch;
	if (isEmpty()) {
		return '\0'; //STACK EMPTY
	} else {
		ch = stack[top];
		top--;
		return ch;
	}
}

void accept() {
	int i;
	printf("How many string you want to accept : ");
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		printf("Enter String :");
		scanf("%s", data[i]);
	}
}
void rev_palindrome() {
	int i, j, flag, cnt = 0;
	char str[10], ch;

	for (i = 0; i < n; i++) {
		strcpy(str, data[i]); //copying i'th string into str

		for (j = 0; str[j] != '\0'; j++) {
			push(str[j]);
		}

		j = 0;
		flag = 1;

		printf("ORIGINAL STRING :%s \t", str);
		printf("REVERSE STRING: ");
		while (ch = pop()) {
			printf("%c", ch);

			if (str[j] != ch) {
				flag = 0;
			}
			j++;
		}
		if (flag == 0)
			printf(" => Its not the palindrome \n");
		else {
			cnt++;
			printf(" => Its Palindrome \n");
		}

	}

	printf("\nNo. of palindrome strings are %d\n", cnt);

}
int main() {

	accept();
	rev_palindrome();
	return 0;
}

