/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */
/*
 Implementing Priority Queue using structure.
 Priority QUEUE is a abstract data type in which the objects are inserted with respect to certain priority.
 In this program, we created the simple ascending order priority queue using the structure,
 */
#include<stdio.h>
#include<stdlib.h>
#define SIZE 5

struct PriorityQ {
	int data;
	int priority;
};

struct PriorityQ pq[SIZE];

int front, rear;

void initQ() {
	front = rear = -1;
	printf("\nPririty Queue Of SIZE=%d is Created !!!\n", SIZE);
}

int isEmpty() {
	if (front == rear)
		return 1;
	else
		return 0;
}

int isFull() {
	if (rear == SIZE - 1)
		return 1;
	else
		return 0;
}

void addQ(int data, int priority) {
	int i;
	if (isFull()) {
		printf("Queue is Full !!!\n");
	} else {
		if (rear == -1) {
			rear++;
			pq[rear].data = data;
			pq[rear].priority = priority;
			return;
		}

		i = rear;
		while (i >= 0 && pq[i].priority >= priority) {
			pq[i + 1] = pq[i];
			i--;
		}
		pq[i + 1].data = data;
		pq[i + 1].priority = priority;
		rear++;
	}

}

struct PriorityQ delQ() {
	struct PriorityQ temp;
	if (isEmpty()) {
		printf("Queue is Empty \n");
		temp.data = -1;
		temp.priority = -1;
		return temp;
	} else {
		front++;
		temp = pq[front];
		return temp;

	}

}

void display() {
	int i;
	printf("Priority Queue : front-> ");
	for (i = front + 1; i <= rear; i++) {
		printf(" [%d,%d] ", pq[i].data, pq[i].priority);
	}
	printf(" <- rear\n");
}
int main() {
	int choice, data, priority;
	struct PriorityQ temp;

	initQ();
	while (1) {
		printf("\n\n1:ADDQ\n2:DELQ\n3:DISPLAY PRIORITY  QUEUE\n4:EXIT\n");
		printf("Enter your choice =");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			printf("Enter Data & priority :");
			scanf("%d %d", &data, &priority);
			addQ(data, priority);
			break;

		case 2:
			temp = delQ();
			if (temp.data != -1 && temp.priority != -1)
				printf("Deleted Data: [Data:%d , Priority=%d]\n ", temp.data,
						temp.priority);
			break;
		case 3:
			display();
			break;
		case 4:
			exit(0);

		default:
			printf("Invalid Choice !!!\n");

		}
	}
}
