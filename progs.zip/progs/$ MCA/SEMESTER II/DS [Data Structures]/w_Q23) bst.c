/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */
/*	Binary Search Tree */

#include<stdio.h>
#include<stdlib.h>

#define NEWNODE (struct node *)malloc(sizeof(struct node))

struct node {
	struct node *left;
	int data;
	struct node *right;
};

struct node *root = NULL;

void bst(int item) {
	struct node *t1, *t2, *t;

	t = NEWNODE;
	t->data = item;
	t->left = NULL;
	t->right = NULL;

	if (root == NULL) {
		root = t;
	} else {
		t1 = root;
		while (t1 != NULL) {
			t2 = t1;

			if (item <= t1->data)
				t1 = t1->left;
			else
				t1 = t1->right;
		}

		if (item <= t2->data)
			t2->left = t;
		else
			t2->right = t;
	}
}
void inorder(struct node *t) {
	if (t != NULL) {
		inorder(t->left);
		printf(" %d ", t->data);
		inorder(t->right);
	}
}
int search(int item) {
	struct node *t1;

	t1 = root;
	while (t1 != NULL) {

		if (t1->data == item)
			return 1;

		if (item <= t1->data)
			t1 = t1->left;
		else
			t1 = t1->right;
	}
	return 0;
}

int main() {
	int n, i, item;
	printf("\nHow many item u want to store =");
	scanf("%d", &n);

	for (i = 1; i <= n; i++) {
		printf("\nEnter data = ");
		scanf("%d", &item);
		bst(item);
	}

	printf("\nDisplaying tree INORDER WISE = ");
	inorder(root);

	printf("\nEnter data to search = ");
	scanf("%d", &item);

	if (search(item) == 1) {
		printf("[%d] is Found !!!\n", item);
	} else {
		printf("[%d] is not Found !!!\n", item);
	}

}
/*
 [sachin@localhost DS]$ gcc Q23_bst.c
 [sachin@localhost DS]$ ./a.out

 How many item u want to store =5
 Enter data = 3
 Enter data = 1
 Enter data = 4
 Enter data = 2
 Enter data = 5

 Displaying tree INORDER WISE =  1  2  3  4  5

 Enter data to search = 3
 [3] is Found !!!

 [sachin@localhost DS]$ ./a.out
 How many item u want to store =5
 Enter data = 2
 Enter data = 5
 Enter data = 1
 Enter data = 3
 Enter data = 4

 Displaying tree INORDER WISE =  1  2  3  4  5

 Enter data to search = 8
 [8] is not Found !!!

 [sachin@localhost DS]$
 */
