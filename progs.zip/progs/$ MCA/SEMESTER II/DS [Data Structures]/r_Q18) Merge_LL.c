/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/*
 Write a c program to merge 2 sorted linked list of strings
 */

#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#include<string.h>
#define NEWNODE (struct node *)malloc(sizeof(struct node))

struct node {
	char str[20];
	;
	struct node *next;
};

struct node * create(int n) {
	struct node *f, *s, *t;
	int i;
	f = NEWNODE;
	printf("ENTER THE STRING :");
	scanf("%s", f->str);
	f->next = NULL;
	s = f;
	for (i = 2; i <= n; i++) {
		t = NEWNODE;
		printf("ENTER THE STRING : ");
		scanf("%s", t->str);
		t->next = NULL;
		s->next = t;
		s = s->next;
	}
	return f;
}

void display(struct node *f) {
	struct node *s;
	for (s = f; s != NULL; s = s->next) {
		printf(" %s ", s->str);
	}
	printf("\n");

}
struct node * sort(struct node *f) {
	struct node *s, *t;
	char temp[20];
	for (s = f; s != NULL; s = s->next) {
		for (t = s->next; t != NULL; t = t->next) {
			if (strcmp(t->str, s->str) < 0) {
				//swaping t with s
				strcpy(temp, t->str);
				strcpy(t->str, s->str);
				strcpy(s->str, temp);
			}
		}
	}
	return f;

}

struct node * merge(struct node *l1, struct node *l2) {

	struct node *l3, *last;
	;

	if (l1 == NULL)
		return l2;
	if (l2 == NULL)
		return l1;

	l3 = last = l1;
	l1 = l1->next;
	last->next = NULL;

	while (l1 != NULL && l2 != NULL) {
		if (strcmp(l1->str, l2->str) < 0) {
			last->next = l1;
			last = last->next;
			l1 = l1->next;
			last->next = NULL;
		} else {
			last->next = l2;
			last = last->next;
			l2 = l2->next;
			last->next = NULL;

		}
	}

	if (l1 != NULL)
		last->next = l1;
	else
		last->next = l2;

	return l3;
}
int main() {
	struct node *l1 = NULL, *l2 = NULL, *l3 = NULL;
	int n;

	printf("HOW MANY NODE U WANT TO CREATE FOR [L1] : ");
	scanf("%d", &n);
	l1 = create(n);

	printf("HOW MANY NODE U WANT TO CREATE FOR [L2] : ");
	scanf("%d", &n);
	l2 = create(n);

	l1 = sort(l1);
	l2 = sort(l2);

	printf(" SORTED LINKED LIST 1= ");
	display(l1);

	printf("SORTED LINKED LIST 2= ");
	display(l2);

	l3 = merge(l1, l2);
	printf("MERGING OF LINKED LIST = ");
	display(l3);

} //main

/*
 
 [sachin@localhost DS]$ gcc sortingOfSinglyLL.c
 [sachin@localhost DS]$ ./a.out

 HOW MANY NODE U WANT TO CREATE FOR [L1] : 5
 ENTER THE STRING :ccc
 ENTER THE STRING : aaa
 ENTER THE STRING : ddd
 ENTER THE STRING : bbb
 ENTER THE STRING : eee

 HOW MANY NODE U WANT TO CREATE FOR [L2] : 3
 ENTER THE STRING :bbb
 ENTER THE STRING : aaa
 ENTER THE STRING : fff

 SORTED LINKED LIST 1=  aaa  bbb  ccc  ddd  eee
 SORTED LINKED LIST 2=  aaa  bbb  fff
 MERGING OF LINKED LIST =  aaa  aaa  bbb  bbb  ccc  ddd  eee  fff
 [sachin@localhost DS]$
 */
