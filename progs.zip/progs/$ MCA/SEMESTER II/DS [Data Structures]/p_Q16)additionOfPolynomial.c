/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<stdlib.h>
#define NEWNODE (struct node *)malloc(sizeof(struct node))
struct node {
	int coeff;
	int pow;
	struct node *next;
};

struct node * create() {
	struct node *f = NULL, *s, *t;
	int ch;
	f = NEWNODE;
	printf("\nEnter coeff & power = ");
	scanf("%d %d", &f->coeff, &f->pow);
	f->next = NULL;
	s = f;
	while (1) {

		printf(
				"\nDo you want to continue..press 1 for continue and 2 to STOP ...= ");
		scanf("%d", &ch);
		if (ch == 2)
			break;

		t = NEWNODE;
		printf("\nEnter coeff & power = ");
		scanf("%d %d", &t->coeff, &t->pow);
		t->next = NULL;
		s->next = t;
		s = s->next;

	}
	return f;
}
struct node * add(struct node *p1, struct node *p2) {
	struct node *p3 = NULL, *l1, *l2, *t, *s;

	l1 = p1;
	l2 = p2;
	while (l1 != NULL && l2 != NULL) {
		t = NEWNODE;
		t->next = NULL;
		if (l1->pow == l2->pow) {
			t->coeff = l1->coeff + l2->coeff;
			t->pow = l1->pow;
			l1 = l1->next;
			l2 = l2->next;
		} else if (l1->pow > l2->pow) {
			t->coeff = l1->coeff;
			t->pow = l1->pow;
			l1 = l1->next;
		} else if (l2->pow > l1->pow) {
			t->coeff = l2->coeff;
			t->pow = l2->pow;
			l2 = l2->next;

		}

		/*	adding node into p3 linked list*/
		if (p3 == NULL) {
			p3 = s = t;
		} else {
			s->next = t;
			s = s->next;
		}
	}
	while (l1 != NULL) {

		t = NEWNODE;

		t->coeff = l1->coeff;
		t->pow = l1->pow;
		l1 = l1->next;

		s->next = t;
		s = s->next;
	}
	while (l2 != NULL) {

		t = NEWNODE;

		t->coeff = l2->coeff;
		t->pow = l2->pow;
		l2 = l2->next;

		s->next = t;
		s = s->next;
	}

	return p3;

}
void display(struct node *f) {
	struct node *s;
	for (s = f; s != NULL; s = s->next) {
		printf("(%dx%d)+", s->coeff, s->pow);
	}
	printf("\b\b\n");
}

int main() {
	struct node *p1, *p2, *p3;
	printf("Accepting First polynimial \n");
	p1 = create();

	printf("Accepting Second polynimial \n");
	p2 = create();

	printf("\nFIRST POLYNOMIAL = ");
	display(p1);

	printf("\nSECOND POLYNOMIAL = ");
	display(p2);

	p3 = add(p1, p2);

	printf("\nSUM OF ABOVE TWO POLYNOMIAL = ");
	display(p3);

}
/*
 Accepting First polynimial

 Enter coeff & power = 3 3
 Do you want to continue..press 1 for continue and 2 to STOP ...= 1
 Enter coeff & power = 2 1
 Do you want to continue..press 1 for continue and 2 to STOP ...= 1
 Enter coeff & power = 5 0
 Do you want to continue..press 1 for continue and 2 to STOP ...= 2

 Accepting Second polynimial
 Enter coeff & power = 2 4
 Do you want to continue..press 1 for continue and 2 to STOP ...= 1
 Enter coeff & power = 4 1
 Do you want to continue..press 1 for continue and 2 to STOP ...= 1
 Enter coeff & power = 7 0
 Do you want to continue..press 1 for continue and 2 to STOP ...= 2

 FIRST POLYNOMIAL = (3x3)+(2x1)+(5x0)+

 SECOND POLYNOMIAL = (2x4)+(4x1)+(7x0)+

 SUM OF ABOVE TWO POLYNOMIAL = (2x4)+(3x3)+(6x1)+(12x0)+

 */
