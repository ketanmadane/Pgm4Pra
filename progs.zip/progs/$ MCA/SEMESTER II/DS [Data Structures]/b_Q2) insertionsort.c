/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<string.h>

struct City {
	char name[10];
	float area;
	int population;
};

struct City c[100]; //array to store 'n' records
int n; //to store no. of records

void accept() {
	int i;

	printf("How many recods you want to store : ");
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		printf("\nAccepting Info for City %d\n", i + 1);

		printf("Enter City Name :");
		scanf("%s", c[i].name);

		printf("Enter area :");
		scanf("%f", &c[i].area);

		printf("Enter population : ");
		scanf("%d", &c[i].population);
	}

}
void display() {
	int i;
	printf("\nCITY NAME \t CITY AREA \t CITY POPULATION \n");

	for (i = 0; i < n; i++) {
		printf("%10s \t %4.2f \t%10d\n", c[i].name, c[i].area, c[i].population);
	}

}
void sortByName() {
	int i, j;
	struct City temp;

	for (i = 1; i < n; i++) {
		temp = c[i];

		for (j = i - 1; j >= 0; j--) {
			if (strcmp(c[j].name, temp.name) > 0) {
				c[j + 1] = c[j];
			} else
				break;
		}
		c[j + 1] = temp;
	}
}

void sortByArea() {
	int i, j;
	struct City temp;

	for (i = 1; i < n; i++) {
		temp = c[i];
		for (j = i - 1; j >= 0; j--) {
			if (c[j].area < temp.area) {
				c[j + 1] = temp;
			} else
				break;
		}
		c[j + 1] = temp;
	}
}

int main() {
	accept();
	sortByName();
	printf("\nDisplaing Data in Descending Order sorted on City Names \n");
	display();

	sortByArea();
	printf("\nDisplaing Data in Asecending Order sorted on City Area \n");
	display();

	return 0;
}
