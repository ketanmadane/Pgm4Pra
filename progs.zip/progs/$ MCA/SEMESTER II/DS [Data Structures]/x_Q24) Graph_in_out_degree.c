/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/* 
 * Write a program to read a graph as adjacency matrix. Calculate indegree,outdegree,and total degree of each vertex.
 */

#include<stdio.h>
#define SIZE 50

int g[SIZE][SIZE], n, e; // data structure related to graph

/*	Accepting directed graph	*/
void accept() {
	int i, j, k;
	printf("\nHOW MANY VERTICES YOUR GRAPH HAS= ");
	scanf("%d", &n);
	printf("\nHOW MANY EDGES YOUR GRAPH HAS= ");
	scanf("%d", &e);
	printf("\nACCEPTING EDGES\n");
	for (k = 1; k <= e; k++) {
		printf("\nenter edge in the form of(vi,vj)=");
		scanf("%d%d", &i, &j);
		g[i - 1][j - 1] = 1;
		//g[j-1][i-1]=1;	// no need of this line in directed graph
	}
}
/*	DISPLAYING GRAPH 	*/
void display() {
	int i, j;
	printf("\nGRAPH IS = \n\t");
	for (i = 0; i < n; i++) {
		printf("v%d\t", i + 1); // dispplaying header row of matrix i.e V1 V2 V3.... etc
	}
	printf("\n");
	for (i = 0; i < n; i++) {
		printf("v%d\t", i + 1);
		for (j = 0; j < n; j++) {
			printf("%d\t", g[i][j]);
		}
		printf("\n");
	}

}
/*	CALCULATING DEGREES	*/
void calc_degree() {
	int in = 0, out = 0, i, j;

	for (i = 0; i < n; i++, in = 0, out = 0) {

		for (j = 0; j < n; j++) {
			if (g[i][j] == 1)
				out++; //incrementing out count for i'th vertex
		}
		for (j = 0; j < n; j++) {
			if (g[j][i] == 1)
				in++; //incrementing in count for j'th vertex
		}
		printf("\nFor Vertex V%d : Indegree=%d Outdegree=%d Total Degree=%d ",
				i + 1, in, out, in + out);
	}

}

int main() {
	int i;
	accept(); //accepting graph
	display(); //displaying graph
	calc_degree();
}
/*
 *
 HOW MANY VERTICES YOUR GRAPH HAS= 3

 HOW MANY EDGES YOUR GRAPH HAS= 4

 ACCEPTING EDGES

 enter edge in the form of(vi,vj)=1 2

 enter edge in the form of(vi,vj)=2 3

 enter edge in the form of(vi,vj)=3 1

 enter edge in the form of(vi,vj)=1 3

 GRAPH IS =
 v1	v2	v3
 v1	0	1	1
 v2	0	0	1
 v3	1	0	0

 For Vertex V1 : Indegree=1 Outdegree=2 Total Degree=3
 For Vertex V2 : Indegree=1 Outdegree=1 Total Degree=2
 For Vertex V3 : Indegree=2 Outdegree=1 Total Degree=3

 */
