/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<stdlib.h>
#define SIZE 5

int DQ[SIZE];

int front, rear;

void initQ() {
	front = rear = 0;
}

void addQ_rear(int data) {
	int i;
	if (((rear + 1) % SIZE) == front) {
		printf("Queue is Full !!!\n");
	} else if (rear == -1) {
		rear = 0;
		DQ[rear] = data;
	} else {
		//	DQ[rear]=data;
		rear = (rear + 1) % SIZE;
		DQ[rear] = data;
	}

}
void addQ_front(int data) {
	int i;
	if (rear == SIZE - 1 && front == 0) {
		printf("Queue is Full !!!\n");

		return;
	}

	if (((front + SIZE - 1) % SIZE) == rear) {
		printf("Queue is Full !!!\n");
	} else if (front == 0) {
		front = SIZE - 1;
		DQ[front] = data;
		//front=SIZE-1;
	} else {
		front = (front + SIZE - 1) % SIZE;
		DQ[front] = data;
	}

}

int delQ_front() {
	int data;

	if ((front == rear)) {
		printf("Queue is Empty \n");
		front = rear = 0;
		return -1;
	} else {
		if (DQ[front] != 0) {
			data = DQ[front];
			DQ[front] = 0;
			front = (front + 1) % SIZE;
			return data;
		}
		front = (front + 1) % SIZE;
		data = DQ[front];
		DQ[front] = 0;
		return data;
	}

}
int delQ_rear() {
	int data;

	if ((front == rear)) {
		printf("Queue is Empty \n");
		front = rear = 0;
		return -1;
	} else {
		data = DQ[rear];
		DQ[rear] = 0;

		rear = (rear + SIZE - 1) % SIZE;

		return data;
	}

}

void display() {
	int i = front;

	printf("Double Ended Queue : front-> ");
	for (; i != rear; i = (i + 1) % SIZE)
	{
		if (DQ[i] != 0)
			printf(" [%d] ", DQ[i]);
	}
	if (DQ[i] != 0)
		printf(" [%d] <- rear\n", DQ[i]);
	else
		printf(" <-rear\n", DQ[i]);
}
int main() {
	int choice, data;

	initQ();

	while (1) {
		printf(
				"\n\n1:ADDQ REAR \n2:ADDQ FRONT\n3:DELQ REAR \n4:DELQ FRONT \n5:DISPLAY DOUBLE ENDED  QUEUE\n6:EXIT\n");
		printf("Enter your choice =");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			printf("Enter Data to add at rear side :");
			scanf("%d", &data);
			addQ_rear(data);
			break;

		case 2:
			printf("Enter Data to add at front side :");
			scanf("%d", &data);
			addQ_front(data);
			break;

		case 3:
			data = delQ_rear();
			if (data != -1)
				printf("Deleted Data: [Data:%d ]\n ", data);
			break;

		case 4:
			data = delQ_front();
			if (data != -1)
				printf("Deleted Data: [Data:%d ]\n ", data);
			break;

		case 5:
			display();
			break;
		case 6:
			exit(0);

		default:
			printf("Invalid Choice !!!\n");

		}
	}
}
