/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/*
 MENU DRIVEN PROGRAM FOR SINGLY LINKED LIST OF STRING
 1)CREATE A SINGLY LINKED LIST OF 'n' STRINGS
 2)DISPLAY SINGLY LINKED LIST
 3)INSERT NODE AT FIRST POSITION
 4) SEARCH STRING FROM LINKED LIST RETURNS POSITION
 */
#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>

#define NEWNODE (struct node *)malloc(sizeof(struct node))

struct node {
	int data[20];
	struct node *next;
};

struct node * create(int n) {
	struct node *f, *s, *t;
	int i;
	f = NEWNODE;
	printf("ENTER THE DATA :");
	scanf("%s", f->data);
	f->next = NULL;
	s = f;
	for (i = 2; i <= n; i++) {
		t = NEWNODE;
		printf("ENTER THE DATA : ");
		scanf("%s", t->data);
		t->next = NULL;
		s->next = t;
		s = s->next;
	}
	return f;
}

void display(struct node *f) {
	struct node *s;
	for (s = f; s != NULL; s = s->next) {
		printf(" %s ", s->data);
	}
	printf("\n");
}
struct node * insert(struct node *f) {
	struct node* s, *t;
	int i;
	t = NEWNODE;
	printf("ENTER THE DATA : ");
	scanf("%s", t->data);
	t->next = NULL;
	if (f == NULL) {
		return t;
	} else {
		t->next = f;
		f = t;
		return f;
	}
}
int search(struct node *f, char str[]) {
	struct node *s;
	int cnt = 1;
	for (s = f; s != NULL; s = s->next, cnt++) {
		if (strcmp(s->data, str) == 0)
			return cnt;

	}

	return -1;

}
int main() {
	struct node *head = NULL;
	int choice, pos, n;
	char s[20];
	while (1) {
		//	system("clear");// this is standered liabrary function which  clears the screen.

		printf(
				"\nMENU\n1:CREATE SINGLY LINKED LIST\n2:DISPLAY SINGLY LINKED LIST\n3:INSERTING NODE AT FIRST POSITION OF LINKED LIST\n4:SEARCH THE STRING FROM LINKED LIST\n5:EXIT");
		printf("\nENTER YOUR CHOICE : ");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			printf("\nHOW MANY NODE U WANT TO CREATE : ");
			scanf("%d", &n);
			head = create(n);
			printf("\nLINKED LIST OF %d NODES IS CREATED SUCCESFULLY\n", n);
			break;

		case 2:
			printf("\nLINKED LIST = ");
			display(head);
			break;

		case 3:
			head = insert(head);
			break;

		case 4:
			printf("ENTER  STRING FOR SEARCH : ");
			scanf("%s", s);
			pos = search(head, s);

			if (pos <= 0)
				printf("[%s] is not found !!!\n", s);
			else
				printf("[%s] is found at [%d] position \n", s, pos);
			break;

		case 5:
			exit(0);
		default:
			printf("INVALID CHOICE,Please RE-ENTER AGAIN\n");

		} //switch
	} //while
} //main
