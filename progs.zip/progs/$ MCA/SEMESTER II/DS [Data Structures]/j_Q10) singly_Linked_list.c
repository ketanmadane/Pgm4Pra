/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/*
 MENU DRIVEN PROGRAM FOR SINGLY LINKED LIST
 1)CREATE A SINGLY LINKED LIST
 2)DISPLAY SINGLY LINKED LIST
 3)INSERT NODE AT GIVEN POSITION
 4)DLELETE NODE FROM GIVEN POSITION IN LINKED LIST
 */
#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>

#define NEWNODE (struct node *)malloc(sizeof(struct node))

struct node {
	int data;
	struct node *next;
};

struct node * create(int n) {
	struct node *f, *s, *t;
	int i;
	f = NEWNODE;
	printf("\nENTER THE DATA :");
	scanf("%d", &f->data);
	f->next = NULL;
	s = f;
	for (i = 2; i <= n; i++) {
		t = NEWNODE;
		printf("\nENTER THE DATA : ");
		scanf("%d", &t->data);
		t->next = NULL;
		s->next = t;
		s = s->next;
	}
	return f;
}

void display(struct node *f) {
	struct node *s;
	for (s = f; s != NULL; s = s->next) {
		printf(" %d ", s->data);
	}

}
struct node * insert(struct node *f, int pos) {
	struct node* s, *t;
	int i;
	t = NEWNODE;
	printf("\nENTER THE DATA : ");
	scanf("%d", &t->data);
	t->next = NULL;
	if (pos == 1) {
		t->next = f;
		f = t;
		return f;
	} else {
		s = f;
		for (i = 1; i <= pos - 2 && s != NULL; i++) {
			s = s->next;
		}
		if (s == NULL) {
			printf("\nERROR : INVALID POSITION");
			return f;
		}
		t->next = s->next;
		s->next = t;
		return f;
	}
}
struct node * delete(struct node *f, int pos) {
	struct node *s, *t;
	int i;
	if (pos == 1) {
		t = f;
		f = f->next;
		free(t);
		return f;
	} else {
		s = f;
		for (i = 1; i <= pos - 2 && s != NULL; i++) {
			s = s->next;
		}
		if (s == NULL) {
			printf("\nERROR : INVALID POSITION");
			return f;
		}
		t = s->next;
		s->next = t->next;
		free(t);
		return f;
	}
}

int main() {
	struct node *head;
	int choice, pos, n;

	while (1) {
		//	system("clear");// this is standered liabrary function which  clears the screen.

		printf(
				"\nMENU\n1:CREATE SINGLY LINKED LIST\n2:DISPLAY SINGLY LINKED LIST\n3:INSERTING NODE AT GIVEN POSITION OF LINKED LIST\n4:DELETING NODE FROM GIVEN POSITION OF THE LINKED LIST\n5:EXIT");
		printf("\nENTER YOUR CHOICE : ");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			printf("\nHOW MANY NODE U WANT TO CREATE : ");
			scanf("%d", &n);
			head = create(n);
			printf("\nLINKED LIST OF %d NODES IS CREATED SUCCESFULLY\n", n);
			break;

		case 2:
			printf("\nLINKED LIST = ");
			display(head);
			break;

		case 3:
			printf("\nENTER POSITION FOR INSERTION : ");
			scanf("%d", &pos);
			head = insert(head, pos);
			break;
		case 4:
			printf("\nENTER POSITION FOR DELETION : ");
			scanf("%d", &pos);
			head = delete(head, pos);
			break;
		case 5:
			exit(0);
		default:
			printf("\nINVALID CHOICE,Please RE-ENTER AGAIN");

		} //switch
	} //while
} //main
