/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>

struct node {
	int data;
	struct node *next;

};

struct node *front, *rear;

initQ() {
	front = NULL;
	rear = NULL;

}

void addQ(int num) {
	struct node *t;

	t = (struct node*) malloc(sizeof(struct node));
	if (t == NULL) {
		printf("Queue is Overflow !!!!\n");
		return;
	}

	t->data = num;
	t->next = NULL;

	if (rear == NULL) {
		front = t;
		rear = t;
		rear->next = front;
	} else {
		rear->next = t;
		rear = rear->next;
		rear->next = front;
	}

	printf("Data is added in queue successfuly !!!!\n");

}

int delQ() {
	struct node *t;
	int num;

	num = front->data;
	if (front->next == front) //if one node left in list
			{
		free(front);
		front = rear = NULL;
		return num;
	}

	t = front;
	front = front->next;

	rear->next = front;

	free(t);
	return num;

}
int main() {
	int choice, num;

	initQ();
	while (1) {
		printf("\n\n1:ADDQ\n2:DELQ\n3:EXIT\n");
		printf("Enter your choice =");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			printf("Enter Data to ADD :");
			scanf("%d", &num);
			addQ(num);
			break;

		case 2:
			if (front == NULL) {
				printf("Queue is Empty !!!\n");
			} else {
				num = delQ();
				printf("Deleted Data: %d\n", num);
			}
			break;
		case 3:
			exit(0);

		default:
			printf("INnvalid Choice !!!\n");

		}
	}
}
