/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>
#include<string.h>

struct node {
	struct node *prev;
	char str[10];
	struct node *next;

};

struct node *top;

initStack() {
	top = NULL;

}

void push(char str[]) {
	struct node *t;

	t = (struct node*) malloc(sizeof(struct node));
	if (t == NULL) {
		printf("Stack is Overflow !!!!\n");
		return;
	}

	strcpy(t->str, str);
	t->next = t->prev = NULL;

	if (top == NULL) {
		top = t;
	} else {
		top->next = t;
		t->prev = top;
		top = top->next;
	}

	printf("Data is pushed successfuly !!!!\n");

}

void pop() {
	struct node *t;

	printf("Popped String : %s\n", top->str);
	t = top;
	top = top->prev;

	if (top != NULL)
		top->next = NULL;
	free(t);

}
int main() {
	int choice;
	char str[10];
	initStack();

	while (1) {
		printf("\n\n1:PUSH\n2:POP\n3:EXIT\n");
		printf("Enter your choice =");
		scanf("%d", &choice);

		switch (choice) {
		case 1:
			printf("Enter String to Push :");
			scanf("%s", str);
			push(str);
			break;

		case 2:
			if (top == NULL) {
				printf("Stack is Empty !!!\n");
			} else {
				pop();
			}
			break;
		case 3:
			exit(0);

		default:
			printf("INnvalid Choice !!!\n");

		}
	}
}
