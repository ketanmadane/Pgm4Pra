/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/* FINDING BFS OF GRAPH	*/

#include<stdio.h>
#define SIZE 50
int g[SIZE][SIZE], visited[SIZE], n, e; // data structure related to graph
int queue[SIZE], front = -1, rear = -1;
/* 	  CODE FOR QUEUE		*/
int isempty() {
	return front == rear;
}
int isfull() {
	return rear == SIZE - 1;
}
void addq(int item) {
	if (isfull())
		printf("\nERROR: QUEUE IS FULL!!!");
	else {
		queue[++rear] = item;
	}
}
int delq() {
	if (isempty())
		printf("\nERROR : QUEUE IS EMPTY!!! ");
	else {
		return queue[++front];
	}
}
/*	ACCEPTING GRAPH IN ADJECENCY MATRIX	 */
void accept() {
	int i, j, k;
	printf("\nHOW MANY VERTICES YOUR GRAPH HAS= ");
	scanf("%d", &n);
	printf("\nHOW MANY EDGES YOUR GRAPH HAS= ");
	scanf("%d", &e);
	printf("\nACCEPTING EDGES\n");
	for (k = 1; k <= e; k++) {
		printf("\nenter edge in the form of(vi,vj)=");
		scanf("%d%d", &i, &j);
		g[i - 1][j - 1] = 1;
		g[j - 1][i - 1] = 1;
	}
}
/*	DISPLAYING GRAPH 	*/
void display() {
	int i, j;
	printf("\nGRAPH IS = \n\t");
	for (i = 0; i < n; i++) {
		printf("v%d\t", i + 1); // dispplaying header row of matrix i.e V1 V2 V3.... etc
	}
	printf("\n");
	for (i = 0; i < n; i++) {
		printf("v%d\t", i + 1);
		for (j = 0; j < n; j++) {
			printf("%d\t", g[i][j]);
		}
		printf("\n");
	}

}
/*	THIS FUNCTION CHECKS WHEATHER ALL VERTICES ARE VISITED OR NOT	*/
int isvisited() {
	int i;
	for (i = 0; i < n; i++) {
		if (visited[i] == 0)
			return 0;
	}
	return 1;
}
/*	THIS FUNCTION FINDS BFS OF GRAPH	*/
void bfs() {
	int i = 0, j;
	printf("\n BFS = V%d ", i + 1);
	visited[i] = 1;
	addq(i);
	while ((!isvisited()) && (!isempty())) // this condition is for disconnected graph i.e for disconnected graph all vettices may not be visited but queue will be empty
	{
		i = delq();
		for (j = 0; j < n; j++) {
			if (g[i][j] == 1 && visited[j] == 0) {
				printf("V%d ", j + 1);
				visited[j] = 1;
				addq(j);
			}
		}
	}
	if (!isvisited())
		printf("\nGRAPH IS DISCONNETCTED!!!!!!!!!!");

}
int main() {
	accept(); //accepting graph
	display(); //displaying graph
	bfs();

}
