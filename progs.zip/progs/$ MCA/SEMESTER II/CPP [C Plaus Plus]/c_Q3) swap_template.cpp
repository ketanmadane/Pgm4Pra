/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
using namespace std;

template<class t>
void swap_temp(t &p, t &q) {

	t temp;
	temp = p;
	p = q;
	q = temp;
}

class A {
	int i;
	float f;

public:
	A(int a = 0, float b = 0.0) {
		i = a;
		f = b;
	}
	void display() {
		cout << "i=" << i << "  f=" << f << endl;
	}

};

int main() {
	//Swapping of int 

	int a = 10, b = 20;
	cout << "Before swap integers are : " << a << "  " << b << endl;
	swap_temp(a, b);
	cout << "After swap integers are : " << a << "  " << b << endl;

	//Swapping of floats

	float x = 1.5, y = 2.5;
	cout << "Before swap floats are : " << x << "  " << y << endl;
	swap_temp(x, y);
	cout << "After swap floats are : " << x << "  " << y << endl;

	//swapping of Objects

	A ob1(1, 2.7), ob2(3, 4.7);
	cout << "Before swap Object1 members : ";
	ob1.display();

	cout << "Before swap Object2 members : ";
	ob2.display();

	swap(ob1, ob2);

	cout << "After swap Object1 members : ";
	ob1.display();

	cout << "After swap Object2 members : ";
	ob2.display();

}

/*
 [sachin@localhost CPP]$ g++ Q3_swap_template.cpp
 [sachin@localhost CPP]$ ./a.out

 Before swap integers are : 10  20
 After swap integers are : 20  10

 Before swap floats are : 1.5  2.5
 After swap floats are : 2.5  1.5


 Before swap Object1 members : i=1  f=2.7
 Before swap Object2 members : i=3  f=4.7

 After swap Object1 members : i=3  f=4.7
 After swap Object2 members : i=1  f=2.7
 */
