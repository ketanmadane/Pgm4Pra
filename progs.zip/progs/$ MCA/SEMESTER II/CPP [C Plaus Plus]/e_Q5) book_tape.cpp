/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<stdlib.h>
using namespace std;

class Publication {
	char title[10];
	double price;

public:
	void accept() {
		cout << "Enter title :";
		cin >> title;

		cout << "Enter Price :";
		cin >> price;
	}
	void display() {
		cout << title << "\t" << price << "\t";
	}
};
class Book: public Publication {
	int pagecnt;
public:
	void accept() {
		Publication::accept();
		cout << "Enter page count:";
		cin >> pagecnt;
	}
	void display() {
		Publication::display();
		cout << pagecnt << endl;
	}
	void display(int n) {
		if (pagecnt > n) {
			Publication::display();
			cout << pagecnt << endl;
		}
	}

};

class Tape: public Publication {
	int playtime;
public:
	void accept() {
		Publication::accept();
		cout << "Enter Playing time in minutes:";
		cin >> playtime;
	}
	void display() {
		Publication::display();
		cout << playtime << endl;
	}
	void display(int n) {
		if (playtime >= n) {
			Publication::display();
			cout << playtime << endl;
		}
	}

};

int main() {
	int n;

	cout << "How many Object of 'Book' you want to create :";
	cin >> n;

	Book b[n];

	cout << "Accepting books information \n";

	for (int i = 0; i < n; i++) {
		b[i].accept();
	}

	cout << "How many Object of 'Tape' you want to create :";
	cin >> n;

	Tape t[n];

	cout << "Accepting books information \n";

	for (int i = 0; i < n; i++) {
		t[i].accept();
	}

	int choice, num;

	while (true) {
		cout
				<< "MENU\n 1:DISPLAY ALL BOOKS \n 2:DISPLAY ALL TAPES \n 3:ALL BOOKS HAVING PAGES > n \n 4: ALL TAPES HAVING PLAYING TIME >= n minutes \n 5:EXIT\n";
		cout << "Enter Your choice : ";
		cin >> choice;

		switch (choice) {
		case 1:
			cout << "\nTITLE\tPRICE\tPAGECNT\n";
			for (int i = 0; i < n; i++) {
				b[i].display();
			}
			break;

		case 2:
			cout << "\nTITLE\tPRICE\tPLAYING TIME\n";
			for (int i = 0; i < n; i++) {
				t[i].display();
			}
			break;

		case 3:
			cout << "Enter value of n to show book having no. of pages > n =";
			cin >> num;
			cout << "\nTITLE\tPRICE\tPAGECNT\n";
			for (int i = 0; i < n; i++) {
				b[i].display(num);
			}
			break;
		case 4:

			cout << "Enter value of n to show tape having playing time >= n =";
			cin >> num;
			cout << "\nTITLE\tPRICE\tPLAYING TIME\n";
			for (int i = 0; i < n; i++) {
				t[i].display(num);
			}
			break;
		case 5:
			exit(0);
		default:
			cout << "Invalid choice !!!!\n";

		} //switch
	} //while
}
