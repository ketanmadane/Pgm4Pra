/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<string.h>
using namespace std;

class Cricket {

	int code;
	char name[10];
	int runs, innings, notout;

public:
	void accept() {
		cout << "Enter Player Code:";
		cin >> code;
		cout << "Enter Name:";
		cin >> name;
		cout << "Enter Total Runs :";
		cin >> runs;
		cout << "Enter total innings played :";
		cin >> innings;
		cout << "Enter no. of times notout : ";
		cin >> notout;
	}
	void display() {
		cout << code << "\t" << name << "\t" << runs << "\t" << innings << "\t"
				<< notout << endl;
	}
	void dispAvg(char n[]) {
		if (strcmp(name, n) == 0) {
			float avg = (float) runs / (innings - notout);
			cout << "Player Name:" << n << "\t Average Runs:" << avg;
		}
	}

};

int main() {
	int n;
	char name[10];

	cout << "how many objects you want to create :";
	cin >> n;

	Cricket ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].accept();
	}

	cout << "\n\nCode\tName\tRuns\tInnings\tNot_Out\n";

	for (int i = 0; i < n; i++) {
		ob[i].display();
	}

	cout << "Enter Player Name to display Avrage Runs:";
	cin >> name;

	for (int i = 0; i < n; i++) {
		ob[i].dispAvg(name);
	}

	return 0;

}
