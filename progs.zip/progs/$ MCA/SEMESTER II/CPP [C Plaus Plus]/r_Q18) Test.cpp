/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
using namespace std;

class Test {
	int testCode;
	char description[30];
	int noOfcandidate;
	int centerReq;

public:
	void shedule() {
		cout << "Enter test code:";
		cin >> testCode;

		cout << "Enter Description :";
		cin >> description;

		cout << "Enter no. of candidates :";
		cin >> noOfcandidate;

		calcntr();
	}
	void calcntr() {
		centerReq = noOfcandidate / 100 + 1;
	}

	void dispTest() {
		cout << testCode << "\t\t" << description << "\t" << noOfcandidate
				<< "\t" << centerReq << endl;
	}
};
int main() {
	int n;
	cout << "how many objects you want to create :";
	cin >> n;

	Test ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].shedule();
	}

	cout << "Code\tDescription\tNo_Of_Candidate\tCenter_Requirement\n";

	for (int i = 0; i < n; i++) {
		ob[i].dispTest();
	}
	return 0;
}
