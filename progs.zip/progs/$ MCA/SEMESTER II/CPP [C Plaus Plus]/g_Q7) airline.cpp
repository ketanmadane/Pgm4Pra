/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<string.h>
using namespace std;

class Airline {
	int fno;
	char origin[4], dest[4];
	char atime[10], dtime[10];

public:

	void accept() {
		cout << "Enter flight num: ";
		cin >> fno;

		cout << "Enter Originating airport code (3 characters ) : ";
		cin >> origin;

		cout << "Enter Destination airport code (3 characters ) : ";
		cin >> dest;

		cout << "Enter departure time :";
		cin >> dtime;

		cout << "Enter Arrival Time :";
		cin >> atime;

	}

	void display(char code[]) {
		if (strcmp(code, origin) == 0) {
			cout << fno << "\t" << origin << "\t" << dest << "\t" << atime
					<< "\t" << dtime << endl;
		}

	}

};

int main() {
	int n;
	char code[4];
	cout << "How many object you want to create :";
	cin >> n;

	Airline ob[n];

	cout << "Accepting Information" << endl;

	for (int i = 0; i < n; i++) {
		ob[i].accept();
	}

	cout << "Enter Airport (3 characters) to list all planes = ";
	cin >> code;

	cout << "Flignt no\tOrigin\tDestination\t Departure \t Arrival\n";
	for (int i = 0; i < n; i++) {
		ob[i].display(code);
	}

}
/*
 *
 How many object you want to create :4
 Accepting Information
 Enter flight num: 1
 Enter Originating airport code (3 characters ) : pun
 Enter Destination airport code (3 characters ) : mum
 Enter departure time :7:15
 Enter Arrival Time :9:02

 Enter flight num: 2
 Enter Originating airport code (3 characters ) : pun
 Enter Destination airport code (3 characters ) : hyd
 Enter departure time :14:12
 Enter Arrival Time :20:15

 Enter flight num: 3
 Enter Originating airport code (3 characters ) : mum
 Enter Destination airport code (3 characters ) : dlh
 Enter departure time :8:30
 Enter Arrival Time :18:10

 Enter flight num: 4
 Enter Originating airport code (3 characters ) : mum
 Enter Destination airport code (3 characters ) : pun
 Enter departure time :10:00
 Enter Arrival Time :11:45

 Enter Airport (3 characters) to list all planes = pun

 Flignt no	Origin	Destination	 Departure 	 Arrival
 1		pun	mum			9:02	7:15
 2		pun	hyd			20:15	14:12

