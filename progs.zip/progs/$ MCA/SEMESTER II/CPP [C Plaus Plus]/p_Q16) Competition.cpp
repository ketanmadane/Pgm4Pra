/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<string.h>
using namespace std;

class Competition {
	int event_no;
	char description[30];
	int score;
	char qualified;

public:
	Competition(int eno = 101, const char desc[] = "State Level", int sc = 50,
			char q = 'N') {
		event_no = eno;
		strcpy(description, desc);
		score = sc;
		qualified = q;
	}
	void input() {
		cout << "Enter Event num:";
		cin >> event_no;
		cout << "Enter Description:";
		cin >> description;
		cout << "Enter Score :";
		cin >> score;

		qualified = '-'; //will set in award function
	}

	void award(int n) {
		if (score > n)
			qualified = 'Y';
		else
			qualified = 'N';
	}
	void show() {
		cout << event_no << "\t" << description << "\t" << score << "\t"
				<< qualified << endl;
	}
};

int main() {
	int n, cutoff;
	cout << "how many objects you want to create :";
	cin >> n;

	Competition ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].input();
	}

	cout << "\n\nEnter cutoff to make qualification :";
	cin >> cutoff;

	for (int i = 0; i < n; i++) {
		ob[i].award(cutoff);
	}

	cout << "Event_no\tDescription\tScore\tQualified\n";

	for (int i = 0; i < n; i++) {
		ob[i].show();
	}
	return 0;
}

