/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
using namespace std;

class Emp {
	int code;
	char name[10], desg[10];

public:
	void accept() {
		cout << "Enter code :";
		cin >> code;
		cout << "Enter name :";
		cin >> name;
		cout << "Enter Designation :";
		cin >> desg;
	}
	void display() {
		cout << code << "\t" << name << "\t" << desg << "\t";
	}
};

class Manager: public Emp {
	int exp;
	double salary;

public:
	void accept() {
		Emp::accept();
		cout << "Year of Experiance :";
		cin >> exp;
		cout << "Salary :";
		cin >> salary;
	}
	void display() {
		Emp::display();
		cout << exp << "\t" << salary << endl;
	}
};
int main() {
	int n;
	cout << "how many objects you want to create :";
	cin >> n;

	Manager ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].accept();
	}

	cout << "Code\tName\tDesg.\tExperiance\tSalary\n";

	for (int i = 0; i < n; i++) {
		ob[i].display();
	}
	return 0;
}
