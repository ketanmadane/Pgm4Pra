/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class shape {

	float v1, v2;
public:
	shape(float a = 0.0, float b = 0.0) {
		v1 = a;
		v2 = b;
	}
	float get_data() {
		return v1 * v2;
	}
	virtual void display_area()=0;
};

class circle: public shape {
	float ans;

public:
	circle(float r = 0.0) :
			shape(r, r) {
		ans = 0.0;
	}
	void display_area() {
		ans = 3.14 * shape::get_data();
		cout << "Area of Circle:" << ans << endl;
	}

};
class sphere: public shape {
	float ans;

public:
	sphere(float r) :
			shape(r * r, r) {
		ans = 0.0;
	}
	void display_area() {
		ans = (4.0 / 3.0) * shape::get_data();
		cout << "Area of Sphere :" << ans << endl;
	}

};

int main() {

	float r;
	shape *p = NULL;

	cout << "Enter radius for circle:";
	cin >> r;

	p = new circle(r);
	p->display_area();
	delete p;

	cout << "Enter radius for Sphere :";
	cin >> r;

	p = new sphere(r);
	p->display_area();
	delete p;

}
