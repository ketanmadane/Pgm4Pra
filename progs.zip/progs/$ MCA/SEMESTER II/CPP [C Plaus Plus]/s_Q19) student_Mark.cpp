/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<string.h>
using namespace std;

class Student {
	int rno;
	char name[10];
	char cls[10];

public:

	void accept() {
		cout << "Enter Roll num:";
		cin >> rno;

		cout << "Enter Name:";
		cin >> name;

		cout << "Enter Class:";
		cin >> cls;
	}
	void display() {
		cout << rno << "\t" << name << "\t" << cls << "\t";
	}
};

class Marks {
	int m[3];
public:
	void accept() {
		for (int i = 0; i < 3; i++) {
			cout << "Enter marks for subject " << (i + 1) << ":";
			cin >> m[i];
		}
	}
	int sum() {
		int s = 0;
		for (int i = 0; i < 3; i++) {
			s = s + m[i];
		}
		return s;
	}
	void display() {
		cout << m[0] << "\t" << m[1] << "\t" << m[2] << "\t";
	}
};

class Result: public Student, public Marks {
	float per;
	char grade[20];

public:
	void accept() {
		Student::accept();
		Marks::accept();

		per = sum() / 3;

		if (per > 70)
			strcpy(grade, "Distinction");
		else if (per > 60)
			strcpy(grade, "First Class");
		else if (per > 50)
			strcpy(grade, "Second Class");
		else if (per > 40)
			strcpy(grade, "Pass");
		else
			strcpy(grade, "Fail");
	}
	void display() {
		Student::display();
		Marks::display();
		cout << per << "\t" << grade << endl;
	}
};
int main() {
	int n;
	cout << "how many objects you want to create :";
	cin >> n;

	Result ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].accept();
	}

	cout << "Rno\tName\tclass\tMark1\tmark2\tmark3\tPer\tGrade\n";

	for (int i = 0; i < n; i++) {
		ob[i].display();
	}
	return 0;
}
