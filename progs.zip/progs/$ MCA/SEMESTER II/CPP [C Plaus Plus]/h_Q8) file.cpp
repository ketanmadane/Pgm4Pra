/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<fstream>
#include<string.h>

using namespace std;

bool isAllCaps(char word[]) //this function checks wheather all characters in words are capital or not
		{
	for (int i = 0; word[i] != '\0'; i++) {
		if (word[i] < 'A' || word[i] > 'Z')
			return false;
	}

	return true;
}

void copyupper() {
	ifstream fr("first.txt"); //opening file for reading
	ofstream fw("second.txt"); //opening file for writng
	char str[80];

	while (fr >> str) {
		if (isAllCaps(str))
			fw << str << " ";

	}

	fr.close();
	fw.close();
}
void display(const char fn[]) {
	ifstream fr(fn);
	char ch;
	while (fr.get(ch)) {
		cout << ch;
	}
	fr.close();
}

int main() {
	char str[30];
	copyupper();

	cout << "Contents of first.txt" << endl;
	display("first.txt");

	cout << "\n\nContents of second.txt" << endl;
	display("second.txt");

	cout << endl;
}
/*
 [sachin@localhost CPP]$ g++ Q8_file.cpp
 [sachin@localhost CPP]$ ./a.out

 Contents of first.txt
 AAAA bbbb CCC
 DDD eee FFF
 123 !@#&


 Contents of second.txt
 AAAA CCC DDD FFF

 [sachin@localhost CPP]$

 *
 */

