/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<fstream>
#include<string.h>
#define MAXSIZE 20
using namespace std;

class CFile {
	fstream fp;
	char fn[MAXSIZE];

public:
	CFile(char *fname) {
		strcpy(fn, fname);
	}

	void display() {
		fp.open(fn, ios::in);
		if (!fp) {
			cout << "Unbale to open file for reading !!!\n";
			return;
		}

		char ch;
		while ((ch = fp.get()) != EOF) {
			cout << ch;
		}
		fp.close();

	}

	void operator -() {
		ofstream fob("temp.txt");
		fp.open(fn, ios::in);
		if (!fp) {
			cout << "Unbale to open file for reading !!!\n";
			return;
		}

		char ch;
		while ((ch = fp.get()) != EOF) {
			if (ch >= 'A' && ch <= 'Z')
				fob.put(ch + 32);
			else if (ch >= 'a' && ch <= 'z')
				fob.put(ch - 32);
			else
				fob.put(ch);
		}
		fp.close();
		fob.close();
		rename("temp.txt", fn);

	}
};

int main() {
	char fname[10], ch;

	cout << "Enter File Name which contains data :"; //e.g a.txt should be there with data
	cin >> fname;

	CFile ob(fname);
	cout << "\n\nFiles contains Data Before changing case" << endl;
	ob.display();

	-ob; //calling operator function

	cout << "\n\nFile Contains data after changing case " << endl;
	ob.display();

}
/*
 *
 [sachin@localhost CPP]$ ./a.out

 Enter File Name:a.txt

 Files contains Data
 AAAAAA
 bbbbbb
 123!@#

 File Contains data after changing case
 aaaaaa
 BBBBBB
 123!@#

 */

