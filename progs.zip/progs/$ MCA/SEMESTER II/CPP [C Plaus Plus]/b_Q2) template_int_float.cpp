/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<math.h>
using namespace std;
template<class t>
void read(t a[], int n) {
	for (int i = 0; i < n; i++) {
		cout << "Enter num:";
		cin >> a[i];
	}
}
template<class t>
void display(t a[], int n) {

	t sum = 0;
	int cnt = 0;
	for (int i = 0; i < n; i++) {
		cout << a[i] << " ";
		if (a[i] >= 0) {
			sum = sum + a[i]; //adding non-negative number into sum
			cnt++; //keeping count of non-negative numbers
		}
	}
	cout << endl << "Average =" << (float) sum / cnt << endl;
}

//To know more visit:
//https://www.mathsisfun.com/data/standard-deviation-formulas.html

template<class t>
void deviation(t a[], int n) {
	float sum = 0, b[50];

//Step-1 calculate mean of given 'n' numbers
	for (int i = 0; i < n; i++) {
		sum = sum + a[i];
	}
	float mean = (float) sum / n; //Step-1 completed

//Step 2. Then for each number: subtract the Mean and square the result

	for (int i = 0; i < n; i++) {
		b[i] = pow((a[i] - mean), 2);
	}
//Step 3. Then work out the mean of those squared differences.

	sum = 0;
	for (int i = 0; i < n; i++) {
		sum = sum + b[i];
	}
	mean = sum / n;

//Step 4. Take the square root of that:
	float ans = sqrt(mean);
	cout << "Deviation = " << ans << endl;
}

int main() {
	int n;

	cout << "how many integers you want to accept :";
	cin >> n;

	int a[n];

	read(a, n);
	cout << "Integer numbers :";
	display(a, n);
	deviation(a, n);

	cout << "\nHow many float numbers you want to accept :";
	cin >> n;

	float b[n];

	read(b, n);
	cout << "Flaot numbers :";
	display(b, n);
	deviation(b, n);

}
/*
 [sachin@localhost CPP]$ g++ -Wall Q2_template_int_float.cpp -lm

 [sachin@localhost CPP]$ ./a.out
 how many integers you want to accept :5
 Enter num:1
 Enter num:2
 Enter num:3
 Enter num:4
 Enter num:5
 Integer numbers :1 2 3 4 5
 Average =3
 Deviation = 1.41421

 How many float numbers you want to accept :3
 Enter num:1.5
 Enter num:2.5
 Enter num:3.5
 Flaot numbers :1.5 2.5 3.5
 Average =2.5
 Deviation = 0.816497
 */
