/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class Bank {
	char name[10];
	int ano;
	char accType[10];
	float balance;

public:

	void accept() {
		cout << "Enter Name:";
		cin >> name;

		cout << "Enter Account num:";
		cin >> ano;

		cout << "Enter account type:";
		cin >> accType;

		cout << "Enter Balance:";
		cin >> balance;
	}
	void deposit(int acno, float amount) {
		if (acno == ano) {
			balance = balance + amount;
			cout << "Deposited Succesfully\n";
		}
	}

	void withdraw(int acno, float amount) {
		if (acno == ano) {
			if (balance >= amount) {
				balance = balance - amount;
				cout << "withdrawn succesfully !!!\n";
			} else {
				cout << "Insufficient Balance \n";
			}

		}
	}

	void display() {
		cout << name << "\t" << balance << endl;
	}
};
int main() {
	int n, acno;
	float amt;

	cout << "how many objects you want to create :";
	cin >> n;

	Bank ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].accept();
	}

	cout << "Enter account num to deposit:";
	cin >> acno;

	cout << "Enter amount to deposit:";
	cin >> amt;

	for (int i = 0; i < n; i++) {
		ob[i].deposit(acno, amt);
	}

	cout << "Enter account num to Withdraw:";
	cin >> acno;

	cout << "Enter amount to Withdraw:";
	cin >> amt;

	for (int i = 0; i < n; i++) {
		ob[i].withdraw(acno, amt);
	}

	cout << "\n\nName\tBalance\n";

	for (int i = 0; i < n; i++) {
		ob[i].display();
	}
	return 0;
}
