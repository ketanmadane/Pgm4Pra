/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
using namespace std;

class Fraction {
	int num, den;

public:
	Fraction(int n = 0, int d = 1) {
		num = n;
		den = d;
	}
	friend istream & operator >>(istream &iob, Fraction &f);
	friend ostream & operator <<(ostream &out, Fraction &f);

};

istream & operator >>(istream &iob, Fraction &f) {
	cout << "Enter Numerator :";
	iob >> f.num;

	LAB: cout << "Enter Denominator :";
	iob >> f.den;

	if (f.den == 0) {
		cout << "Denomenator should not be Zero !!! " << endl;
		goto LAB;
	}
	return iob;
}

ostream & operator <<(ostream &out, Fraction &f) {
	float ans = (float) f.num / f.den;
	cout << "Fraction:" << f.num << "/" << f.den << "=" << ans << endl;
	return out;
}
int main() {
	Fraction fob;

	cin >> fob;
	cout << fob;

	return 0;
}

/*
 [sachin@localhost CPP]$ g++ Q1_Fraction.cpp
 [sachin@localhost CPP]$ ./a.out
 Enter Numerator :5
 Enter Denominator :2
 Fraction:5/2=2.5

 [sachin@localhost CPP]$ ./a.out
 Enter Numerator :5
 Enter Denominator :0

 Denomenator should not be Zero !!!
 Enter Denominator :3
 Fraction:5/3=1.66667

 [sachin@localhost CPP]$
 */
