/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
using namespace std;
class Fraction {
	int a, b;

public:
	Fraction(int x = 0, int y = 1) {
		a = x;
		b = y;
	}

	Fraction add(Fraction ob2) {
		Fraction temp;
		temp.a = (a * ob2.b) + (ob2.a * b);
		temp.b = b * ob2.b;
		return temp;
	}
	Fraction mult(Fraction ob2) {
		Fraction temp;
		temp.a = a * ob2.a;
		temp.b = b * ob2.b;
		return temp;
	}
	void display() {
		cout << a << "/" << b << endl;
	}

};

int main() {
	int num, den;
	Fraction ob3;

	cout << "ACCEPTING FIRST FRACTION " << endl;

	cout << "ENTER VALUE OF NUMERATOR=";
	cin >> num;
	cout << "ENTER VALUE OF DENOMENATOR=";
	cin >> den;

	Fraction ob1(num, den);

	cout << "ACCEPTING SECOND FRACTION" << endl;
	cout << "ENTER VALUE OF NUMERATOR=";
	cin >> num;
	cout << "ENTER VALUE OF DENOMENATOR=";
	cin >> den;

	Fraction ob2(num, den);

	cout << "FIRST FRACTION = ";
	ob1.display();

	cout << "SECOND FRACTION = ";
	ob2.display();

	ob3 = ob1.add(ob2);
	cout << "SUM = ";
	ob3.display();

	ob3 = ob1.mult(ob2);
	cout << "MULT = ";
	ob3.display();

	return 0;
}

