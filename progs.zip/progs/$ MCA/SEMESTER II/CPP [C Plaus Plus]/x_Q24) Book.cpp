/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class Book {
	int bno;
	char title[20];
	float price;

public:

	void input() {
		cout << "Enter Book num:";
		cin >> bno;

		cout << "Enter Title : ";
		cin >> title;

		cout << "Enter Price :";
		cin >> price;
	}
	void display() {
		cout << bno << "\t" << title << "\t" << price << endl;
	}
	static void purchase(Book b[], int n) {
		int copies[n];

		for (int i = 0; i < n; i++) {
			cout << "How many copies of ' " << b[i].title << " '  You need : ";
			cin >> copies[i];
		}

		total_cost(b, n, copies);

	}
	static void total_cost(Book b[], int n, int copies[]) {
		float total = 0;
		for (int i = 0; i < n; i++) {
			total = total + (b[i].price * copies[i]);
		}

		cout << "Total Cost Paid by User : " << total << endl;
	}

};

int main() {
	int n;

	cout << "how many objects you want to create :";
	cin >> n;

	Book ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].input();
	}

	cout << "\n\nBOOK NUM\tTITLE\tPRICE\n";

	for (int i = 0; i < n; i++) {
		ob[i].display();
	}

	Book::purchase(ob, n);

	return 0;
}
/*
 [sachin@localhost CPP]$ g++ Q24_Book.cpp
 [sachin@localhost CPP]$ ./a.out
 how many objects you want to create :3
 Enter Book num:101
 Enter Title : C
 Enter Price :100
 Enter Book num:102
 Enter Title : C++
 Enter Price :200
 Enter Book num:3
 Enter Title : Java
 Enter Price :300


 BOOK NUM	TITLE	PRICE
 101	C	100
 102	C++	200
 3	Java	300
 How many copies of ' C '  You need : 2
 How many copies of ' C++ '  You need : 1
 How many copies of ' Java '  You need : 3
 Total Cost Paid by User : 1300
 */
