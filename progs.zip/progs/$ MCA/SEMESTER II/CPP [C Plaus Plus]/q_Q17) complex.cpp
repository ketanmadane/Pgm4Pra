/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

/*	
 * Define class named Complex for representing complex numbers. A complex number has the general form a+ib.
 * Complex rules are as follows -
 * 	(a+ib)+(c+id)=(a+c)+i(b+d)
 * 	(a+ib)-(c+id)=(a+c)-i(b+d)
 *	(a+ib)*(c+id)=(ac-bd)+i(bc+ad)
 * Define these operation as memeber functions of Complex.	
 * */
#include<iostream>

using namespace std;

class Complex {
	int a, b;
public:
	Complex() {
		a = 0;
		b = 0;
	}
	void accept() {
		cout << "\nEnter value of a= ";
		cin >> a;
		cout << "\nEnter value of b=  ";
		cin >> b;
	}
	void display(char opr) {
		cout << "(" << a << ")" << opr << "i(" << b << ")\n";
	}
	Complex add(Complex ob2) {
		Complex t;
		t.a = a + ob2.a;
		t.b = b + ob2.b;
		return t;
	}
	Complex sub(Complex ob2) {
		Complex t;
		t.a = a + ob2.a;
		t.b = b + ob2.b;
		return t;
	}
	Complex mult(Complex ob2) {
		Complex t;
		t.a = (a * ob2.a) - (b * ob2.b);
		t.b = (b * ob2.a) + (a * ob2.b);
		return t;
	}

};

int main() {
	Complex ob1, ob2, ans;

	cout << "\nAccepting first Complex\n";
	ob1.accept();

	cout << "\nAccepting second Complex\n";
	ob2.accept();

	cout << "\nFirst Complex = ";
	ob1.display('+');

	cout << "\nSecond Complex = ";
	ob2.display('+');

	ans = ob1.add(ob2);
	cout << "\nSum of Polynomial = ";
	ans.display('+');

	ans = ob1.sub(ob2);
	cout << "\nSubtraction of Polynomial = ";
	ans.display('-');

	ans = ob1.mult(ob2);
	cout << "\nMultiplication of Polynomial = ";
	ans.display('+');

}

