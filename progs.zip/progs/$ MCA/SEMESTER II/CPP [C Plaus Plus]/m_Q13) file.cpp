/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<fstream>
#include<string.h>
#define MAXSIZE 20
using namespace std;

class CFile {
	fstream fp;
	char fn[MAXSIZE];

public:
	CFile(char *fname) {
		strcpy(fn, fname);
	}

	void char_count() {
		fp.open(fn, ios::in);
		if (!fp) {
			cout << "Unbale to open file for reading !!!\n";
			return;
		}

		int cnt = 0;
		while ((fp.get()) != EOF) {
			cnt++;
		}
		fp.close();
		cout << "No of Chararcter in file:" << cnt << endl;

	}
	void line_count() {
		fp.open(fn, ios::in);
		if (!fp) {
			cout << "Unbale to open file for reading !!!\n";
			return;
		}

		int cnt = 0;
		char ch;
		while ((ch = fp.get()) != EOF) {
			if (ch == '\n')
				cnt++;
		}
		fp.close();
		cout << "No of Lines in file:" << cnt << endl;

	}
};

int main() {
	char fname[10], ch;

	cout << "Enter File Name which contains data :"; //e.g a.txt should be there with data
	cin >> fname;

	CFile ob(fname);
	ob.char_count();
	ob.line_count();

}

