/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class Report {
	int adno;
	char name[20];
	float marks[5];
	float avg;

public:
	void readInfo() {
		cout << "Enter Admission Number:";
		cin >> adno;
		cout << "Enter Name:";
		cin >> name;

		for (int i = 0; i < 5; i++) {
			cout << "Enter marks for subject  " << i + 1 << ":";
			cin >> marks[i];
		}
		avg = getAvg();

	}
	float getAvg() {
		return (marks[0] + marks[1] + marks[2] + marks[3] + marks[4]) / 5.0;
	}
	void displayInfo() {
		cout << adno << "\t" << name << "\t" << marks[0] << "\t" << marks[1]
				<< "\t" << marks[2] << "\t" << marks[3] << "\t" << marks[4]
				<< "\t" << avg << endl;
	}
};
int main() {
	int n;
	char name[10];

	cout << "how many objects you want to create :";
	cin >> n;

	Report ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].readInfo();
	}

	cout << "\n\nAdno\tName\tMarks1\tMarks2\tMarks3\tMarks4\tMarks5\tAverage\n";

	for (int i = 0; i < n; i++) {
		ob[i].displayInfo();
	}

}
/*
 [sachin@localhost CPP]$ g++ Q25_Report.cpp
 [sachin@localhost CPP]$ ./a.out
 how many objects you want to create :2
 Enter Admission Number:101
 Enter Name:sachin
 Enter marks for subject  1:10
 Enter marks for subject  2:20
 Enter marks for subject  3:30
 Enter marks for subject  4:40
 Enter marks for subject  5:50
 Enter Admission Number:102
 Enter Name:Sourabh
 Enter marks for subject  1:50
 Enter marks for subject  2:60
 Enter marks for subject  3:7
 Enter marks for subject  4:80
 Enter marks for subject  5:90


 Adno	Name	Marks1	Marks2	Marks3	Marks4	Marks5	Average
 101	sachin	10	20	30	40	50	30
 102	Sourabh	50	60	7	80	90	57.4
 */
