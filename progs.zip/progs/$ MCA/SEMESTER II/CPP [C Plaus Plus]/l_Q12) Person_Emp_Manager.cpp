/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class Person {
	char name[10], address[20], phno[11];

public:
	void accept() {
		cout << "Enter Name :";
		cin >> name;

		cout << "Enter Address :";
		cin >> address;

		cout << "Enter Phno :";
		cin >> phno;
	}
	void display() {
		cout << name << "\t" << address << "\t" << phno << "\t";
	}
};

class Emp: private Person {
	int eno;
	char ename[10];

public:
	void accept() {
		Person::accept();
		cout << "enter emp no:";
		cin >> eno;

		cout << "Enter Emp name :";
		cin >> ename;
	}

	void display() {
		Person::display();
		cout << eno << "\t" << ename << "\t";
	}
};

class Manager: private Emp {
	char desg[10], dept[10];
	double salary;
public:

	void accept() {
		Emp::accept();
		cout << "Enter Designation:";
		cin >> desg;
		cout << "Enter Department :";
		cin >> dept;
		cout << "Enter salary :";
		cin >> salary;
	}
	void display() {
		Emp::display();
		cout << desg << "\t" << dept << "\t" << salary << endl;
	}
};

int main() {
	int n;
	cout << "how many objects you want to create :";
	cin >> n;

	Manager ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].accept();
	}

	cout << "Name\tAddress\tPhno\tEno\tName\tDesg.\tDept\tSalary\n";

	for (int i = 0; i < n; i++) {
		ob[i].display();
	}
	return 0;
}
