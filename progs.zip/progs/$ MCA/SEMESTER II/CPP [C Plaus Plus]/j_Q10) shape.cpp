/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class shape {

	float v1, v2;
public:
	shape(float a = 0.0, float b = 0.0) {
		v1 = a;
		v2 = b;
	}
	float get_data() {
		return v1 * v2;
	}
	virtual void display_area()=0;
};

class square: public shape {
	float ans;

public:
	square(float r = 0.0) :
			shape(r, r) {
		ans = 0.0;
	}
	void display_area() {
		ans = shape::get_data();
		cout << "Area of Square:" << ans << endl;
	}

};
class rectangle: public shape {
	float ans;

public:
	rectangle(float l = 0.0, float b = 0.0) :
			shape(l, b) {
		ans = 0.0;
	}
	void display_area() {
		ans = shape::get_data();
		cout << "Area of Rectangle :" << ans << endl;
	}

};

int main() {

	float side;
	shape *p = NULL;

	cout << "Enter the Side for square:";
	cin >> side;

	p = new square(side);
	p->display_area();
	delete p;

	float l, b;
	cout << "Enter Length :";
	cin >> l;
	cout << "Enter Breadth :";
	cin >> b;

	p = new rectangle(l, b);
	p->display_area();
	delete p;

}
