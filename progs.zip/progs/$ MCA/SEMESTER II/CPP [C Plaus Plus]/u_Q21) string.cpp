/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<string.h>
using namespace std;

class String {
	char str[80];

public:
	String() {
		strcpy(str, "");
	}
	String(const char s[]) {
		strcpy(str, s);
	}

	void display() {
		cout << str << endl;
	}

	String operator +(String ob2) {
		String tob;
		int k = 0;
		for (int i = 0; str[i] != '\0'; i++, k++)
			tob.str[k] = str[i];

		for (int j = 0; ob2.str[j] != '\0'; j++, k++)
			tob.str[k] = ob2.str[j];

		tob.str[k] = '\0';
		return tob;
	}

	bool operator ==(String ob2) {
		if (strcmp(str, ob2.str) == 0)
			return true;
		else
			return false;
	}
};

int main() {
	String ob3;
	char s[10];

	cout << "Enter first object: ";
	cin >> s;

	String ob1(s);

	cout << "Enter Second Object :";
	cin >> s;

	String ob2(s);

	cout << "Fisrst Object :";
	ob1.display();

	cout << "Second Object :";
	ob2.display();

	ob3 = ob1 + ob2;

	cout << "Concatenation :";
	ob3.display();

	if (ob1 == ob2)
		cout << "String are Equal !!!!\n";
	else
		cout << "Strings are not equal !!!\n";
	return 0;
}
