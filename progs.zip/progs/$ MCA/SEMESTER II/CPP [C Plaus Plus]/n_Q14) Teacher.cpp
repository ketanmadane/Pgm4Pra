/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class Teacher {
	char name[10], subject[10];
	double salary;

public:
	void read_data() {
		cout << "Enter name:";
		cin >> name;

		cout << "Enter Subject :";
		cin >> subject;

		try {
			cout << "Enter Salary:";
			cin >> salary;
			if (salary < 0) {
				throw "Excpetion: Salary is not positive \n\n";
			}
		} catch (const char *s) {
			cout << s;
			salary = 0;
		}
	}

	void display_data() {
		cout << name << "\t" << subject << "\t" << salary << endl;
	}
};

int main() {
	int n;
	cout << "how many objects you want to create :";
	cin >> n;

	Teacher ob[n];

	for (int i = 0; i < n; i++) {
		ob[i].read_data();
	}

	cout << "Name\tsubject\tSalary\n";

	for (int i = 0; i < n; i++) {
		ob[i].display_data();
	}
	return 0;

}
