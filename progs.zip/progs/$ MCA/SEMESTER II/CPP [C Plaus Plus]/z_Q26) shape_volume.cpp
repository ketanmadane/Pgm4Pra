/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class shape {

	float v1, v2;
public:
	shape(float a = 0.0, float b = 0.0) {
		v1 = a;
		v2 = b;
	}
	float get_data() {
		return v1 * v2;
	}
	virtual void display_volume()=0;
};

class cube: public shape {
	float ans;

public:
	cube(float a = 0.0) :
			shape(a * a, a) {
		ans = 0.0;
	}
	void display_volume() {
		ans = shape::get_data();
		cout << "Volume of cube :" << ans << endl;
	}

};
class cylinder: public shape {
	float ans;

public:
	cylinder(float r = 0.0, float h = 0.0) :
			shape(r * r, h) {
		ans = 0.0;
	}
	void display_volume() {
		ans = 3.14 * shape::get_data();
		cout << "Volume of Cyliinder :" << ans << endl;
	}

};

int main() {

	float a;
	shape *p = NULL;

	cout << "Enter the value for a:";
	cin >> a;

	p = new cube(a);
	p->display_volume();
	delete p;

	float r, h;
	cout << "Enter radius for cylinder :";
	cin >> r;
	cout << "Enter Height for cylinder :";
	cin >> h;

	p = new cylinder(r, h);
	p->display_volume();
	delete p;

}
