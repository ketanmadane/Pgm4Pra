/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>
#include<fstream>

using namespace std;

class MyFile {
	fstream in_out;

public:
	MyFile(char *fname) {
		in_out.open(fname, ios::in | ios::out | ios::trunc);
		if (!in_out) {
			ofstream ob(fname);
			ob.close();
			in_out.open(fname, ios::in | ios::out | ios::trunc);
		}
	}
	void append(char ch) {
		in_out.put(ch);
	}
	void display() {
		in_out.seekg(0, ios::beg);
		char ch;
		while ((ch = in_out.get()) != EOF) {
			cout << ch;
		}
	}

	void fileclose() {
		in_out.close();
	}
};

int main() {
	char fname[10], ch;

	cout << "Enter File Name:";
	cin >> fname;

	MyFile ob(fname);

	cout << "Enter data & press 'cntrl+d' to stop" << endl;

	while ((ch = cin.get()) != EOF) //accepting character from user and appending it to the file
	{
		ob.append(ch);
	}

	cout << "\n\nFiles contains Data " << endl;
	ob.display();
	ob.fileclose();
}
