/*
 By Sachin Dhane.
 Techno-Comp Academy
 Branch : (F. C. Road /  Old Sangvi),Pune
 Contact- 9028282629 / 9970970127
 Visit : technocompacademy.in
 */

#include<iostream>

using namespace std;

class Matrix {
	int **p;
	int m, n;

public:
	Matrix(int r = 10, int c = 10) {
		m = r;
		n = c;

		p = new int*[m];

		for (int i = 0; i < n; i++) {
			p[i] = new int[n];
		}

	}
	Matrix(Matrix &ob) {
		m = ob.m;
		n = ob.n;
		p = new int*[m];

		for (int i = 0; i < n; i++) {
			p[i] = new int[n];
		}

		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++)
				p[i][j] = ob.p[i][j];
		}

	}

	Matrix operator +(Matrix &ob2) {

		Matrix ans(m, n);
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++)
				ans.p[i][j] = p[i][j] + ob2.p[i][j];
		}
		return ans;
	}

	void accept() {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				cout << "Enter the data :";
				cin >> p[i][j];
			}
		}
	}
	void display() {
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				cout << p[i][j] << "\t";
			}
			cout << endl;
		}
	}

};

int main() {
	int m, n;

	cout << "How many rows :";
	cin >> m;

	cout << "How many columns :";
	cin >> n;

	Matrix ob1(m, n), ob2(m, n), ob3(m, n);

	cout << "Accepting First Matrix \n";
	ob1.accept();

	cout << "\n\nAccepting Seocnd Matrix \n";
	ob2.accept();

	ob3 = ob1 + ob2;

	cout << "First Matrix\n";
	ob1.display();

	cout << "Second Matrix\n";
	ob2.display();

	cout << "Sum of above two matrix\n";
	ob3.display();

	return 0;
}

