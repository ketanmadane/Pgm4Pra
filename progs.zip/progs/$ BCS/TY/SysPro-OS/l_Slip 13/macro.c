#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char t1[50],t2[50],t3[50],s[50],fn[50],ppt[50][50],fpt[50][50];
int kptptr=0,pptptr=0,fptptr=0,aptptr=0,mdtptr=0,mntptr=0,mec=0,n,i;
FILE *fp;

struct macronametable
{
	char mname[50];
	int mdtp,nop;
}mnt[50];

struct keywordparam
{
	char param[50],value[50];
}kpt[50];

struct actualparam
{
	char param[50],value[50];
}apt[50];

struct macrodef
{
	char opcode[50],value[50];
}mdt[50];

int searchppt(char *s)
{
	for(i=0;i<pptptr;i++)
		if(strcmp(ppt[i],s)==0)
			return i;
	return -1;
}

int searchfpt(char *s)
{
	for(i=0;i<fptptr;i++)
		if(strcmp(fpt[i],s)==0)
			return i;
	return -1;
}

int searchapt(char *s)
{
	for(i=0;i<aptptr;i++)
		if(strcmp(apt[i].param,s)==0)
			return i;
	return -1;
}

int searchkpt(char *s)
{
	for(i=0;i<kptptr;i++)
		if(strcmp(kpt[i].param,s)==0)
			return i;
	return -1;
}

int searchmnt(char *s)
{
	for(i=0;i<mntptr;i++)
		if(strcmp(mnt[i].mname,s)==0)
			return i;
	return -1;
}

void printppt()
{
	printf("\n\nPositional Parameter Table\n");
        printf("\nParameter Name\n");
	for(i=0;i<pptptr;i++)
		printf("\n%s",ppt[i]);
}

void printfpt()
{
	printf("\n\nFormal Parameter Table\n");
         printf("\nParameters\n");
	for(i=0;i<fptptr;i++)
		printf("\n%s",fpt[i]);
}

void printapt()
{
	printf("\n\n Actual Parameter Table\n");
        printf("\nParameter Value\n");
	for(i=0;i<aptptr;i++)
		printf("\n%s\t%s",apt[i].param,apt[i].value);
}

void printkpt()
{
	printf("\n\n Keywora Parameter Table\n");
        printf("\nParameter Value\n");
	for(i=0;i<kptptr;i++)
		printf("\n%s\t%s",kpt[i].param,kpt[i].value);
}

void printmnt()
{       
        printf("\n\nMacro Name Table\n");
	printf("\nmname\tmdtp\tnop\n");
	for(i=0;i<mntptr;i++)
		printf("\n%s\t%d\t%d",mnt[i].mname,mnt[i].mdtp,mnt[i].nop);
}


void printmdt1()
{
        printf("\n mname \t mdtp \t nop\n");
        for(i=0;i<mdtptr;i++)
                printf("\n%s\t%s",mdt[i].opcode,mdt[i].value);
}

void printmdt()
{
	int j,k,p,i1;char *ptr;

        printf("\n\nMacro Defination Table\n");
	for(i1=0;i1<mdtptr;i1++)
	{

             if(mdt[i1].opcode[0]=='&')
		{
			j=searchfpt(mdt[i1].opcode+1);
			j++;
      
			ptr=strstr(mdt[i1].value,",");
			k=searchfpt(ptr+2);
			k++;
			strcpy(t1,mdt[i1].value);
			t1[strlen(mdt[i1].value)-strlen(ptr)]='\0';
			p=searchfpt(t1+1);
			p++;
			printf("\n(p,%d)(p,%d)(p,%d)\n",j,p,k);
		}//if
		else if(strcmp(mdt[i1].opcode,"MEND")==0)
			printf("\nMEND\n");
		else
		{
			ptr=strstr(mdt[i1].value,",");
			k=searchfpt(ptr + 2);
			k++;
			strcpy(t1,mdt[i1].value);
			t1[strlen(mdt[i1].value)-strlen(ptr)]='\0';
			p=searchfpt(t1+1);
			p++;
			printf("\n%s (p,%d) (p,%d)",mdt[i1].opcode,p,k);
		}//else
	}//for
}//printmdt

void makefpt(char *s)
{
	int k=0,j=0;char tmp[50];
	strcat(s,",");
	while(s[k]!='\0')
	{
		if(s[k]=='&')
			k++;
		else if(s[k]==',')
		{
			tmp[j]='\0';
			j=0;
			k++;
			if(searchppt(tmp)==-1)
			{
				strcpy(ppt[pptptr++],tmp);
				strcpy(fpt[fptptr++],tmp);
			}//if
		}//elseif
		else
		{
			tmp[j]=s[k];
			j++;
			k++;
			if(s[k]=='=')
			{
				tmp[j]='\0';
				j=0;
				strcpy(kpt[kptptr].param,tmp);
				strcpy(fpt[fptptr++],tmp);
				while(s[k]!=',')
				{
					tmp[j]=s[k];
					j++;
					k++;
				}
				tmp[j]='\0';
                                k++;
				j=0;
				strcpy(kpt[kptptr++].value,tmp);
			}//if
		}//else
	}//while
mnt[0].nop=pptptr;
}
	void makeapt(char *s)
	{
		int k=0,j=0;
		char tmp[50];
		strcat(s,",");
		while(s[k]!='\0')
		{
			if(s[k]=='&')
				k++;
			else if(s[k]==',')
			{
				tmp[j]='\0';
				j=0;
				k++;
				strcpy(apt[aptptr].param,tmp);
				strcpy(apt[aptptr++].value,"");
			}//elseif
			else
			{
				tmp[j]=s[k];
				j++;
				k++;
				if(s[k]=='=')
				{
					tmp[j]='\0';
					j=0;
					strcpy(apt[aptptr].param,tmp);
					while(s[k]!=',')
					{
						tmp[j]=s[k];
						j++;
						k++;
					}
					tmp[j]='\0';
                                         k++;
					j=0;
					strcpy(apt[aptptr++].value,tmp);
				}//if
			}//else
		}//while

}


void seperate()
{
 printf("\n macro prototype is %s",s);
}


		void expand(int k)
		{
			int k1,k2,k3;
			char tmp1[50],tmp2[50],tmp3[50],*ptr;
			int mec=0;
                     // printmdt1();
			while(strcmp(mdt[mec].opcode,"MEND")!=0)
			{
				if(mdt[mec].opcode[0]=='&')
				{
                                    // printf("\n mmmm%s",mdt[mec].opcode);
					k1=searchapt(mdt[mec].opcode+1);
					if(k1!=-1)
						strcpy(tmp1,apt[k1].value);
					else
					{
						k1=searchkpt(mdt[mec].opcode+1);
						strcpy(tmp1,kpt[k1].value);
					}
					ptr=strstr(mdt[mec].value,",");
					k2=searchppt(ptr+2);
					if(k2!=-1)
						strcpy(tmp2,apt[k2].param);
					strcpy(t1,mdt[mec].value);
					t1[strlen(mdt[mec].value)-strlen(ptr)]='\0';
					k3=searchapt(t1+1);
					if(k3!=-1)
						strcpy(tmp3,apt[k3].value);
					else
					{
						k3=searchkpt(t1+1);
						strcpy(tmp3,kpt[k3].value);
					}//else
					printf("\n+%s %s %s",tmp1+1,tmp3+1,tmp2);
				}//if of '&'
				else
				{
					ptr=strstr(mdt[mec].value,",");
					k2=searchppt(ptr+2);
					if(k2!=-1)
                                        strcpy(tmp2,apt[k2].param);
                   
					strcpy(t1,mdt[mec].value);
                                        t1[strlen(mdt[mec].value)-strlen(ptr)]='\0';
           				k3=searchapt(t1+1);
					 if(k3!=-1)
						strcpy(tmp3,apt[k3].value);
					else
					{
						
                                                  k3=searchkpt(t1+1);
                               		          strcpy(tmp3,kpt[k3].value);
                                         
					}//else
					printf("\n+%s %s %s",mdt[mec].opcode,tmp3+1,tmp2);
				}//else
                        mec++;
			}//while
		
		}//expand

main(int argc,char *argv[])
{
	strcpy(fn,argv[1]);
	fp=fopen(fn,"r");
	if(fp==NULL)
	{
		printf("\n can not open");
		exit(0);
	}//if
	while(!feof(fp))
	{
		fgets(s,80,fp);
		n=sscanf(s,"%s%s%s",t1,t2,t3);
		switch(n)
		{
			case 1: if(strcmp(t1,"STOP")==0)
				printf("\n STOP");
				if(strcmp(t1,"MEND")==0)
				{
					strcpy(mdt[mdtptr].opcode,t1);
					strcpy(mdt[mdtptr++].value,"");
					mntptr++;
				}//if
				if(strcmp(t1,"MACRO")==0)
				{
					fgets(s,80,fp);
                                        seperate();
					sscanf(s,"%s%s",t1,t2);
					strcpy(mnt[mntptr].mname,t1);
					mnt[mntptr].mdtp=0;
					makefpt(t2);
                                }
				break;

			case 2:
				if(searchmnt(t1)!=-1)
				{
					makeapt(t2);
                                      
					if(aptptr<pptptr)
					{
						printf("\n can npot open");
						exit(0);
					}//if
					expand(0);
				}//if
				else
				{
					if(t2[0]=='&')
					{
						strcpy(mdt[mdtptr].opcode,t1);
						strcpy(mdt[mdtptr++].value,t2);
					}//if
					else
					printf("\n %s",s);
				}//else
				break;
			case 3:
				printf("\n %s",s);
				break;

		}//switch
	}//while
 printmnt();
 printmdt();
printfpt();
printkpt();
printapt();
}//main
/*
----------------------------------------------------------------------------------------
OUTPUT:
[localhost ~]$ vi macro.c
[localhost ~]$ cc macro.c
[localhost ~]$ ./a.out macro.txt
*/
