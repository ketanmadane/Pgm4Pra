/*	SACHIN DHANE.		CONTACT:9028282629
 *	TECHNO-COMP SOLUTION,(OLD SANGVI & KOTHRUD)
 * TYBCS:SEM-I
 * ASSIGNMENT-2 : SIMULATOR PROGRAM 
 * */


#include<stdio.h>
#include<stdlib.h>

int main()
{
	FILE *fp;
	char fname[10];
	
	long memory[50];		//this array is used to store numeric code of SMACO
	
	int reg[4]={0,0,0,0};		//registers AREG,BREG,CREG,DREG
	int cc[6]={0,0,0,0,0,1};	//Condition Code {LT,LE,EQ,GT,GE,ANY}
	int pc=0;			//program counter is intialized to zero bcz instruction stored in memroy from index '0'
	int opc,op1,op2;		//opcode,operand1,operand2	
	int i;
	
	printf("\nENTER FILE NAME : ");
	scanf("%s",fname);

	fp=fopen(fname,"r");
	if(fp==NULL)
	{
		printf("\n%s is not found\n",fname);
		exit(0);
	}

	/*  Load file into memory array */
	pc=0;
	while(fscanf(fp,"%ld",&memory[pc++])!=EOF)
	{
		//NO code in while loop
	}
	fclose(fp);

	/*	READING EACH INSTRUCTION FROM memory ARRAY */	
	pc=0;
	while(1)
	{
		opc=memory[pc]/10000;
		op1=((memory[pc]%10000)/1000)-1;
		op2=((memory[pc]%10000)%1000);

		switch(opc)
		{
			case 0:	//STOP
				exit(0);

			case 1: //ADD
				reg[op1]=reg[op1]+memory[op2];
				pc++;
				break;
			case 2: //SUB
				reg[op1]=reg[op1]-memory[op2];
                                pc++;
                                break;
			case 3: //MULT
                                reg[op1]=reg[op1]*memory[op2];
                                pc++;
                                break;
			case 8: //DIV
                                reg[op1]=reg[op1]/memory[op2];
                                pc++;
                                break;
			case 4: //MOVER
				reg[op1]=memory[op2];
				pc++;
				break;
			case 5: //MOVEM
				memory[op2]=reg[op1];
				pc++;
				break;
			case 6: //COMP
				
				if(reg[op1]<memory[op2])
					cc[0]=1;
				if(reg[op1]<=memory[op2])
                                        cc[1]=1;
				if(reg[op1]==memory[op2])
                                        cc[2]=1;
 				if(reg[op1]>memory[op2])
                                        cc[3]=1;
				if(reg[op1]>=memory[op2])
                                        cc[4]=1;
				pc++;
				break;

			case 7: //BC
				
				if(cc[op1]==1)
					pc=op2;
				else
					pc++;
				
				for(i=0;i<=4;i++)
					cc[i]=0;	//reset all flags i.e LT,LE,EQ,GT,GE
				break;

			case 9:	//READ
				printf("\nENTER THE NUMBER : ");
				scanf("%ld",&memory[op2]);
				pc++;
				break;

			case 10: //PRINT
				printf("\nOUTPUT= %ld",memory[op2]);
				pc++;
				break;
			
		}//switch

	}//while
}//main
