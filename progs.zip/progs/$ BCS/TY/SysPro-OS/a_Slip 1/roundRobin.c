/*	BY- SACHIN DHANE.	CONTACT-9028282629
 *	ASSIGNMENT-2:SET-A :Q.1
 *	CPU SCHEDULING - ROUND ROBIN
 * */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>	//for rand() function
struct process_info
{
	char pname[5];
	int AT,BT,tempBT,CT,TAT,WT;
};

struct gantt_chart
{
	int ST;			//start time
	char pname[5];		
	int ET;			//end time
};

struct process_info p[10];
struct gantt_chart g[100];
int n;				//no.of process in system
int gcnt=0;			//keep count of no. of entries in gantt chart
int total_TAT;			//keep total turn arround time
int total_WT;			//keep total waiting time
int time_slice;
void accept()
{
	int i;
	printf("\n\tACCEPTING INPUT TO THE SYSTEM\n");
	printf("\nENTER TIME SLICE = ");
	scanf("%d",&time_slice);
	printf("\nHow many processes you have = ");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("\nENTER INFO FOR PROCESS %d\n",i+1);
		printf("\nEnter  process name =");
		scanf("%s",p[i].pname);
		printf("\nEnter Arrival time =");
		scanf("%d",&p[i].AT);
		printf("\nEnter Burst time=");
		scanf("%d",&p[i].BT);
	
		p[i].tempBT=p[i].BT;
	}
}

void sort_AT()
{
	int i,j;
	struct process_info t;
	for(i=n-1;i>=0;i--)
	{
		for(j=0;j<i;j++)
		{
			if(p[j].AT>p[j+1].AT)
			{
				t=p[j];
				p[j]=p[j+1];
				p[j+1]=t;	
			}
		}
	}
}
int isDone()
{
	int i;
	for(i=0;i<n;i++)
	{
		if(p[i].tempBT!=0)
			return 0;
	}
	return 1;
}
void RR()
{
	int time=0,i=0;
	
	gcnt=0;
	while(!isDone())
	{
		if(p[i].AT<=time && p[i].tempBT!=0)
		{
			if(p[i].BT>=time_slice)	
			{
				g[gcnt].ST=time;
				strcpy(g[gcnt].pname,p[i].pname);
				g[gcnt].ET=time+time_slice;
				gcnt++;
			
				time=time+time_slice;
				p[i].tempBT=p[i].tempBT-time_slice;
			}
			else
			{
				g[gcnt].ST=time;
                                strcpy(g[gcnt].pname,p[i].pname);
                                g[gcnt].ET=time+p[i].tempBT;
                                gcnt++;

                                time=time+p[i].tempBT;
                                p[i].tempBT=0;

			}
			i=(i+1)%n;
			
		}
		else if(p[i].tempBT==0)
			i=(i+1)%n;
		else
		{
			g[gcnt].ST=time;
			strcpy(g[gcnt].pname,"CPU_IDLE");
			g[gcnt].ET=time+1;
			gcnt++;

			time++;
			
		}
		
	
	}
}
void calculate()
{
	//calculating completion time
	
	int ct=0,i,j;
	for(i=0;i<n;i++)
	{
		for(j=0;j<gcnt;j++)
		{
			if(strcmp(p[i].pname,g[j].pname)==0)
			{
				ct=g[j].ET;
			}
		}
		p[i].CT=ct;
	}
	
	//calculating TAT, WT, total_TAT, total_WT
	
	for(i=0;i<n;i++)
	{
		p[i].TAT=p[i].CT-p[i].AT;
		p[i].WT=p[i].TAT-p[i].BT;
	
		total_TAT=total_TAT+p[i].TAT;
		total_WT=total_WT+p[i].WT;
		
	}
}
void display()
{
	int i=0;
	printf("\nINFORMATION OF SYSTEM INFO\n");	
	printf("\nTIME SLICE = %d",time_slice);
	printf("\nPname\tAT\tBT\tCT\tTAT\tWT");
	for(i=0;i<n;i++)
	{
		printf("\n%s\t%d\t%d\t%d\t%d\t%d",p[i].pname,p[i].AT,p[i].BT,p[i].CT,p[i].TAT,p[i].WT);
	}
	
	printf("\n\nGANTT CHART => ");
	for(i=0;i<gcnt;i++)
	{
		printf("|%d|%s|%d| \t",g[i].ST,g[i].pname,g[i].ET);
	}
	
	printf("\nTotal TAT = %d",total_TAT);
	printf("\nTotal WT = %d",total_WT);
	printf("\nAvg. TAT = %f",(float)total_TAT/n);
	printf("\nAvg. WT = %f",(float)total_WT/n);
	
}
/*	THIS FUNCTION IS WRITTEN TO ACCEPTING BURST TIME FROM SYSTEM */
void acceptSystemBT()
{
	int i;
	for(i=0;i<n;i++)
	{
		p[i].BT=rand()%10+1;
		p[i].tempBT=p[i].BT;
	}
}
int main()
{
	int i;

	accept();
	printf("\nDISPLAYING ACCEPTED SYSTEM INFO \n");
	printf("\nPname\tAT\tBT");
	for(i=0;i<n;i++)
	{
		 printf("\n%s\t%d\t%d",p[i].pname,p[i].AT,p[i].BT);

	}	
	
	sort_AT();
	RR();
	calculate();
	display();
/*------------------------------------------------------------------------------------------------------*/
	//EXECUTING ROUND-ROBIN FOR BURST TIME GIVEN BY SYSTEM
	printf("\n------------------EXECUTING ROUND-ROBIN FOR SYSTEM BURST TIME--------------------------------");
	acceptSystemBT();
        printf("\nDISPLAYING ACCEPTED SYSTEM INFO \n");
        printf("\nPname\tAT\tBT");
        for(i=0;i<n;i++)
        {
                 printf("\n%s\t%d\t%d",p[i].pname,p[i].AT,p[i].BT);

        }

        sort_AT();
        RR();
        calculate();
        display();

}
/*					OUTPUT
 * [sachin@localhost CPU_Scheduling]$ ./a.out
 *
 * 	ACCEPTING INPUT TO THE SYSTEM
 *
 * 	ENTER TIME SLICE = 1
 *
 * 	How many processes you have = 3
 *
 * 	ENTER INFO FOR PROCESS 1
 *
 * 	Enter  process name =A1
 *
 * 	Enter Arrival time =1
 *
 * 	Enter Burst time=3
 *
 * 	ENTER INFO FOR PROCESS 2
 *
 * 	Enter  process name =A2
 *
 * 	Enter Arrival time =2
 *
 * 	Enter Burst time=2
 *
 * 	ENTER INFO FOR PROCESS 3
 *
 * 	Enter  process name =A3
 *
 * 	Enter Arrival time =0
 *
 * 	Enter Burst time=5
 *
 * 	DISPLAYING ACCEPTED SYSTEM INFO 
 *
 * 	Pname	AT	BT
 * 	A1	1	3
 * 	A2	2	2
 * 	A3	0	5
 * 	INFORMATION OF SYSTEM INFO
 *
 * 	TIME SLICE = 1
 * 	Pname	AT	BT	CT	TAT	WT
 * 	A3	0	5	10	10	5
 * 	A1	1	3	8	7	4
 * 	A2	2	2	6	4	2
 *
 * 	GANTT CHART => |0|A3|1| 	|1|A1|2| 	|2|A2|3| 	|3|A3|4| 	|4|A1|5| 	|5|A2|6| 	|6|A3|7| 	|7|A1|8| 	|8|A3|9| 	|9|A3|10| 	
 * 	Total TAT = 21
 * 	Total WT = 11
 * 	Avg. TAT = 7.000000
 * 	Avg. WT = 3.666667
 * 	------------------EXECUTING ROUND-ROBIN FOR SYSTEM BURST TIME--------------------------------
 * 	DISPLAYING ACCEPTED SYSTEM INFO 
 *
 * 	Pname	AT	BT
 * 	A3	0	3
 * 	A1	1	6
 * 	A2	2	7
 * 	INFORMATION OF SYSTEM INFO
 *
 * 	TIME SLICE = 1
 * 	Pname	AT	BT	CT	TAT	WT
 * 	A3	0	3	7	7	4
 * 	A1	1	6	14	13	7
 * 	A2	2	7	16	14	7
 *
 * 	GANTT CHART => |0|A3|1| 	|1|A1|2| 	|2|A2|3| 	|3|A3|4| 	|4|A1|5| 	|5|A2|6| 	|6|A3|7| 	|7|A1|8| 	|8|A2|9| 	|9|A1|10| 	|10|A2|11| 	|11|A1|12| 	|12|A2|13| 	|13|A1|14| 	|14|A2|15| 	|15|A2|16| 	
 * 	Total TAT = 55
 * 	Total WT = 29
 * 	Avg. TAT = 18.333333
 * 	Avg. WT = 9.666667[sachin@localhost CPU_Scheduling]$ 
 *
 * */
