#include<stdlib.h>		//for malloc() & free() functions
#include<stdio.h>
#include<string.h>

#define ENTRY (struct info *)malloc(sizeof(struct info))

struct info
{
	char fname[10];
	int start,length;
	struct info *next;
};

struct info *E=NULL,*lastEntry=NULL;
int *D=NULL;
int dsize;	//disk size
int used=0;

void init_disk()
{
	int i;
	D=(int*)malloc(sizeof(int)*dsize);	
	for(i=0;i<dsize;i++)
		D[i]=0;		//means i'th block is not allocated...
}

int search(int length)
{
	int i,j,flag=1,blknum;
	for(i=0;i<dsize;i++)
	{
		if(D[i]==0)
		{
			flag=1;
			for(blknum=i,j=0;j<length;j++)
			{
				if(D[blknum++]==0)
					continue;
				else
				{
					flag=0;
					break;
				}
			}
			if(flag==1)
				return i;
			
		}
	}
	return -1;
}
void allocate()
{
	char fname[10];
	int length,blknum,i;
	
	struct info *t;
	printf("\nEnter file name =");
	scanf("%s",fname);
	
	printf("\nEnter length of file = ");
	scanf("%d",&length);

	if(length<=dsize-used)
		blknum=search(length);
	else
		blknum=-1;
	
	if(blknum==-1)
	{
		printf("\nERROR : NO DISK SPACE AVAILABLE.........");
	}
	else
	{
		printf("\nBLOCK IS ALOCATED.....");	
		used=used+length;
		t=ENTRY;
		strcpy(t->fname,fname);
		t->start=blknum;
		t->length=length;
		t->next=NULL;	
		if(E==NULL)
		{
			E=lastEntry=t;
		}
		else
		{
			lastEntry->next=t;
			lastEntry=lastEntry->next;
		}
		
		/* UPADATING DISK */
		for(i=1;i<=length;i++)
		{
			D[blknum++]=1;
		}
		printf("\nBLOCK STATUS AFTER ALLOCATION = ");
		for(i=0;i<dsize;i++)
			printf("%d",D[i]);	
	}
}
void deallocate()
{
	struct info *f,*s;
	
	char fname[10];
	int start,length,i,blknum,flag=0;
	printf("\nEnter file name to delete = ");
	scanf("%s",fname);
	
	for(s=E;s!=NULL;s=s->next)
	{
		if(strcmp(s->fname,fname)==0)
		{
			flag=1;
			start=s->start;
			length=s->length;
			 for(blknum=start,i=0;i<length;i++)
                	        D[blknum++]=0;
        
		        printf("\nBLOCK STATUS AFTER DE-ALLOCATION = ");
		        for(i=0;i<dsize;i++)
               		printf("%d",D[i]);

			if(s==E)		//first node
			{
				E=E->next;
				free(s);
				used=used-length;
				break;
			}
				//other node deleting
			for(f=E;f->next!=s;f=f->next)
			{
				
			}
		
			f->next=s->next;
			free(s);
			used=used-length;
			break;
		}		
	}
	
	if(flag==0)
	{
		printf("\nINVALID FILE NAME GIVEN TO DELETE........");
	}

}
void display_entry()
{
	struct info *t;
	printf("\nFNAME\tSTART\tSIZE\n");
	for(t=E;t!=NULL;t=t->next)
	{
		printf("\n%s\t%d\t%d",t->fname,t->start,t->length);
	}
	printf("\n USED BLOCK =%d",used);
	printf("\nFREE BLOCK  =%d",dsize-used);
} 
int main()
{
	int choice;
	printf("\nWhat is disk size = ");
	scanf("%d",&dsize);
	
	init_disk();
	while(1)
	{
		printf("\nMENU\n1:ALLOCATE SPACE FO NEWLY CREATED FILE\n2:DE-ALLOCATE SPACE FOR NOW DELETED FILE\n3:SHOW USED & FREE SPACE ON DISK\n4:EXIT\n");
		printf("\nENTER YOUR CHOICE = ");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1: allocate();	
				break;
			case 2:	deallocate();
				break;
			case 3:display_entry();
				break;
			case 4:exit(0);
		}
	}
	
}
