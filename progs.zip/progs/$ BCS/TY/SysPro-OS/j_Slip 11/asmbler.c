
#include<stdio.h>
#include<string.h>
#include<stdlib.h>

long inst;
int i,n,f=0,l=0,symbols=0,p=0,lc=0,cnt=0,t=0,j,pl[20],ic[100][4];
char t1[50],t2[50],t3[50],t4[50],s[50],fn[50];
FILE *fp;

struct SYMTAB
{
 char SYMBOL[50];
 int add;
 int used;
 int defined;
}sym[50];

struct LITTAB
{
 char literal[50];
 int addr;
}lt[50];

int searchRegtab(char *s)
{
 char Regtab[4][10]={"AREG","BREG","CREG","DREG"};
 for(i=0;i<4;i++)
  if(strcmp(Regtab[i],s)==0)
   return i+1;
   return -1;
}

int searchSymtab(char *s)
{
 for(i=0;i<symbols;i++)
  if(strcmp(sym[i].SYMBOL,s)==0)
    return i;
    return -1; 
}

int searchLittab(char *s)
{
 for(i=pl[p-1];i<l;i++)
  if(strcmp(lt[i].literal,s)==0)
    return i;
    return -1;
}

int searchContab(char *s)
{
 char Contab[6][10]={"LT","LE","EQ","GT","GE","ANY"};
 for(i=0;i<6;i++)
  if(strcmp(Contab[i],s)==0)
    return i+1;
    return -1;
}

int searchOptab(char *s)
{
 char Optab[11][20]={"STOP","ADD","SUB","MULT","MOVER","MOVEM","COMP","BC","DIV","READ","PRINT"};
  for(i=0;i<11;i++)
   if(strcmp(Optab[i],s)==0)
     return i;
     return -1;
}

void initSymtab()
{
  for(i=0;i<50;i++)
   {
     strcpy(sym[i].SYMBOL," ");
     sym[i].add=-1;
     sym[i].used=0;
     sym[i].defined=0;
   }
}

void initLittab()
{
	for(i=0;i<50;i++)
	{
		strcpy(lt[i].literal," ");
		lt[i].addr=-1;
	}
}

void ErrorWarnings()
{
  for(i=0;i<symbols;i++)
   {
     if(sym[i].defined==0 && sym[i].used==1)
       printf("\n ERROR : %s is used but not defined.",sym[i].SYMBOL);
     if(sym[i].defined==1 && sym[i].used==0)
       printf("\n ERROR : %s is defined but never used.",sym[i].SYMBOL);
   }
}

void AddLittab(char *literal)
{
  if(f==0)
   {
     strcpy(lt[l++].literal,literal);
     pl[p++]=l-1;
     f=1;
   }
  else
   {
     i=searchLittab(literal);
     if(i==-1)
      strcpy(lt[l++].literal,literal);
   }
}

void Litaddress()
{
  for(i=pl[p-1];i<l;i++)
   {
     lt[i].addr=lc;
     lc++;
   }
}

void AddSymtab(char *s,int a,int u,int d)
{
  i=searchSymtab(s);
  if(i==-1)
   {
    strcpy(sym[symbols].SYMBOL,s);
    i=symbols;
    symbols++;
   }
  if(sym[i].add!=-1 && a>=0)
   printf("\n ERROR : %s is redeclared symbol.",sym[i].SYMBOL);
  if(sym[i].add==-1)
   sym[i].add=a;
  if(sym[i].used==0)
   sym[i].used=u;
  if(sym[i].defined==0)
   sym[i].defined=d;
}

void Pass_I()
{
  initSymtab();
  initLittab();
  while(!feof(fp))
  {
    fgets(s,80,fp);
    n=sscanf(s,"%s%s%s%s",t1,t2,t3,t4);
    switch(n)
     {
       case 0:ic[cnt][0]=0;
              ic[cnt][1]=0;
              ic[cnt][2]=0;
              ic[cnt++][3]=0;
              lc++;
              break;

       case 1:if(strcmp(t1,"STOP")==0)
               {
                 ic[cnt][0]=0;
                 ic[cnt][1]=0;
                 ic[cnt][2]=0;
                 ic[cnt++][3]=0;
                 lc++;
               }
              else if(strcmp(t1,"LTORG")==0 || strcmp(t1,"END")==0)
               {
                 Litaddress();
                 f=0;
               }
              if(t1[0]=='=')
               {
                 ic[cnt][0]=0;
                 ic[cnt][1]=0;
                 ic[cnt][2]=atoi(t1+1);
                 ic[cnt++][3]=0;
               }
              break;
         
      case 2:if(strcmp(t1,"START")==0)
               {
                 if(strstr(t2,","))
                   printf("%s is invalid statement",s);
                 else
                   lc=atoi(t2);
               }
             if(strcmp(t1,"STOP")==0)
               {
                 t1[strlen(t1)-1]='\0';
                 AddSymtab(t1,lc,0,1);
                 ic[cnt][0]=0;
                 ic[cnt][1]=0;
                 ic[cnt][2]=0;
                 ic[cnt++][3]=0;
                 lc++;
               }
            if(strcmp(t1,"ORIGIN")==0)
               {
                 char *pat;
                 if(pat=strstr(t2,"+"))
                  {
                    t2[strlen(t2)-2]='\0';
                    AddSymtab(t2,-1,1,0);
                    i=searchSymtab(t2);
                    lc=sym[i].add+atoi(pat+1);
                  }
                 else
                  {
                    AddSymtab(t2,-1,1,0);
                    i=searchSymtab(t2);
                    lc=sym[i].add;
                  }
               }
            if(searchOptab(t1)==9 || searchOptab(t1)==10)
               {
                 AddSymtab(t2,-1,1,0);
                 ic[cnt][0]=searchOptab(t1);
                 ic[cnt][1]=0;
                 ic[cnt][2]=searchSymtab(t2);
                 ic[cnt++][3]=0;
                 lc++;
               }
            break;

     case 3:if(searchOptab(t1)==-1 && searchRegtab(t2)!=-1)
              printf("\n %s invalid mnemonic in statement %s.",t1,s);
            else
             {
               if(strcmp(t2,"DS")==0)
                {
                  ic[cnt][0]=0;
                  ic[cnt][1]=0;
                  ic[cnt][2]=0;
                  ic[cnt++][3]=0;
                  lc=lc+atoi(t3);
                  AddSymtab(t1,lc,0,1);
                }
               if(strcmp(t2,"DC")==0)
                {
                  ic[cnt][0]=0;
                  ic[cnt][1]=0;
                  ic[cnt][2]=atoi(t3);
                  ic[cnt++][3]=0;
                  lc=lc+1;
                  AddSymtab(t1,lc,0,1);
                }
               if(strcmp(t2,"EQU")==0)
                {
                  i=searchSymtab(t3);
                  AddSymtab(t1,sym[i].add,sym[i].used,sym[i].defined);
                }
               if(searchOptab(t1)==9 || searchOptab(t1)==10)
                {
                  t1[strlen(t1)-1]='\0';
                  AddSymtab(t1,lc,0,1);
                  AddSymtab(t3,-1,1,0);
                  ic[cnt][0]=searchOptab(t2);
                  ic[cnt][1]=0;
                  ic[cnt][2]=searchSymtab(t3);
                  ic[cnt++][3]=0;
                  lc++;
                }
               if(searchOptab(t1)>=1 && searchOptab(t1)<=8)
                {
                  if(t3[0]=='=')
                   {
                     AddLittab(t3);
                     ic[cnt][0]=searchOptab(t1);
                     if(searchRegtab(t2)!=-1)
                      ic[cnt][1]=searchRegtab(t2);
                     else if(searchContab(t2)!=-1)
                      ic[cnt][1]=searchContab(t2);
                     else
                      printf("\n %s is Invalid Statement.",s);
                      ic[cnt][2]=searchLittab(t3);
                      ic[cnt++][3]=1;
                      lc++;
                   }
                 else
                  {
                    if(searchRegtab(t3)!=-1 || strcmp(t3,"ORIGIN")==0)
                      printf("\n %s is invalid symbol in %s",t3,s);
                    else
                     {
                      AddSymtab(t3,-1,1,0);
                      ic[cnt][0]=searchOptab(t1);
                      if(searchRegtab(t2)!=-1)
                        ic[cnt][1]=searchRegtab(t2);
                      else if(searchContab(t2)!=-1)
                        ic[cnt][1]=searchContab(t2);
                      else
                        printf("\n ERROR : %s is Invalid Statement.",s);
                        ic[cnt][2]=searchSymtab(t3);
                        ic[cnt++][3]=0;
                        lc++;
                     }
                  }
                }
              }
             break;
     
     case 4:if(searchOptab(t2)>=1 && searchOptab(t2)<=8)
                {
                   t1[strlen(t1)-1]='\0';
                   AddSymtab(t1,lc,0,1);
                  if(t4[0]=='=')
                   {
                     AddLittab(t4);
                     ic[cnt][0]=searchOptab(t2);
                     if(searchRegtab(t3)!=-1)
                      ic[cnt][1]=searchRegtab(t3);
                     else if(searchContab(t2)!=-1)
                      ic[cnt][1]=searchContab(t3);
                     else
                      printf("\n %s is Invalid Statement.",s);
                      ic[cnt][2]=searchLittab(t3);
                      ic[cnt++][3]=1;
                      lc++;
                   }
                  else
                   {
                     AddSymtab(t4,-1,1,0);
                     ic[cnt][0]=searchOptab(t2);
                     if(searchRegtab(t3)!=-1)
                      ic[cnt][1]=searchRegtab(t3);
                     else if(searchContab(t3)!=-1)
                      ic[cnt][1]=searchContab(t3);
                     else
                      printf("\n Invalid Statement %s",s);
                      ic[cnt][2]=searchSymtab(t3);
                      ic[cnt++][3]=0;
                      lc++;
                   }
              }
            break;
     }
  }
}       

void Pass_II()
{
  for(i=0;i<cnt;i++)
   {
     if(ic[i][0]==0 && ic[i][1]==0)
      {
        inst=ic[i][2];
        printf("\n %ld",inst);
      }
     else
      {
        if(ic[i][3]==1)
         inst=ic[i][0]*10000+ic[i][1]*1000+lt[ic[i][2]].addr;
        else
         inst=ic[i][0]*10000+ic[i][1]*1000+sym[ic[i][2]].add;
        printf("\n %ld",inst);
      }
   }
}
  
int main()
{
  printf("\n Enter Source File : ");
  scanf("%s",fn);
  fp=fopen(fn,"r");
  if(fp==NULL)
   {
     printf("\n File can't open.");
     exit(0);
   }
  Pass_I();
  printf("\n SYMTAB is \n");
  printf("------------------------------------");
  printf("\nSYMBOL\tADD\tUSED\tDEFINED\n");
  printf("--------------------------------------");
  for(i=0;i<symbols;i++)
  printf("\n %s\t%d\t%d\t%d",sym[i].SYMBOL,sym[i].add,sym[i].used,sym[i].defined);
  printf("\n------------------------------------\n\n");
  printf("\n LITTAB is \n");
  printf("--------------------------------");
  printf("\nLITERAL\t ADDR\n");
  printf("--------------------------------");
  for(i=0;i<l;i++)
  printf("\n %s \t %d",lt[i].literal,lt[i].addr);
  printf("\n--------------------------------\n\n");
  printf("\n POOLTAB is \n");
  printf("------------------");
  for(i=0;i<p;i++)
  printf("\n %d",pl[i]);
  printf("\n-----------------\n\n");
  ErrorWarnings();
  printf("\n-----------------------");
  printf("\n Intermediat Code is \n");
  printf("-------------------------");
  for(i=0;i<cnt;i++)
  printf("\n%d \t %d \t %d",ic[i][0],ic[i][1],ic[i][2]);
  printf("\n------------------\n\n");
  printf("\n------------------");
  printf("\n Target Code is \n");
  printf("--------------------");
  Pass_II();
  printf("\n-------------------\n");
}

/*
Output:

$ ./a.out 

 Enter Source File : asm.txt

 SYMTAB is 
------------------------------------
SYMBOL  ADD     USED    DEFINED
--------------------------------------
 A      1       1       1
 LOOP   202     1       1
 B      2       1       1
 NEXT   208     1       1
 BACK   202     1       1
 LAST   -1      1       0
------------------------------------


 LITTAB is 
--------------------------------
LITERAL  ADDR
--------------------------------
 =5      206
 =1      207
 =1      2
--------------------------------


 POOLTAB is 
------------------
 0
 2
-----------------

*/
