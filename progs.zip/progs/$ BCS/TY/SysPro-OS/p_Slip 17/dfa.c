/* BY SACHIN DHANE. CONTACT-9028282629.
 * ASSIGNEMENT : 5 	IMPLEMENTING DFA DRIVER 
 * SET- A B: Q.1-A,B,C.ALSO FOR ALL DFA
 * A) L={set of all string over {0,1,2} which start with 0 and contains substring 102}
 * */
#include<stdio.h>
#include<stdlib.h>
int noOfState,noOfInputSym,intialState,noOfFinalState;
char inputSym[10]; //store input symbols. 
int table[10][10];	//stores transition table details
int finalState[10];	//it holdes final state
char str[10];		//it holds string to cheeck

void accept()
{
	int i,j;
	printf("\nHow many states you have : ");
	scanf("%d",&noOfState);
	printf("\nHow many input symbol you have : ");
	scanf("%d",&noOfInputSym);
	printf("\nEnter initial state (e.g. 0) : ");
	scanf("%d",&intialState);
	printf("\nHow many final states you have :");
	scanf("%d",&noOfFinalState);

	printf("\nACCEPTING INPPUT SYMBOLS\n");

	for(i=0;i<noOfInputSym;i++)
	{
		printf("\nEnter Input Symbol %d =",i+1);
		getchar();			//this function removes '\n'which was entered previously bcz it is also one character..	
		scanf("%c",&inputSym[i]);
	}

	printf("\nACCEPTING FINAL STATES\n");
	for(i=0;i<noOfFinalState;i++)
	{
		printf("\nEnter Final state %d =",i+1);
		scanf("%d",&finalState[i]);
	}
	
	printf("\nACCEPTING TRANSITION TABLE\n");
	for(i=0;i<noOfState;i++)
	{
		for(j=0;j<noOfInputSym;j++)
		{
			printf("\nEnter value for state %d =",i);
			scanf("%d",&table[i][j]);
		}
	}
}

void validate()
{
	int i,j,currentState,flag;
	char symb;
	currentState=intialState;
	for(i=0;str[i]!='\0';i++)
	{
		symb=str[i];
		flag=0;
		for(j=0;j<noOfInputSym;j++)
		{
			if(inputSym[j]==symb)
			{
				flag=1;
				break;
			}
		}
		if(flag==1)
		{
			currentState=table[currentState][j];
		}
		else
		{
			printf("\nGiven Input String is Invalid...");		//you will come here if string does not contain input symbol
			exit(0);
		}
	}
	
	flag=0;
	for(i=0;i<noOfFinalState;i++)
	{
		if(finalState[i]==currentState)
		{
			flag=1;
			break;
		}
	}
	if(flag==1)
	{
		printf("\nGiven string is accepted by DFA... ");
	}
	else
	{
		printf("\nGiven String is not accepted by DFA...");
	}


}

int main()
{
	int choice;
	accept();
	
	while(1)
	{
		printf("\n Do you want to check string press 1 for yes any other key for no :");
		scanf("%d",&choice);
		if(choice==1)
		{
	 		printf("\nEnter Strnig to check :");
        		scanf("%s",str);
			validate();
		}
		else
			break;
	}
	

}

