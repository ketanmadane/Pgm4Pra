//FIFO

#include<stdio.h>

int nor;	//no of reference
int nof;	// how many frames
int ref[20];	//reference string
int table[20][20];	//holds snapshot of frames
int frame[10];
int page_fault=0;

void accept()
{
	int i;
	printf("\nHow many references = ");
	scanf("%d",&nor);

	printf("\nACCEPTING REFERENCES\n");
	for(i=0;i<nor;i++)
	{
		printf("\nENTER REFERENCE = ");
		scanf("%d",&ref[i]);
	}
	
	printf("\nHow many Frames you have = ");
	scanf("%d",&nof);
}
int search(int pno)
{
	int i;
	for(i=0;i<nof;i++)
	{
		if(frame[i]==pno)
			return i;
	}
	return -1;
}
void display()
{
	int i,j;
	printf("\n\t\t\tSNAPSHOT OF FARMES\n");
	for(i=0;i<nor;i++)
		printf("%2d ",ref[i]);
	printf("\n");
	
	for(i=0;i<nor;i++)
		printf("------");
	printf("\n");
	for(i=0;i<nof;i++)
	{
		for(j=0;j<nor;j++)
			printf("%2d ",table[i][j]);
		printf("\n");
	}

	printf("\n\nPAGE FAULT=%d",page_fault);


}
void fifo()
{
	int i,pos,r,found;
	
	for(i=0;i<nof;i++)
	{
		frame[i]=-1;
	}

	pos=0;
	for(r=0;r<nor;r++)
	{
		found=search(ref[r]);
		if(found==-1)
		{
			page_fault++;

			frame[pos]=ref[r];
			pos=(pos+1)%nof;
			
			//copying frame contents in table
			for(i=0;i<nof;i++)
			{
				table[i][r]=frame[i];
			}
			
		}
		else
		{
			for(i=0;i<nof;i++)
            {
                  table[i][r]=frame[i];
            }

		}
				
	}
}

int main()
{
	accept();
	fifo();
	display();
}
