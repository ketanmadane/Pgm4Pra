/*	MFU PAGE REPLACEMENT ALGORITHM */

#include<stdio.h>

int nor;	//no of reference
int nof;	// how many frames
int ref[20];	//reference string
int table[20][20];	//holds snapshot of frames
int frame[10],count[10];

int page_fault=0;

void accept()
{
	int i;
	printf("\nHow many references = ");
	scanf("%d",&nor);

	printf("\nACCEPTING REFERENCES\n");
	for(i=0;i<nor;i++)
	{
		printf("\nENTER REFERENCE = ");
		scanf("%d",&ref[i]);
	}
	
	printf("\nHow many Frames you have = ");
	scanf("%d",&nof);
}
int search(int pno)
{
	int i;
	for(i=0;i<nof;i++)
	{
		if(frame[i]==pno)
			return i;
	}
	return -1;
}
int get_pos(int pos)
{
	int max,i,tpos;

	tpos=pos;
	max=count[pos];
	i=pos;
	do
	{
		if(frame[i]==-1)
			return i;
		if(count[i]>max)
		{
			max=count[i];
			tpos=i;
		}
		i=(i+1)%nof;	
	}while(i!=pos);

	return tpos;
}
void mfu()
{
	int i,pos,r,found;
	
	for(i=0;i<nof;i++)
	{
		frame[i]=-1;
		count[i]=-1;
	}


	pos=0;
	for(r=0;r<nor;r++)
	{
		found=search(ref[r]);
		if(found==-1)
		{
			
			pos=get_pos(pos);
			frame[pos]=ref[r];
			count[pos]=1;
			pos=(pos+1)%nof;
			page_fault++;
			
			//copying frame into table
			for(i=0;i<nof;i++)
			{
				table[i][r]=frame[i];
			}
		}
		else
		{
			count[found]++;
			//copying frame into table
			for(i=0;i<nof;i++)
			{
			 	table[i][r]=frame[i];
			}
		}
		
	}
}

void display()
{
	int i,j;
	printf("\n\t\t\tSNAPSHOT OF FARMES\n");
	for(i=0;i<nor;i++)
		printf("%d\t",ref[i]);
	printf("\n");
	
	for(i=0;i<nor;i++)
		printf("------");
	printf("\n");
	for(i=0;i<nof;i++)
	{
		for(j=0;j<nor;j++)
			printf("%d\t",table[i][j]);
		printf("\n");
	}

	printf("\n\nPAGE FAULT=%d",page_fault);


}

int main()
{
	accept();
	mfu();
	display();
	getch();
}
