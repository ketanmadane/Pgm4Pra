/*
 * SET A: Q.1
 * 1. a
 * 2. d n 
 * 3. d m n
 * 4. s
 * 5. p
 * */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define newnode (struct node *)malloc(sizeof(struct node))

struct node
{
        struct node *prev;
        char line[80];
        struct node *next;
};

struct node *first,*last;
int length,flag;
FILE *fp;

void loadintoLL(char *fn)
{
        char buff[80];
        struct node *T;
        fp=fopen(fn,"r");
        if(fp==NULL)
        {
                printf("\n ERROR: file %s is not found",fn);
                exit(0);
        }
        while(fgets(buff,80,fp))
        {
                T=newnode;
                T->next = T->prev = NULL;
                strcpy(T->line,buff);
                if(first==NULL)
                {
			first=last=T;
                }
                else
                {
                        last->next=T;
                        T->prev=last;
                        last=last->next;
                }
                length++;
        }
}

struct node * find(int pos)
{
        int lno=1;
        struct node *T=first;
        while(lno <= pos-1)
        {
                T=T->next;
                lno++;
        }
        return T;
}

void print(int start,int end)
{
        struct node *T,*S;
        int lno=start;
        T=find(start);
        S=find(end);
        while(T!=S->next)
        {
                printf("%d %s",lno,T->line);
                T=T->next;
                lno++;
        }
}
void append()
{
        char buff[80];
        struct node *T;
         T=newnode;
         T->next = T->prev = NULL;

        printf("Enter data(line) to append= ");
        fgets(T->line,80,stdin);

        if(first==NULL)
        {
               first = last = T;
        }
        else
        {
               last->next=T;
               T->prev=last;
               last=last->next;
        }
        length++;
        flag=1;
}

void delete(int start,int end)
{
	struct node *s,*t;
	s=find(start);
	t=find(end);
	
	if(start==1 && end==length)
	{
		first=last=NULL;
	}
	else if(start==1 && end!=length)
	{
		first=t->next;
		first->prev=NULL;
	}
	else if(start!=1 && end==length)
	{
		last=s->prev;
		last->next=NULL;
		s->prev=NULL;
	}
	else
	{
		s->prev->next=t->next;
		t->next->prev=s->prev;
		s->prev=t->next=NULL;
	}
	
	length=length-(end-start+1);
	flag=1;
}
void save(char *fn)
{
	struct node *t;
	
	if(flag==1)
	{
		fp=fopen(fn,"w");
		if(fp==NULL)
		{
			printf("\nError while Opening File %s",fn);
			exit(0);
		}
	
		for(t=first;t!=NULL;t=t->next)
		{
			fputs(t->line,fp);
		}
		fclose(fp);
		flag=0;
	}
}
int main(int argc, char *argv[])
{
	char fname[10],buff[80],cmd;
	int tokenCnt=0,n1,n2;
	
	if(argc==2)
	{
		strcpy(fname,argv[1]);
		loadintoLL(fname);		
	}
	
	system("clear");
	while(1)
	{
		printf("\n$]");
		gets(buff);
		tokenCnt=sscanf(buff,"%c %d %d",&cmd,&n1,&n2);
		
		switch(tokenCnt)
		{
			case 1:
				if(cmd=='a')
				{
					append();
				}
				else if(cmd=='p')
				{
					print(1,length);
				}
				else if(cmd=='s')
				{
					save(argv[1]);
				}
				else if(cmd=='q')
				{
					exit(0);	//this command is used to Quit the editor
				}
				else
				{
					printf("Invalid Command\n");
				}
				break;
			
			case 2:
				if(cmd=='d')
				{
					delete(n1,n1);
				}
				else
				{
					printf("Invalid Command\n");
				}
				break;
			case 3:
				if(cmd=='d')
				{
					delete(n1,n2);
				}
				else
				{
					printf("Invalid Command\n");
				}
				break;
			default:
				printf("Invalid Command\n");

		}
	
	}
		
	

	
}
