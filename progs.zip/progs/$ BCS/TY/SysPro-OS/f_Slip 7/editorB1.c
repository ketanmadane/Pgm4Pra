/*
 * SET B: Q.1
 * 1. a
 * 2. p 
 * 3. m n1 n2
 * 4. m n1 n2 n3
 *
 * */

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define newnode (struct node *)malloc(sizeof(struct node))

struct node
{
        struct node *prev;
        char line[80];
        struct node *next;
};

struct node *first,*last;
int length,flag;
FILE *fp;

void loadintoLL(char *fn)
{
        char buff[80];
        struct node *T;
        fp=fopen(fn,"r");
        if(fp==NULL)
        {
                printf("\n ERROR: file %s is not found",fn);
                exit(0);
        }
        while(fgets(buff,80,fp))
        {
                T=newnode;
                T->next = T->prev = NULL;
                strcpy(T->line,buff);
                if(first==NULL)
                {
			first=last=T;
                }
                else
                {
                        last->next=T;
                        T->prev=last;
                        last=last->next;
                }
                length++;
        }
}

struct node * find(int pos)
{
        int lno=1;
        struct node *T=first;
        while(lno <= pos-1)
        {
                T=T->next;
                lno++;
        }
        return T;
}

void print(int start,int end)
{
        struct node *T,*S;
        int lno=start;
        T=find(start);
        S=find(end);
        while(T!=S->next)
        {
                printf("%d %s",lno,T->line);
                T=T->next;
                lno++;
        }
}
void append()
{
        char buff[80];
        struct node *T;
         T=newnode;
         T->next = T->prev = NULL;

        printf("Enter data(line) to append= ");
        fgets(T->line,80,stdin);

        if(first==NULL)
        {
               first = last = T;
        }
        else
        {
               last->next=T;
               T->prev=last;
               last=last->next;
        }
        length++;
        flag=1;
}

void move(int n1,int n2,int n3)
{
	struct node *p,*q,*r;

	p=find(n1);
	q=find(n2);
	r=find(n3);
	
	if(p==first && q==last)
	{
		printf("Can Not Perform MOVE..Illegal arguments...\n");
		return;
	}
	else if(p==first && q!=last)
	{
		first=q->next;
		q->next=NULL;
		first->prev=NULL;
	}
	else if(p!=first && q==last)
	{
		last=p->prev;
		last->next=NULL;
		p->prev=NULL;
	}
	else
	{
		p->prev->next=q->next;
		q->next->prev=p->prev;
		p->prev=NULL;
		q->next=NULL;
	}

	if(r==last)
	{
		r->next=p;
		p->prev=r;
		last=q;
	}
	else
	{
		q->next=r->next;
		p->prev=r;
		r->next->prev=q;
		r->next=p;
	}
	flag=1;
}
int main(int argc, char *argv[])
{
	char fname[10],buff[80],cmd;
	int tokenCnt=0,n1,n2,n3;
	
	if(argc==2)
	{
		strcpy(fname,argv[1]);
		loadintoLL(fname);		
	}
	
	system("clear");
	while(1)
	{
		printf("\n$]");
		gets(buff);
		tokenCnt=sscanf(buff,"%c %d %d %d",&cmd,&n1,&n2,&n3);
		
		switch(tokenCnt)
		{
			case 1:
				if(cmd=='a')
				{
					append();
				}
				else if(cmd=='p')
				{
					print(1,length);
				}
				else if(cmd=='q')
				{
					exit(0);	//this command is used to Quit the editor
				}
				else
				{
					printf("Invalid Command\n");
				}
				break;
			
			case 3:
				if(cmd=='m')
				{
					move(n1,n1,n2);
				}
				else
				{
					printf("Invalid Command\n");
				}
				break;
			 case 4:
                                if(cmd=='m')
                                {
                                        move(n1,n2,n3);
                                }
                                else
                                {
                                        printf("Invalid Command\n");
                                }
                                break;
			default:
				printf("Invalid Command\n");

		}
	
	}
		
	

	
}
