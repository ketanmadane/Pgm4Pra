
/* Write a program to accept a program written in assembly language. After accepting
entire program list out errors wherever applicable.
a) Symbols used but not defined
b) Symbols declared but not used
c) Redeclaration of symbols
Consider following program as input
START 100
READ X
Y MOVER BREG, X
ADD BREG, X
X MOVEM AREG, Z
STOP
X DS 1
Y DS 1
END*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct symtab
{
	char name[20];
	int add;
	int used;
	int def;
}symtab[100];
char fname[20],str[80],st[20];
char op1[10],op2[10],op3[10],op4[10];
FILE *fp;
int lc,x,u,d,cnt=0,n;
char opcode[11][6]={"COMP","MOVEM","MOVER","BC","ADD","MULT","DIV","PRINT","SUB","READ","STOP"};
int mnemonics(char []);
void addsym(char [],int,int);
void print();
void check();
int 
main()
{
	system("clear");
	printf("\nEnter file name => ");
	scanf("%s",fname);
	fp=fopen(fname,"r");
	if(fp==NULL)
	{
		printf("\nFile does not exit");
		exit(0);
	}
	fgets(str,80,fp);
	sscanf(str,"%s%d",st,&lc);
	while(1)
	{
		fgets(str,80,fp);
		puts(str);
		x=sscanf(str,"%s%s%s%s",op1,op2,op3,op4);
		switch(x)
		{
			case 1:
				break;
			case 2:
				if(mnemonics(op1)>0)
				{
					addsym(op2,0,1);
				}
				else if(mnemonics(op2)>0)	
				{
					addsym(op1,1,0);
				}
				break;
			case 3:
				if(mnemonics(op1)>0)
				{
					addsym(op3,0,1);
				}
				else if(mnemonics(op2)>0)
				{
					addsym(op1,1,0);
					addsym(op3,0,1);
				}
				else if((strcmp(op2,"DC")==0)||(strcmp(op2,"DS")==0))
				{
					addsym(op1,1,0);
				}
				break;
			case 4:
				addsym(op1,1,0);
				addsym(op4,0,1);
		}
		lc++;
		if(strcmp(op1,"END")==0)
			break;
	}
	print();
	check();
}

int mnemonics(char st[10])
{
	int j;
	for(j=0;j<11;j++)
	{
		if(strcmp(opcode[j],st)==0)
		{
			return j;
		}
	}
	return -1;
}

void addsym(char st[10],int d,int u)
{
	int i,f=0;
	for(i=0;i<cnt;i++)
	{
		if(strcmp(symtab[i].name,st)==0)
		{
			f=1;
			break;
		}
	}
	if(f==1)
	{
		if(d==1)
		{
			
			symtab[i].def++;
			symtab[i].add=lc;
		}
		else 
		{
			symtab[i].used++;
		}
	}
	else 
	{
		strcpy(symtab[i].name,st);
		symtab[i].def=d;
		symtab[i].used=u;
		if(d==1)
		{
			symtab[i].add=lc;
		}
		else
		{
			symtab[i].add=-1;
		}
		cnt++;
	}
}

void print()
{
	int i;
	printf("\n*************SYMBOL TABLE*********************");
	printf("\nName\tAddress\tDefined\tUsed");
	for(i=0;i<cnt;i++)
	{
		printf("\n%s\t%d\t%d\t%d",symtab[i].name,symtab[i].add,symtab[i].def,symtab[i].used);
	}
}

void check()
{
	int i;
	for(i=0;i<cnt;i++)
	{
		if(symtab[i].def>1)
		printf("\nRedeclaration of %s symbol",symtab[i].name);
		else if((symtab[i].def==1)&&(symtab[i].used<1))
		printf("\n%s symbol is defined but not used",symtab[i].name);
		else if(((symtab[i].used)>=1)&&(symtab[i].def<1))
		printf("\n%s symbol is used but not defined",symtab[i].name);
	}
}

/*
OUTPUT
****************************

Enter file name => asm.txt
        READ     X

Y       MOVER   BREG,   X

        ADD     BREG,   X

X       MOVEM   AREG,   Z

        STOP

        X       DS      1

        Y       DS      1

        END


*************SYMBOL TABLE*********************
Name    Address Defined Used
X       105     2       3
Y       106     2       0
Z       -1      0       1
Redeclaration of X symbol
Redeclaration of Y symbol
Z symbol is used but not defined 
*/

