/*		BANKER ALOGORITHM	*/


#include<stdio.h>

int allocation[20][20]; //allocation matrix
int max[20][20];	//holds maximum requirment of resource
int need[20][20];  	//hold need matrix
int available[20];	//holds availability of resoources
int seq[20],scnt=0; 	//holds safe sequence
int finish[20];		//tells wheather i'th process is terminated or not
int n,r;		//n=no of process	r=no.of resources

void accept()
{
	int i,j;
	printf("\nhow many processs = ");
	scanf("%d",&n);
	printf("\nEnter how many resources = ");
	scanf("%d",&r);
	
	printf("\nACCEPTING ALLOCATION MATIRCS\n");	
	
	for(i=0;i<n;i++)
	{
		for(j=0;j<r;j++)
		{
			printf("\n P%d : Enter resources for %c =",i,65+j);
			scanf("%d",&allocation[i][j]);
		}
	}
	
	printf("\nACCEPTING MAX MATRIX\n");
	for(i=0;i<n;i++)
        {
                for(j=0;j<r;j++)
                {
                        printf("\n P%d : Enter resources for %c =",i,65+j);
                        scanf("%d",&max[i][j]);
                }
        }
	
	printf("\nACCEPTING AVAILABILITY\n");
	
	for(j=0;j<r;j++)
	{
		 printf("\nAvailable resources for %c =",65+j);
                 scanf("%d",&available[j]);

	}
	fflush(stdin);
}



void calc_need()
{
	int i,j;
		
	for(i=0;i<n;i++)
        {
                for(j=0;j<r;j++)
                {
			need[i][j]=max[i][j]-allocation[i][j];
                }
        }


}


int check_need_avail(int i)
{
	int j;
	
	for(j=0;j<r;j++)
	{
		if(need[i][j]<=available[j])
			continue;
		else
			return 0;
	}
	
	return 1;
}


void banker()
{
	
	int i,j,cnt;
	
	cnt=1;		//only twice we run the algo,if within that unable to find sequence then will announce that 'system is not in safe state'
	i=0;		//starting from process 0
	while(cnt<=2)
	{
		
		if(finish[i]==0)	//considering process if not completed	
		{
			
			if(check_need_avail(i))
			{
				for(j=0;j<r;j++)
				{
					available[j]=available[j]+allocation[i][j];
				}
				finish[i]=1;		//process is finished	
				seq[scnt]=i;		//adding process i to sequence
				scnt++;
				
			}
			
		}//if

		 i=(i+1)%n;
                 if(i==0)
                 {
                         cnt++;
                 }

	}
}


void display()
{
	int i,j;
	printf("\n\t\t\t\t\t\t\tSNAPSHOT OF SYSTEM\n");
	
	printf("\n\tALLOCATION MATRIX\n");
	for(j=0;j<r;j++)
	{
		printf("\t%c ",65+j);
	}
	printf("\n");
	for(i=0;i<n;i++)
	{
		printf("P%d\t",i);
		for(j=0;j<r;j++)
		{
			printf("%d\t",allocation[i][j]);
		}
		printf("\n");
	}
	
	printf("\n\tMAX MATRIX\n");
        for(j=0;j<r;j++)
        {
                printf("\t%c ",65+j);
        }
	printf("\n");
        for(i=0;i<n;i++)
        {
                printf("P%d\t",i);
                for(j=0;j<r;j++)
                {
                        printf("%d\t",max[i][j]);
                }
		printf("\n");
        }

 	printf("\n\tNEED MATRIX\n");
        for(j=0;j<r;j++)
        {
                printf("\t%c ",65+j);
        }
	printf("\n");
        for(i=0;i<n;i++)
        {
                printf("P%d\t",i);
                for(j=0;j<r;j++)
                {
                        printf("%d\t",need[i][j]);
                }
		printf("\n");
        }
	fflush(stdin);	
	printf("\n\tAVAILABLE MATRIX\n");
        for(j=0;j<r;j++)
        {
                printf("\t%c ",65+j);
        }
        printf("\n\n");   
	fflush(stdin);
        for(j=0;j<r;j++)
        {
               printf("%d\t",available[j]);
        }

}

int main()
{
	int i;
	accept();
	calc_need();
	display();
	banker();
	if(scnt==n)
	{
		printf("\n\nSYSTEM IS IN SAFE STATE......");
		printf("\nSAFE SEQUENCE = ");
		for(i=0;i<scnt;i++)
			printf("P%d\t",seq[i]);
	}
	else
	{
		printf("\n\nGIVEN SYSTEM IS NOT IN SAFE STATE....");
	}
	
}
