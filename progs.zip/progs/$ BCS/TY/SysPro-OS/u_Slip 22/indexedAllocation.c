//Indexed ALLOCATION

#include<stdlib.h>		//for malloc() & free() functions
#include<stdio.h>
#include<string.h>

#define ENTRY (struct info *)malloc(sizeof(struct info))

int dsize;	//disk size

struct info
{
	char fname[10];
	int start,length,blocks[50];
	struct info *next;
};

struct info *E=NULL,*lastEntry=NULL;
int *D=NULL;
int used=0;

void init_disk()
{
	int i;
	D=(int*)malloc(sizeof(int)*dsize);	
	for(i=0;i<dsize;i++)
		D[i]=-1;		//means i'th block is not allocated...
}
int search()
{
	int i; 
	for(i=0;i<dsize;i++)
	{
		if(D[i]==-1)
			return i;
	}
	return -1;
}
void allocate()
{
	char fname[10];
	int length,blknum,i,b;
	
	struct info *t;
	printf("\nEnter file name =");
	scanf("%s",fname);
	
	printf("\nEnter length of file = ");
	scanf("%d",&length);

	if(length+1>dsize-used)
	{
		printf("\nERROR : NO DISK SPACE AVAILABLE.........");
		
	}
	else
	{
		printf("\nBLOCK IS ALOCATED.....");	
		used=used+length+1;
	
		t=ENTRY;
	
		blknum=search();
		strcpy(t->fname,fname);
		t->start=blknum;
		t->length=length+1;
		t->next=NULL;
		
		D[blknum]=1;
	
		b=0;		
		for(i=1;i<=length;i++)
		{
			blknum=search();
			t->blocks[b++]=blknum;
			D[blknum]=1;
		}
		
	

		
		if(E==NULL)
		{
			E=lastEntry=t;
		}
		else
		{
			lastEntry->next=t;
			lastEntry=lastEntry->next;
		}
		printf("\nBLOCK STATUS AFTER ALLOCATION = ");
		for(i=0;i<dsize;i++)
			printf("%d\t",D[i]);	
	}
}
void deallocate()
{
	struct info *f,*s;
	
	char fname[10];
	int start,length,i,blknum,flag=0;
	printf("\nEnter file name to delete = ");
	scanf("%s",fname);
	
	for(s=E;s!=NULL;s=s->next)
	{
		if(strcmp(s->fname,fname)==0)
		{
			flag=1;
			start=s->start;
				
			D[start]=-1;

			length=s->length;
			
			for(i=1;i<=length-1;i++)
                	{
				blknum=s->blocks[i-1];
				D[blknum]=-1;
				
			}
        
		        printf("\nBLOCK STATUS AFTER DE-ALLOCATION = ");
		        for(i=0;i<dsize;i++)
               		printf("%d\t",D[i]);

			if(s==E)		//first node
			{
				E=E->next;
				free(s);
				used=used-length;
				break;
			}
				//other node deleting
			for(f=E;f->next!=s;f=f->next)
			{
				
			}
		
			f->next=s->next;
			free(s);
			used=used-length;
			break;
		}		
	}
	
	if(flag==0)
	{
		printf("\nINVALID FILE NAME GIVEN TO DELETE........");
	}

}
void display_entry()
{
	int i;
	struct info *t;
	printf("\nFNAME\tINDEX_BLK\tLENGTH\tDATA_BLOCK\n");
	for(t=E;t!=NULL;t=t->next)
	{
		printf("\n%s\t%d\t\t%d\t",t->fname,t->start,t->length);
		for(i=0;i<t->length-1;i++)
		{
			printf(" %d,",t->blocks[i]);
		}
	}
	printf("\n USED BLOCK =%d",used);
	printf("\nFREE BLOCK  =%d",dsize-used);
} 
int main()
{
	int choice;
	printf("\nWhat is disk size = ");
	scanf("%d",&dsize);
	
	init_disk();
	while(1)
	{
		printf("\nMENU\n1:ALLOCATE SPACE FO NEWLY CREATED FILE\n2:DE-ALLOCATE SPACE FOR NOW DELETED FILE\n3:SHOW USED & FREE SPACE ON DISK\n4:EXIT\n");
		printf("\nENTER YOUR CHOICE = ");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1: allocate();	
				break;
			case 2:	deallocate();
				break;
			case 3:display_entry();
				break;
			case 4:exit(0);
		}
	}
	
}
