/*
Write a program to accept a program written in assembly language. After accepting
entire program list out errors wherever applicable.

a) Invalid statement
b) Invalid mnemonic

Consider following program as input
START 100 ,2
READ A
MOVER A,AREG
BDD AREG, A
A MOVEM AREG, '=2'
STOP
X DS 1
Y DS 1
END
PROGRAM
*/

#include<stdio.h>
#include<string.h>
#include<stdlib.h>
char opcode[11][6]={"STOP","READ","PRINT","ADD","SUB","MULT","DIV","MOVER","MOVEM","BC","COMP"};
char reg[4][5]={"AREG","BREG","CREG","DREG"};
char dc[2][3]={"DC","DS"};
char ad[2][666666]={"START","END"};
FILE *fp;
char fname[20],str[80],s1[20],s2[20],s3[20],s4[20],s5[20];
int w,lc=0,i;
char *op1,*op2,*label;
int isMN(char *);
int isSYM(char *);
int isDS(char *);
int isAD(char *);
int isNUM(char *);
int isREG(char *);

main()
{
	printf("\nEnter file name => ");
	scanf("%s",fname);
	fp=fopen(fname,"r");
	if(fp==NULL)
	{
		printf("\nFile does is not present");
		exit(0);
	}
	while(1)
	{
		fgets(str,80,fp);
		//puts(str);
		lc++;
		w=sscanf(str,"%s%s%s%s%s",s1,s2,s3,s4,s5);
		if(w>4)
		{
			printf("\n%s is invalid statement at %d line",str,lc);
			continue;
		}
		if(strcmp(s1,"END")==0)
		{
			/*if(strcmp(s2,"NULL")!=0)
			{
				printf("\n%s is invalid statement at %d line",str,lc);
			}*/
			break;
		}
		i=isMN(s1);
		if(i==-1)
		{
			i=isSYM(s1);
			if(i==-1)
			{
				printf("\n%s is invalid statement at %d line",str,lc);
				continue;
			}
			else
			{
				i=isMN(s2);
				if(i==-1)
				{
					printf("\n%s is invalid mnemonics at %d line",str,lc);
					continue;
				}
				else
				{
					label=s1;
					op1=s3;
					op2=s4;
				}
			}
		}
		else
		{
			label=NULL;
			op1=s2;
			op2=s3;
		}
		switch(i)
		{
			case 0:
				if((w>2)||((w==2)&&(label==NULL)))
				{
					printf("\n%s is invalid statement at %d line",str,lc);
					continue;
				}
				break;
			case 1:
			case 2:
				if((w>3)||(w==3)&&(label==NULL)||(isSYM(op1))==-1)
				{
					printf("\n%s is invalid statement at %d line",str,lc);
					continue;
				}
				break;
			case 3:
			case 4:
			case 5:
			case 6:
			case 7:
			case 8:
			case 9:
			case 10:
				if((w==4) &&(label==NULL)||(isREG(op1)==-1)||(isSYM(op2))==-1)
				{
					printf("\n%s is invalid statement at %d line",str,lc);
					continue;
				}
				break;
			case 20:
			case 21:
				if((w>2)||((w==2) &&(isNUM(op1)==-1))||(label!=NULL))
				{
					printf("\n%s is invalid statement at %d line",str,lc);
					continue;
				}
				break;
			case 30:
			case 31:
				if((w>3)||((w==3)&&(isNUM(op1)==-1))||(label==NULL))
				{
					printf("\n%s is invalid statement at %d line",str,lc);
					continue;
				}
				break;
		}
	}
}

int isMN(char *s)
{
	for(i=0;i<11;i++)
	{
		if(strcmp(s,opcode[i])==0)
		return i;
	}
	i=(isAD(s));
	if(i!=-1)
	return 20+i;
	i=(isDS(s));
	if(i!=-1)
	return 30+i;
	return -1;
}

int isSYM(char *s)
{
	if(s[0]<65 || s[0]>90)
	return -1;
	if(isMN(s)>=0)
	return -1;
	if(isREG(s)>=0)
	return -1;
	return 1;
}

int isREG(char *s)
{
	for(i=0;i<4;i++)
	{
		if(strcmp(s,reg[i])==0)
		return i;
	}	
	return -1;
}

int isDS(char *s)
{
	for(i=0;i<2;i++)
	{
		if(strcmp(s,dc[i])==0)
		return i;
	}
	return -1;
}

int isAD(char *s)
{
	for(i=0;i<2;i++)
	{
		if(strcmp(s,ad[i])==0)
		return i;
	}
	return -1;
}		

int isNUM(char *s)
{
	for(i=0;i<strlen(s);i++)
	{
		if(s[i]<47 || s[i]>57)
		return i;
	}
	return atoi(s);
}
/*
******************************
OUTPUT
*****************************

Enter file name => asm.txt

        START   100,    2
 is invalid statement at 1 line
        MOVER   A,      AREG
 is invalid statement at 3 line
        BDD     AREG,   A
 is invalid mnemonics at 4 line
A       MOVEM   AREG,   '=2'
 is invalid statement at 5 line

*/


