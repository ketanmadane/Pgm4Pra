/*
 7) Create a linked list containing the names of the days in a week. Display the menu that has following options (35 marks)
		a)Display the contents of the list using Iterator
		b)Display the contents of the list in reverse order using ListIterator
		c)Accept a day and display its index in the collection.
		d)Exit
 * */
import java.io.*;
import java.util.*;

class Q7
{
	LinkedList l;
	Q7()
	{
		String s[]={"Monday","TuesDay","Wednesday","Thursday","Friday","Saturday","Sunday"};
		l=new LinkedList();
		for(int i=0;i<s.length;i++)
			l.add(s[i]);
	}
	
	void display()
	{
		ListIterator ir=l.listIterator();
		int i=1;
		while(ir.hasNext())
		{
			System.out.println("Day "+i+" = "+ir.next());
			i++;
		}
		
	}
	void revDisplay()
	{
		ListIterator ir=l.listIterator();
		int i=7;
		while(ir.hasNext())
		{
			ir.next(); 
		}
		
		while(ir.hasPrevious())
		{
			System.out.println("Day "+i+" = "+ir.previous());
			i--;
		}
	}
	
	void showIndex() throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		
		System.out.print("Enter Day =");
		String w=dis.readLine();
		int i=l.indexOf(w);
		if(i>=0)
		{
			System.out.println("Index of Day="+i);
		}
		else
		{
			System.out.println("Element Does not Found !!!");
		}
	}		 
	public static void main(String args[])throws Exception
	{
		Q7 ob=new Q7();
		DataInputStream dis=new DataInputStream(System.in);
		
		while(true)
		{
			System.out.println("\nMENU\n1: Display the contents of the list using Iterator \n2:Display the contents of the list in reverse order using ListIterator \n3:Accept a day and display its index in the collection.\n4:Exit");
			System.out.print("Enter your choice= ");	
			int choice=Integer.parseInt(dis.readLine());
			
			switch(choice)
			{
				case 1: System.out.println("Days Of week");
						ob.display();
						break;
				case 2: System.out.print("\n\nDays Of week in Reverse");
						ob.revDisplay();
						break;
				case 3: ob.showIndex();
						break;
				case 4: System.exit(0);
				
				default: 
							System.out.println("Invalid Choice !!!");
			}		
		}
	}
}
