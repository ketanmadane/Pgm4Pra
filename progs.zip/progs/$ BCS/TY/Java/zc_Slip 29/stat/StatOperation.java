package stat;
public class StatOperation
{
	public static void average(int a,int b,int c)
	{
		System.out.println("\nAVERAGE ="+(double)(a+b+c)/3);
	}
	public static void  median(int a,int b,int c)
	{
		if((a>=b && a<=c) ||(a>=c && a<=b))	//b<a<c  c<a<b
		{
			System.out.println("\nMEDIAN = "+ a);
		}
		if((b>=a && b<=c)||(b>=c && b<=a))	//a<b<c  c<b<a
		{
			System.out.println("\nMEDIAN = "+ b);
		}
		if((c>=a && c<=b)||(c>=b && c<=a))	//a<c<b  b<c<a
		{
			System.out.println("\nMEDIAN = "+ c);
		}	
	}	
}