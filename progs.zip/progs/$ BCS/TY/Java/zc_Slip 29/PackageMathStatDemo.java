/* 
	* Create a package named 'math'. Define class MathOperation with static methods to find the maximum and minimum of three numbers.
	* Create another package 'stat'. Define class StatOperation with methods to find the average and median of three numbers.
	* Use this methods in main to perform operations on three integers accepted using command line argument.
*/
import java.io.*;
import math.MathOperation;
import stat.StatOperation;

public class PackageMathStatDemo
{
	public static void main(String args[])
	{
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		int c=Integer.parseInt(args[2]);
		
		MathOperation.maximum(a,b,c);
		MathOperation.minimum(a,b,c);
		
		StatOperation.average(a,b,c);
		StatOperation.median(a,b,c);
	}
}