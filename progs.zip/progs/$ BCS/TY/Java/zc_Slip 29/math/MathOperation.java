package math;
public class MathOperation
{
	public static void maximum(int a,int b,int c)
	{
		if(a>=b && a>=c)
		{
			System.out.println(a+" IS MAXIMUM ");
		}
		else if(b>=a && b>=c)
		{
			System.out.println(b+" IS MAXIMUM");
		}
		else
		{
			System.out.println(c+" IS MAXIMUM ");
			
		}
	}
	public static void minimum(int a,int b,int c)
	{
		if(a<=b && a<=c)
		{
			System.out.println(a+" IS MINIMUM ");
		}
		else if(b<=a && b<=c)
		{
			System.out.println(b+" IS MINIMUM");
		}
		else
		{
			System.out.println(c+" IS MINIMUM ");
		}
	}
}