/*	Q.26
	The first Scroll bar will handle red color; the second will handle green color and third will handle the blue color. 
	Set min = 0, max = 255 for the scroll bars. The screen has two labels and one command button �Apply�. When user clicks on the Apply button, set the background color of the label1 according to the RGB values set using the scrollbars. 
	Display the values of Red, Green, Blue in label2.
	
* */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

class Q26 extends JFrame
{
	MyPanel mp;
	Q26()
	{
		mp=new MyPanel();	
		setTitle("Q25");
		setSize(450,450);
		setVisible(true);
		add(mp);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String a[])
	{
		new Q26();
	}
}
class MyPanel extends JPanel implements ActionListener
{
	JScrollBar sbR,sbG,sbB;
    JLabel l2,rlab,glab,blab;
	JButton b;
	Color c=null;
	MyPanel()
	{
		setLayout(null);
		
		rlab=new JLabel("Red :",JLabel.CENTER);
		rlab.setSize(100,30);
		rlab.setLocation(30,30);	
		add(rlab);	
		
		sbR=new JScrollBar(JScrollBar.HORIZONTAL,0,0,0,255);//orientation,value,extent,min,max
		sbR.setSize(200,30);
		sbR.setLocation(150,30);
		sbR.setBackground(Color.RED);
		add(sbR);
		
		glab=new JLabel("Green :",JLabel.CENTER);
		glab.setSize(100,30);
		glab.setLocation(30,80);	
		add(glab);	
		
		sbG=new JScrollBar(JScrollBar.HORIZONTAL,0,0,0,255);//orientation,value,extent,min,max
		sbG.setSize(200,30);
		sbG.setLocation(150,80);
		sbG.setBackground(Color.GREEN);
		add(sbG);		
		
		blab=new JLabel("Blue :",JLabel.CENTER);
		blab.setSize(100,30);
		blab.setLocation(30,130);	
		add(blab);	
		
		sbB=new JScrollBar(JScrollBar.HORIZONTAL,0,0,0,255);//orientation,value,extent,min,max
		sbB.setSize(200,30);
		sbB.setLocation(150,130);
		sbB.setBackground(Color.BLUE);
		add(sbB);		
		
		l2=new JLabel("Label2 :",JLabel.CENTER);
		l2.setSize(200,30);
		l2.setLocation(180,210);	
		add(l2);
		
		b=new JButton("Apply");
		b.setSize(100,30);
		b.setLocation(150,270);
		b.addActionListener(this);
		add(b);
	}
	public void actionPerformed(ActionEvent ae)
	{
		int rvalue=sbR.getValue();
		int gvalue=sbG.getValue();
		int bvalue=sbB.getValue();
		
		c=new Color(rvalue,gvalue,bvalue);
		
		String s="Red="+rvalue+" Green= "+gvalue+" Blue="+bvalue;	
		l2.setText(s);
		repaint();
	}
	public	void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D gob=(Graphics2D)g;
		
		if(c!=null)
		{
			Rectangle2D r=new Rectangle2D.Double(30,210,100,50);
			gob.setColor(c);
			gob.fill(r);
			gob.setColor(Color.BLACK);
			gob.drawString("Label 1",50,230);
		}
	}
}