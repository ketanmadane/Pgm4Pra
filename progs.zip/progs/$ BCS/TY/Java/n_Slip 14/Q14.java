/*
	14)	Write a Java Program to create a Hash table to store book id and book name. 
	Book id and name should be accepted from the console. Write a menu driven program to add, search, delete and display the contents of the hash table. 
	Display the contents of the hash table in tabular format. 
	Display all the options till Exit is selected. (Do not use Swing).
*/
import java.io.*;
import java.util.*;

class Q14
{
	Hashtable ht;
	Q14()
	{
		ht=new Hashtable();
	}
	public void add()throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.print("Enter Book Id=");
		int id=Integer.parseInt(dis.readLine());
		System.out.print("Enter Book Name=");
		String bname=dis.readLine();
		ht.put((Object)id,(Object)bname);
	}
	void display()
	{
		Enumeration key=ht.keys();
		System.out.println("ID \t Name");
		while(key.hasMoreElements())
		{
			
			Object id=key.nextElement();
			System.out.println(id+" \t "+ht.get(id));
		}
	}
	void search(int tid)
	{
		Enumeration key=ht.keys();
		while(key.hasMoreElements())
		{
			
			int id=Integer.parseInt(key.nextElement().toString());
			if(id==tid)
			{	System.out.println("Record Found !!!");
				System.out.println(id+" \t "+ht.get(id));
				return;
			}
		}
		System.out.println("Record Not Found !!!!");
	}
	
	void delete(int tid)
	{
		Enumeration key=ht.keys();
		while(key.hasMoreElements())
		{
			
			int id=Integer.parseInt(key.nextElement().toString());
			if(id==tid)
			{	
				ht.remove((Object)id);
				System.out.println("Record Deleted  !!!");
				
				return;
			}
		}
		System.out.println("Record Not Found !!!!");
	}
	public static void main(String args[])throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		
		Q14 ob=new Q14();
		while(true)
		{
			System.out.println("\nMENU\n1:ADD BOOK\n2:DISPLAYS DETAILS OF BOOK\n3:SEARCH BOOK\n4:DELETE BOOK\n5:EXIT");
			System.out.print("\nENTER YOUR CHOICE = ");
			int choice=Integer.parseInt(dis.readLine());
			switch(choice)
			{
				
				case 1: //add
					ob.add();
					break;
				case 2 : //display all info
					ob.display();
					break;
				case 3 : //search
					System.out.print("\nEnter id to search = ");
					int id1 =Integer.parseInt(dis.readLine());
					ob.search(id1);
					break;
				case 4 :// Delete REcord
					System.out.print("\nEnter id to delete = ");
					int id2 =Integer.parseInt(dis.readLine());
					ob.delete(id2);
					break;
				case 5 : System.exit(0);
					default : System.out.println("INVALID CHOICE..........");
			}
		}
	}
}