/* When the user clicks on the even button, your program should keep on displaying even numbers till the user clicks on respective stop. 
	Similarly, when the user clicks on the odd button, your program should keep on displaying odd numbers till the user clicks on its respective stop.
	(User may fix the range of even and odd numbers)
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Date;
class Q13 extends JFrame implements ActionListener
{
	TextArea todd,teven;
	JButton even,estop,odd,ostop;
	MyThread t1,t2;
	
	Q13()
	{
		setLayout(null);
		teven=new TextArea();
		teven.setSize(200,100);
		teven.setLocation(10,10);
		add(teven);
		
		todd=new TextArea();
		todd.setSize(200,100);
		todd.setLocation(250,10);
		add(todd);
		
		
		even=new JButton("EVEN");
		even.setSize(100,30);
		even.setLocation(20,200);
		even.addActionListener(this);
		add(even);
		
		estop=new JButton("STOP");
		estop.setSize(100,30);
		estop.setLocation(130,200);
		estop.addActionListener(this);
		add(estop);
		
		odd=new JButton("ODD");
		odd.setSize(100,30);
		odd.setLocation(240,200);
		odd.addActionListener(this);
		add(odd);
		
		ostop=new JButton("STOP ");
		ostop.setSize(100,30);
		ostop.setLocation(350,200);
		ostop.addActionListener(this);
		add(ostop);
		
		setTitle("Time");
		setSize(500,500);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String str=ae.getActionCommand();
		
		if(str.compareTo("EVEN")==0)
		{
			t1=new MyThread(0,100,teven);
			t1.start();	//Starting thread
		}
		if(str.compareTo("ODD")==0)
		{
			t2=new MyThread(1,100,todd);
			t2.start();	//Starting thread
		}
		if(str.compareTo("STOP")==0)
		{	
			t1.stop();	//stoping thread
		}
		if(str.compareTo("STOP ")==0)
		{	
			t2.stop();	//stoping thread
		}
	}
	
	public static void main(String args[])throws Exception
	{
		Q13 ob=new Q13();
	}
}
class MyThread extends Thread
{
	static int start,end;
	TextArea ta;
	MyThread(int s,int e,TextArea t)
	{
		start=s; 
		end=e;
		ta=t;
	}
	public void run()
	{
		try
		{		
			while(true)
			{
				for(int i=start;i<=end;i=i+2)
				{
					ta.append("\n"+i);
					sleep(1000);
				}
			}
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(null,e);
		}
	}
}