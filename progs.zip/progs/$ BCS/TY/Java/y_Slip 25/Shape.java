
import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;

public class Shape extends JFrame
{
	Shape()
	{
		setTitle("ShapeDemo");
		setSize(751,657);
		
		MyPanel p = new MyPanel();
		p.setForeground(Color.black);
		add(p);
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}										
 	public static void main(String args[])
	{
		new Shape();
	}
}
class MyPanel extends JPanel
{
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D)g;
		
		Rectangle2D r1 = new Rectangle.Double(10,10,700,600);
		g2.setColor(Color.red);
		g2.fill(r1);
		
		
		Ellipse2D e1 = new Ellipse2D.Double(80,80,500,500);
		g2.setColor(Color.yellow);
		g2.fill(e1);
		
		
		
		Ellipse2D e2 = new Ellipse2D.Double(150,170,350,350);
		g2.setColor(Color.blue);
		g2.fill(e2);
		
		
		Rectangle2D r2 = new Rectangle.Double(250,300,170,90);
		g2.setColor(Color.red);		
		g2.fill(r2);
	}	
}