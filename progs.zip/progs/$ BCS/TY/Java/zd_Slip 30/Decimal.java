/* Convert Decimal to Binary & octal & HexaDecimal */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

public class Decimal extends JFrame implements ActionListener 
{
	JLabel l1,l2,l3,l4;
	JTextField t1,t2,t3,t4;
	JButton b1;
	int n1;
	
	Decimal()
	{
		setLayout(null);		
		setTitle("Conversion Demo");
		
		l1 = new JLabel("Decimal  Number:");
		l2 = new JLabel("Binary   Number:");	
		l3 = new JLabel("Octal    Number:");
		l4 = new JLabel("Hexdecimal Number:");
		
		t1 = new JTextField(  );
		t2 = new JTextField(  );
		t3 = new JTextField(  );
		t4 = new JTextField(   );
		
		Font f = new Font("Serif",Font.BOLD,15);
		
		t1.setFont(f);	
		t2.setFont(f);
		t3.setFont(f);		
		t4.setFont(f);
		
		t2.setEditable(false);
		t3.setEditable(false);				
		t4.setEditable(false);
		
		b1 = new JButton("CALCULATE");
		
		l1.setBounds(150,30,300,300);	// setBounds(x,y,width,height); => setSize() & setLocation()
		t1.setBounds(300,170,100,30);		
		
		
		l2.setBounds(150,150,300,300);
		t2.setBounds(300,290,300,30);		
		
		l3.setBounds(150,270,300,300);
		t3.setBounds(300,410,300,30);		
		
		
		l4.setBounds(150,390,300,300);
		t4.setBounds(310,530,300,30);		
		
		b1.setBounds(300,600,150,50);
		
		add(l1);
		add(t1);
		
		add(l2);
		add(t2);
		
		add(l3);
		add(t3);
		
		add(l4);
		add(t4);
		
		add(b1);			
		b1.addActionListener(this);
		
		setSize(1000,718);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public static void main(String args[])
	{
		new Decimal();
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		JButton b = (JButton)ae.getSource();
		
		if(b == b1)
		{
			n1 = Integer.parseInt(t1.getText());
			
			t2.setText(Integer.toBinaryString(n1));
			t3.setText(Integer.toOctalString(n1));
			t4.setText(Integer.toHexString(n1));
			
		}
	}
}


/* for L4 adding values in l3 	
	
	l3.setBounds(150,270,300,300);
	
	l4 :  (1) 150 
	
	(2) 270 + 120 = 390.
	
	(3) 300
	
	(4) 300
	
	
	
	l4(150,270,300,300)
	
	--------------------------------
	
	t3.setBounds(300,410,300,30);		
	
	
	t4:
	
	(1) 300 
	(2) 410 + 120 = 530
	(3) 300
	(4)30
	
	t4(300,530,300,30)
	
	
	*/							