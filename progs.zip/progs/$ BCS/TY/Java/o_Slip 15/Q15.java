/*
	15)Write a Java program to accept �n� student names from console and display the sorted list in descending order (Use Comparator). (35 marks)
	(Note: The examiners can change the data that is to be stored in the List i.e instead of student names, accept �n� book names or item names or city names etc.)
* */
import java.io.*;
import java.util.*;
class Q15
{
	ArrayList a;
	Q15()
	{
		a=new ArrayList();
	}
	void accept() throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.print("How many Names : ");
		int n=Integer.parseInt(dis.readLine());
		
		for(int i=1;i<=n;i++)
		{
			System.out.print("Enter Name: ");
			String s=dis.readLine();
			a.add(s);
		}
	}
	
	void display()
	{
		Iterator ir=a.iterator();
		
		int i=1;
	while(ir.hasNext())
	{
	System.out.println("Student "+i+" : "+ir.next()); 
	}
	}
	
	public static void main(String args[])throws Exception
	{
		Q15 ob=new Q15();
		
		ob.accept();
		System.out.println("Before sorting - "+ob.a);
		
		Collections.sort(ob.a,new StudentComparator());		
		
		System.out.println("After sorting - "+ob.a);
	}
}

class StudentComparator implements Comparator
{
	public int compare(Object a,Object b)
	{
		String ob1=(String)a;
		String ob2=(String)b;
		
		return (-ob1.compareTo(ob2));
		
	}
}