/* 
	Write a server program which echoes messages sent by the client. The process continues till the client types “END”.
*/

import java.io.*;
import java.net.*;

class ServerB2
{	
	public static void main(String arsg[])throws Exception
	{
		
		ServerSocket ssob;
		Socket csob;
		
		InputStream is;
		OutputStream os;
		
		DataInputStream dis;
		DataOutputStream dos;
		
		ssob = new ServerSocket (14200);
		System.out.print("\n  Server Started:");
		
		csob = ssob.accept();
		
		System.out.print("\n Cilent connected:");
		
		is = csob.getInputStream();
		os = csob.getOutputStream();
		
		dis = new DataInputStream(is);
		dos = new DataOutputStream(os);
		
		while(true)
		{
			String msg = dis.readUTF();
			
			if(msg.equals("END"))
			break;
			else
			dos.writeUTF("msg="+msg);
		}	
		
		ssob.close();
		csob.close();
	}
}


/*  OUTPUT
	
	javac ClientB2.java
	[root@localhost ~]# java ClientB2
	
	Enter the string
	sachin Dhane
	message from servermsg=sachin Dhane
	
	Enter the string
	Old Sangvi
	message from servermsg=Old Sangvi
	
	Enter the string
	9028282629
	message from servermsg=Old Sangvi
	
	Enter the string
	END
	
*/