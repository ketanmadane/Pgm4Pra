import java.io.*;
import java.net.*;

class ClientB2
{
	public static void main(String args[])throws Exception
	{
		Socket csob;
		
		InputStream is;
		OutputStream os;
		
		DataInputStream dis;
		DataOutputStream dos;
		
		csob = new Socket("localhost",14200);
		
		is = csob.getInputStream();
		os = csob.getOutputStream();
		
		dis = new DataInputStream(is);
		dos = new DataOutputStream(os);
		
		BufferedReader br = new BufferedReader(new InputStreamReader		(System.in));
		
		while(true)
		{
			System.out.println("\n Enter the string");
			String s1 = br.readLine();
			
			if(s1.equals("END"))
			{
				dos.writeUTF(s1);
				break;
			}
			dos.writeUTF(s1);
			String msg = dis.readUTF();
			System.out.println("message from server"+msg);
			}
			
			csob.close();
			}
			}			