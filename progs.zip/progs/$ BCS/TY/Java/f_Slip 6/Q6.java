/*
	Q.6)Create two singly linked lists for string data and perform following operations(35 marks)
	a)Add element in list1
	b)Add element in list2
	c)Union
	d)Display the reverse of the linked list after the union of lists
	e)Intersection
	f)exit
	
* */
import java.io.*;
import java.util.*;

class Q6
{
	LinkedList l1,l2;
	Q6()
	{
		l1=new LinkedList();
		l2=new LinkedList();
	}
	static void accept(LinkedList l)throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.print("How many elements u want to accept = ");
		int n=Integer.parseInt(dis.readLine());
		for(int i=0;i<n;i++)
		{
			System.out.print("Enter the string = ");
			String str=dis.readLine();
			if(!l.contains(str))	//logic to do not add duplicate elements into the linked list.....
			{
				l.add(str);
			}
			else
			{
				System.out.println(str+" already prsent in linked list,so can not add............");
				i--;
				
			}
		}
	}
	static void display(LinkedList l)
	{
		ListIterator ir=l.listIterator();
		int i=1;
		while(ir.hasNext())
		{
			System.out.println("Element "+i+" = "+ir.next());
			i++;
		}
		
	}
	void union()
	{
		LinkedList l3=new LinkedList();
		
		/* ADDING FIRST LINKEDLIST DATA INTO THIRD LIST....*/
		for(int i=0;i<l1.size();i++)
		{
			l3.add(l1.get(i));
		}
		
		/* ADDING SECOND LINKEDLIST DATA INTO THIRD LIST*/
		for(int i=0;i<l2.size();i++)
		{
			String str=(String)l2.get(i);
			if(!l3.contains(str))
			l3.add(str);
		}
		System.out.println("\t\t\tUNION OF FIRST AND SECOND LINKED LIST.........");
		display(l3);
		
		System.out.println("\t\t\tREVERSE OF UNION OF FIRST AND SECOND LINKED LIST.........");
		revDisplay(l3);
		
	}
	static void revDisplay(LinkedList l)
	{
		ListIterator ir=l.listIterator();
		int i=1;
		while(ir.hasNext())
		{
			ir.next(); 
			
		}
		
		while(ir.hasPrevious())
		{
			System.out.println("Element "+i+" = "+ir.previous());
			i++;
		}
	}
	void intersection()
	{
		LinkedList l3=new LinkedList();
		
		for(int i=0;i<l1.size();i++)
		{
			String str=(String)l1.get(i);
			if(l2.contains(str))
			{
				l3.add(str);
			}
		}
		System.out.println("\t\t\tINTERSECTION OF FIRST AND SECOND LINKED LIST.........");
		display(l3);
		
	}
	
	public static void main(String args[])throws Exception
	{
		Q6 ob=new Q6();
		System.out.println("\t\t\tACCEPTING DATA FOR LINKEDLIST  FIRST.........");
		accept(ob.l1);
		System.out.println("\t\t\tACCEPTING DATA FOR LINKEDLIST  SECOND.........");
		accept(ob.l2);
		System.out.println("\t\t\tDISPLAYING DATA FOR LINKEDLIST  FIRST.........");
		display(ob.l1);
		System.out.println("\t\t\tDISPLAYING DATA FOR LINKEDLIST  SECOND.........");
		display(ob.l2);
		
		ob.union();		// displaying union of 2 linked list	
		ob.intersection();	//displaying intersection of 2 linkedlist
	}
}
