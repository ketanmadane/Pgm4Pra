/* Q.12)Write a Java thread program that displays the string �Welcome to Java� that moves horizontally from left hand side of a frame/panel to the right hand side. 
**/

import java.awt.*;
import javax.swing.*;

class Q12 extends JFrame implements Runnable
{
	JLabel l;
	Thread t;
	
	Q12()
	{
		setLayout(null);
		l=new JLabel("Welcome To Java !!!");
		l.setSize(200,30);
		l.setLocation(50,50);
		add(l);
		
		setTitle("Message Display");
		setSize(300,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		t=new Thread(this);
		t.start();
	}
	public void run()
	{
		try
		{
			int i=0;
			while(true)
			{
				l.setLocation(i,30);
				i++;
				if(i>=300)
					i=0;
				Thread.sleep(10);
			}
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
	}
	
	public static void main(String args[])throws Exception
	{
		Q12 ob=new Q12();
	}
}