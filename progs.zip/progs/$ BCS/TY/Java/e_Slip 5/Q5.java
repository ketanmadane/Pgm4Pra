
import java.io.*;	
import java.sql.*;
class Q5
{	Connection con;	Statement stmt;	   
	PreparedStatement ps; 	
	ResultSet res;
	
	Q5()throws Exception
	{
		Class.forName("org.gjt.mm.mysql.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost/tybcs","root","");
		if(con==null)
		{	System.out.println("Connnection Failed");
			System.exit(0);
		}
	}
	void displayAll()throws SQLException
	{
		stmt=con.createStatement();
		res=stmt.executeQuery("select * from stud");	
		System.out.println("\nRollNo Name  M1  M2  M3  Total  PerCentage");
		while(res.next())
		{       				
			int m1=res.getInt(3);
			int m2=res.getInt(4);
			int m3=res.getInt(5);
			int total=m1+m2+m3;
			double per=(double)total/3;
	 		System.out.println(res.getInt(1)+"\t"+res.getString(2)+"\t"+m1+"\t"+m2+"\t"+m3+"\t"+total+"\t"+per);
		}
	}
	void insert()throws IOException,SQLException
	{
		DataInputStream dis=new DataInputStream(System.in);
		ps=con.prepareStatement("insert into stud values(?,?,?,?,?)");
		System.out.print("\nEnter Roll No= ");      
		int rno=Integer.parseInt(dis.readLine());
		System.out.print("Enter Name = "); 	   
		String name=dis.readLine();
		System.out.print("Marks 1= ");      int m1=Integer.parseInt(dis.readLine());
		System.out.print("Marks 2= ");      int m2=Integer.parseInt(dis.readLine());
		System.out.print("Marks 3= ");      int m3=Integer.parseInt(dis.readLine());
		ps.setInt(1,rno);	                ps.setString(2,name);                
		ps.setInt(3,m1);	ps.setInt(4,m2);	ps.setInt(5,m3);		
		ps.executeUpdate();
	}
    public static void main(String args[])throws Exception
	{	
		DataInputStream dis=new DataInputStream(System.in);
		Q5 ob=new Q5();
		while(true)
		{   System.out.println("Do you want to add more 1:Yes 0:NO");
			System.out.print("Enter your choice : ");
			int choice=Integer.parseInt(dis.readLine());
			switch(choice)
			{	case 1 :ob.insert(); break;
				case 0: ob.displayAll();
				System.exit(0);		
				default: System.out.println("Invalid choice pllease enter valid input.... ");
			}
		}
	}
}

