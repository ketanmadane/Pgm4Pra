/* Q.4)Write program to create a window that has a textbox/label to show current time. The time should be displayed in hh:mm:ss format. 
	*The thread should start displaying the time when the user clicks the Start button and stop when the user clicks the Stop button.
**/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Date;
class Q4 extends JFrame implements ActionListener,Runnable
{
	JLabel l;
	JButton start,stop;
	Thread t;
	
	Q4()
	{	
		setLayout(null);
		l=new JLabel();
		l.setSize(200,30);
		l.setLocation(50,50);
		add(l);
		
		start=new JButton("START");
		start.setSize(100,30);
		start.setLocation(20,100);
		start.addActionListener(this);
		add(start);
		
		stop=new JButton("STOP");
		stop.setSize(100,30);
		stop.setLocation(150,100);
		stop.addActionListener(this);
		add(stop);
		
		setTitle("Time");
		setSize(300,300);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void actionPerformed(ActionEvent ae)
	{
		String str=ae.getActionCommand();
		
		if(str.compareTo("START")==0)
		{
			t=new Thread(this);
			t.start();	//Starting thread
		}
		if(str.compareTo("STOP")==0)
		{	
			t.stop();	//stoping thread
		}
	}
	public void run()
	{
		while(true)
		{
			Date d=new Date();
			int h=d.getHours();
			int m=d.getMinutes();
			int s=d.getSeconds();
			String str="TIME:"+h+":"+m+":"+s;
			l.setText(str);
		}
	}
	
	public static void main(String args[])throws Exception
	{
		Q4 ob=new Q4();	
		
	}
}