/* 
	Write a servlet which counts how many times a user visited a web page. If the user is visiting the page for the first time,display the welcome 
	message. if the user is revisiting the page, diplay the number of times visited. (Use cookies)
*/

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Servlet_a3 extends HttpServlet
{
	int hit=0;
	public void doGet(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
		res.setContentType("text/html");
		PrintWriter pw=res.getWriter();
		Cookie []c=req.getCookies();
		Cookie ck=null;
		
		if(hit==0)
		{
			pw.println("<h1>welcome</h1>");
			hit++;
			String scnt=Integer.toString(hit);
			ck=new Cookie("page",scnt);
			res.addCookie(ck);
		}
		else
		{
			
			for(int i=0;i<c.length;i++)
			{
				if((c[i].getName()).compareTo("page")==0)
				{
					hit=Integer.parseInt(c[i].getValue());
					
					pw.println("You have visited "+hit+"times<br>");
					hit++;	
					String scnt=Integer.toString(hit);
					ck=new Cookie("page",scnt);	
					res.addCookie(ck);
					break;
				}
				
			}
		}	
		
		pw.close();
	}
}