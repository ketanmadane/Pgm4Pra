/* 
	Write a client-server program which displays the server machine’s date 		and time on the client machine.
*/

import java.io.*;
import java.net.*;
import java.util.*;

class ServerA1
{
	public static void main(String args[])throws IOException
	{
		ServerSocket ssob;
		Socket csob;
		
		InputStream is;
		OutputStream os;
		
		DataInputStream dis;
		DataOutputStream dos;
		
		ssob = new ServerSocket (13200);
		System.out.print("\n  Server Started:");
		
		csob = ssob.accept();
		
		System.out.print("\n Cilent connected:");
		
		is = csob.getInputStream();
		os = csob.getOutputStream();
		
		dis = new DataInputStream(is);
		dos = new DataOutputStream(os);
		
		String msg = new Date().toString();
		dos.writeUTF(msg);
		csob.close();
		csob.close();
	}
}



/* Output
	
	javac ServerA1.java
	[root@localhost ~]# java ServerA1
	
	Server Started:
	Cilent connected:
	
	
	Run - : Fist compile the both program on different terminal & Run fist the 
	server program & then run client program on different terminal
*/