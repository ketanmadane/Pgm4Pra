import java.io.*;
import java.net.*;
import java.util.*;

class ClientA1
{
	public static void main(String args[])throws Exception
	{
		Socket csob;
		InputStream is;
		OutputStream os;
		
		DataInputStream dis;
		DataOutputStream dos;
		
		csob = new Socket("localhost",13200);
		
		is = csob.getInputStream();
		os = csob.getOutputStream();
		
		dis = new DataInputStream(is);
		dos = new DataOutputStream(os);
		
		String msg = dis.readUTF();
		System.out.print("\n Server Date & time = "+msg);
		
		csob.close();
	}
}

/* 
output

Server Date & time = Sun Dec 25 19:42:08 IST 2011[

*/