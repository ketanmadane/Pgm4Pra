/*	ASSIGNMENT 3 : SET-A : Q.1 & Q.3			JDBC
	* CREATE A STUDENT TABLE WITH FIELDS ROLLNUMBER,NAME,PERCENTAGE.
	* INSERT VALUES IN THE TABLE.
	* DISPLAY ALL THE DETAILS OF THE STUDENT TABLE USING JDBC.
	* DISPLAY ALL COLUMN INFORMATION OF STUDENT (Q.3)
* */
import java.io.*;
import java.sql.*;

class StudentJdbc
{
	public static void main(String args[])throws Exception
	{
		Connection con=null;
		Statement stmt=null;
		ResultSet res=null;
		ResultSetMetaData rsmd=null;	//used to print info about table, col etc.
		
		DataInputStream dis=new DataInputStream(System.in);
		System.out.print("Enter name of the table =");
		String tname=dis.readLine();
		
		Class.forName("org.gjt.mm.mysql.Driver");//loading driver
		con=DriverManager.getConnection("jdbc:mysql://localhost/tybcs","root","");// getting connection
		if(con==null)
		{
			System.out.println("Connection failed........");
			System.exit(0);
		}
		
		stmt=con.createStatement();
		res=stmt.executeQuery("Select * from "+tname);
		
		System.out.println("Displaying information of student Table");
		rsmd=res.getMetaData();
		int noOfColumn=rsmd.getColumnCount();
		System.out.println("No.of Column in Student table = " + noOfColumn);
		System.out.println("\nColumn_Name Column_Type Column_Size");
		for(int i=1;i<=noOfColumn;i++)
		{
			System.out.println(rsmd.getColumnName(i)+"\t"+rsmd.getColumnTypeName(i)+"\t\t"+rsmd.getColumnDisplaySize(i));
		}
		
		//Displaying no.of records in table
		res=stmt.executeQuery("Select count(*) from "+tname);
		res.next();
		int rowCnt=res.getInt(1);
		System.out.println("No.of records in table="+rowCnt);
	}
}