/*
	Write a menu driven JDBC program to display the first record, last record, middle record, nthrecord of a student.
	Student table should contain student id, name and class)(35 marks) 
	Note : Examiners can replace Student table with Item, Book, Supplier, Customer, Doctor, Patient or any other and provide the design of the table)
*/

import java.io.*;
import java.sql.*;
class Q3
{
	Connection con=null;
	Statement stmt=null;
	ResultSet rs;
	
	Q3() throws Exception
	{
		Class.forName("org.gjt.mm.mysql.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost/tybcs","root","");
		if(con==null)
		{
			System.out.println("Connection Failed !!!!");
			System.exit(0);
		}
	}
	
	void dispFirstRecord()throws Exception
	{
		stmt=con.createStatement();
		rs=stmt.executeQuery("select * from student order by rno asc");
		
		while(rs.next())
		{
			System.out.print("FIRST RECORD : ");
			System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Per="+rs.getDouble(3));
			//System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Class="+rs.getString(3));
			break;
		}	
	}
	
	void dispLastRecord()throws Exception
	{
		stmt=con.createStatement();
		rs=stmt.executeQuery("select * from student order by rno desc");
		
		while(rs.next())
		{
			System.out.print("LAST RECORD : ");
			System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Per="+rs.getDouble(3));
			//System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Class="+rs.getString(3));
			break;
		}	
	}
	
	void dispMidRecord() throws Exception
	{
		ResultSet temp=null;
		stmt=con.createStatement();
		temp=stmt.executeQuery("select count(*) from student");
		temp.next();		
		int cnt=temp.getInt(1);	//getting count of record
		
		stmt=con.createStatement();
		rs=stmt.executeQuery("select * from student order by rno asc");
		
		int mid=(int)cnt/2;	
		int i=1;
		
		while(rs.next())
		{	
			if(i!=mid)
			{
				i++;
				continue;
			}
			
			System.out.print("MIDDLE RECORD : ");
			System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Per="+rs.getDouble(3));
			//System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Class="+rs.getString(3));
			break;
		}
	}
	void dispNthRecord() throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.print("Which Record you want to display enter number:");
		int n=Integer.parseInt(dis.readLine());
		
		stmt=con.createStatement();
		rs=stmt.executeQuery("select * from student order by rno asc");
		
		int i=1;
		
		while(rs.next())
		{	
			if(i!=n)
			{
				i++;
				continue;
			}
			
			System.out.print(n +"th RECORD : ");
			System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Per="+rs.getDouble(3));
			//System.out.println("Rno="+rs.getInt(1)+" Name : " +rs.getString(2)+" Class="+rs.getString(3));
			break;
		}
	}
	
	public static void main(String args[]) throws Exception
	{
		
		Q3 ob=new Q3();
		
		ob.dispFirstRecord();	//Displaying first record
		ob.dispLastRecord();	//Displaying first record
		ob.dispMidRecord();		//Displaying Middle record	
		ob.dispNthRecord();		//Displaying nth record	
		
	}
}
