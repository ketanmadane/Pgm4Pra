/*  
	Q1) Write a Java program to create a class FileWatcher that can be given several filenames that may or may not exist. The class should start a thread for each filename. Each thread will periodically check for the existence of its file. 
	If the file exists, then thread will display the details of the file (viz. filename, permissions and size) on the console and then end. 
	If file does not exist then display appropriate error message.
* */

import java.io.*;

class FileWatcher extends Thread
{
	String fname;
	FileWatcher(String fname)
	{
		this.fname=fname;
	}
	public void run()
	{
		try
		{
			File f=new File(fname);
			if(f.exists())
			{
				System.out.println("\n"+fname+" EXIST ");
				System.out.println("File Name:"+f.getName());
				System.out.println("File Size:"+f.length());
			}
			else
			System.out.println("\n"+fname+" DOES NOT EXISTS ");
			sleep(2000);
		}
		catch(InterruptedException e)
		{
			System.out.println(e);
		}
	}
}

public class FileWatcherDemo
{
	public static void main(String args[]) throws Exception
	{
		DataInputStream dis=new DataInputStream(System.in);
		System.out.print("\nHow many files want to check= ");
		int n=Integer.parseInt(dis.readLine());
		for(int i=0;i<n;i++)
		{
			System.out.print("\nEnter File names = ");
			String name=dis.readLine();
			FileWatcher t=new FileWatcher(name);
			t.start();
			Thread.sleep(2000);
		}
	}
}

/*
	* [root@localhost 1]# java FileWatcherDemo 
	*
	* How many files want to check= 2
	*
	* Enter File names = FileWatcherDemo.java
	*
	* FileWatcherDemo.java EXIST 
	* File Name:FileWatcherDemo.java
	* File Size:1402
	*
	* Enter File names = a.txt
	*
	* a.txt DOES NOT EXISTS 
	* [root@localhost 1]# 
	*
	*
* */ 