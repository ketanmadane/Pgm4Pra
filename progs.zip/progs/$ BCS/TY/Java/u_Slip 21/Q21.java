import java.io.*;
class Stud
{
	String rollno;
	String name;
	String percentage;
	Stud()
	{
	}
	Stud(String rollno,String name,String percentage)
	{
		this.rollno=rollno;
		this.name=name;
		this.percentage=percentage;
	}
	long store(RandomAccessFile f)throws IOException
	{
		long pos=f.getFilePointer();
		f.writeUTF(rollno);
		f.writeUTF(name);
		f.writeUTF(percentage);
		return pos;
	}
	void access(RandomAccessFile f)throws IOException
	{
		rollno=f.readUTF();
		name=f.readUTF();
		percentage=f.readUTF();
		System.out.print(toString());
		
	}
	public String toString()
	{
		return "Rollno ="+rollno+"\n"+"Name ="+name+"\n"+"Percentage ="+percentage+"\n";
	}
}

public class Q21
{
	public static void main(String a[])throws IOException
	{
		RandomAccessFile f=new RandomAccessFile("Student.dat","rw");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Stud s;
		System.out.print("\nEnter How Many Entries:");
		int n=Integer.parseInt(br.readLine());
		String[] nameTable=new String[n];
		long[] posTable=new long[n];
		for(int i=0;i<n;i++)
		{
			System.out.print("\nEnter RollNo :-");
			String rollno=br.readLine();
			System.out.print("\nEnter Name :- ");
			String name=br.readLine();
			System.out.print("\nEnter Percentage:-");
			String percentage=br.readLine();
			s=new Stud(rollno,name,percentage);
			nameTable[i]=rollno;
			posTable[i]=s.store(f);
			
		}
		f.close();
		boolean done=false;
		RandomAccessFile f1=new RandomAccessFile("Student.dat","r");
		Stud s1=new Stud();
		while(!done)
		{
			System.out.print("\nEnter The RollNo to Search:");
			String rollno=br.readLine();
			boolean found=false;
			for(int i=0;i<n;i++)
			if(nameTable[i].equals(rollno))
			{
				f1.seek(posTable[i]);
				s1.access(f1);
				found=true;
			}
			if(!found)
				System.out.print("\n Sorry!record not found");
			System.out.print("\nDo You Want to Continue  Y/N");
			String ans=br.readLine();
			if(ans.equals("N"))
			done=true;
		}
		f1.close();
	}
}