/*  Assig 7 (Set A - 2)
	
	Write a program which sends the name of a text file from the client to server and displays the contents of the file on the client machine. If the file is not found, display an error message.
*/

import java.io.*;
import java.net.*;

class ServerA2
{	
	public static void main(String arsg[])throws IOException
	{
		ServerSocket ssob;
		Socket csob;
		
		InputStream is;
		OutputStream os;
		
		DataInputStream dis;
		DataOutputStream dos;
		
		ssob = new ServerSocket(13200);
		System.out.print("\n  Server Started:");
		
		csob = ssob.accept();
		
		System.out.print("\n Cilent connected:");
		
		is = csob.getInputStream();
		os = csob.getOutputStream();
		
		dis = new DataInputStream(is);
		dos = new DataOutputStream(os);
		
		String fname = dis.readUTF();
		File f = new File(fname);
		
		if(f.exists())
		{
			FileReader fr = new FileReader(fname);
			
			String msg = "",str = "";
			
			BufferedReader br = new BufferedReader(fr);		
			
			while((str = br.readLine())!=null)
			{
				msg = msg+str+"\n";
			}
			dos.writeUTF("Content of File Are :-\n"+msg);			
			dos.writeUTF("stop");					 			
			
		}
		else
		{
			dos.writeUTF(fname+"does not exists");
			dos.writeUTF("stop");				
		}
		csob.close();
		ssob.close();
	}
}


/* output
	
	Enter File Name:       a.txt
	CONTENTS OF FIE ARE :-
	
	
	A
	B
	C
	D
	F
	G
	
*/