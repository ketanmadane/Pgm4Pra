import java.io.*;
import java.net.*;


class ClientA2
{
	public static void main(String args[])throws IOException
	{
		Socket csob;
		
		InputStream is;
		OutputStream os;
		
		DataInputStream dis;
		DataOutputStream dos;
		
		csob = new Socket("localhost",13200);
		
		is = csob.getInputStream();
		os = csob.getOutputStream();
		
		dis = new DataInputStream(is);
		dos = new DataOutputStream(os);
		
		BufferedReader br = new BufferedReader
		(new InputStreamReader(System.in));
		
		System.out.print("\n Enter File Name:\t");
		String fname = br.readLine();
		dos.writeUTF(fname);
		
		
		String s = " ";
		
		while((s = dis.readUTF()).compareTo("stop")!=0) 				
		{
			System.out.println(s);
		}
		csob.close();	
	}
}

/* output
	
	Server Started:    
	Cilent connected:
	
*/