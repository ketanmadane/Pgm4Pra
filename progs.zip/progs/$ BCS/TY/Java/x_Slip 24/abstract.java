﻿abstract class shape
{
	final float PI=3.14f;
	final float I=1.0333f;
	final float A=0.333f;
	abstract float area();
	abstract float vol();
}
class sphere extends shape			//class sphere
{
	int r;
	sphere()				//default constructor
	{
		r=0;
	}
	sphere(int x)				//parameterised constructor
	{
		r=x;
	}
	float area()				//function for calculating area
	{
		return(4*PI*r*r);
	}
	float vol()				//function for calculating volume
	{
		return(I*PI*r*r);
	}
}
class cylinder extends shape 		//class cylinder  
{
	int r,h;
	cylinder()				//default constructor
	{
		r=h=0;
	}
	cylinder(int x,int y)		//parameterised constructor
	{
		r=x;
		h=y;
	}
	float area()				//function for calculating area
	{
		return(2*PI*r*r*h);
	}
	float vol()   			//function for calculating volume
	{
		return(PI*r*r*h);
	}
}

class cube extends shape
{
	int a;
	cube()					//default constructor
	{
		a=0;
	}
	cube(int x)				//parameterised constructor
	{
		a=x;
	}
	float area()				//function for calculating area
	{
		return(6*a*a);
	}
	float vol()				//function for calculating volume
	{
		return(a*a*a);
	}
	
}
class cone extends shape
{
	int r,l,h;
	cone()				//default constructor
	{
		l=h=r=0;
	}
	cone(int x,int y,int z)		//parameterised constructor
	{
		r=x;
		h=y;
		l=z;
	}
	float area()			//function for calculating area
	{
		return(PI*r*h*(l+r));
	}
	float vol()				//function for calculating volume
	{
		return(A*PI*r*r*h);
	}
	
}

class inherit
{
	public static void main(String[]args)
	{
		
		sphere s=new sphere(10);
		System.out.println("\nArea of the sphere is"+s.area());
		System.out.println("\nVolume of the sphere is"+s.vol());
		
		cylinder c=new cylinder(5,7);
		System.out.println("\nArea of the cylinder is"+c.area());
		System.out.println("\nvolume of the cylinder is"+c.vol());
		
		cube b=new cube(8);
		System.out.println("\nArea of the cube is"+b.area());
		System.out.println("\nVolume of the cube is"+b.vol());
		
		cone a=new cone(5,8,9);
		System.out.println("\nArea of the cone is"+a.area());
		System.out.println("\nVolume of the cone is"+a.vol());
		
	}
}
/*******OUTPUT*******/                                                                             

/*	
	Area of the sphere is1256.0
	
	Volume of the sphere is324.4562
	
	Area of the cylinder is1099.0
	
	volume of the cylinder is549.5
	
	Area of the cube is384.0
	
	Volume of the cube is512.0
	
	Area of the cone is1758.4001
	
	Volume of the cone is209.12401
*/