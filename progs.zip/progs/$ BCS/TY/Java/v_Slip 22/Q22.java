/*
	*Write a Java program to create GUI that displays all the font names available on a system in a Combobox. 
	*Also display some text message. Apply the font selected from the combo box to the text message.
* */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import java.awt.geom.*;
class Q22 extends JFrame
{
	MyPanel mp;
	Q22()
	{
		mp=new MyPanel();
		setTitle("Q22");
		setSize(450,450);
		setVisible(true);
		add(mp);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String a[])
	{
		new Q22();
	}
}
class MyPanel extends JPanel implements ItemListener
{
	JComboBox cbx;
	String fname=null;
	MyPanel()
	{
		String fnames[]=GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		cbx=new JComboBox(fnames);
		cbx.setSize(200,50);
		cbx.setLocation(100,50);
		cbx.addItemListener(this);
		add(cbx);
	}	
	public	void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D gob=(Graphics2D)g;
		if(fname!=null)
		{
			Font f=new Font(fname,Font.BOLD,30);
			gob.drawString("Your Selected Font ="+fname, 100,80);
		}
	}
	
	public void itemStateChanged(ItemEvent ie)
	{
		fname=(String)ie.getItem();
		repaint();
	} 
}