//	Q.27

import java.awt.*;
import javax.swing.*;
import java.awt.geom.*;
class Q27 extends JFrame
{
	MyPanel mp;
	Q27()
	{
		mp=new MyPanel();	
		setTitle("Q27");
		setSize(450,450);
		setVisible(true);
		add(mp);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String a[])
	{
		new Q27();
	}
}
class MyPanel extends JPanel
{
	public	void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D gob=(Graphics2D)g;
		
		Line2D l1=new Line2D.Double(200,30,400,30);
		gob.draw(l1);
		
		Line2D l2=new Line2D.Double(400,30,400,200);
		gob.draw(l2);
		
		Line2D l3=new Line2D.Double(400,200,50,200);
		gob.draw(l3);
		
		Line2D l4=new Line2D.Double(50,200,50,130);
		gob.draw(l4);
		
		Line2D l5=new Line2D.Double(50,130,200,30);
		gob.draw(l5);
		
		Rectangle2D r1=new Rectangle2D.Double(200,50,50,50);
		gob.draw(r1);
		
		Rectangle2D r2=new Rectangle2D.Double(280,50,100,50);
		gob.draw(r2);
		
		Ellipse2D e1=new Ellipse2D.Double(100,150,80,80);
		gob.draw(e1);
		
		Ellipse2D e2=new Ellipse2D.Double(120,170,40,40);
		gob.draw(e2);
		
		Ellipse2D e3=new Ellipse2D.Double(300,150,80,80);
		gob.draw(e3);
		
		Ellipse2D e4=new Ellipse2D.Double(320,170,40,40);
		gob.draw(e4);
		
	}
}