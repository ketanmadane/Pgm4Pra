/*
	*
	1.Write a program to accept a string as command line argument and check whether it is a file or directory. If it is a directory, list the contents of the directory, count how many files the directory has and delete all files in that directory having extension .txt. (Ask the user if the files have to be deleted). If it is a file, display all information about the file
	(path, size, attributes etc).
**/

import java.io.*;

public class fileDemo
{
	public static void main(String args[])throws IOException
	{
		int fcnt=0,dcnt=0;
		
		BufferedReader br = new BufferedReader
		(new InputStreamReader(System.in));
		
		File f = new File(args[0]);		
		if(f.exists())
		{
			if(f.isDirectory())
			{
				String name[] = f.list();
				System.out.print("\n------------------------------");
				System.out.print("    Directory  contain");			             System.out.print("\n------------------------------");
				
				for(int i=0;i<name.length;i++)
				{
					
					File t = new File (args[0]+"/"+name[i]);
					System.out.print("\n"+i+")"+name[i]);
					if(t.isDirectory())
					{
						dcnt++;
					}
					else
					{
						fcnt++;
					}
				}
				System.out.print("\n Total No of Directory: "+dcnt);
				System.out.println("\n Total No of file	: "+fcnt);
				
				for(int i=0;i<name.length;i++)
				{
					String s = name[i];
					
					File t = new File(args[0]+"/"+name[i]);
					if(s.endsWith(".txt"))
					{
						System.out.println(name[i]+"File you want to delete. ( y / n)");		   String ch = br.readLine();
						if(ch.equals("y"))
						{
							t.delete();
							System.out.println(s+" is Deleted");
						}
					}
				}//for
			}//if
			else if(f.isFile())
			{
				System.out.println("**********FILE INFO**********");
				System.out.println("FILE NAME: "+f.getName());
				System.out.println("PARENT NAME: "+f.getParent());
				System.out.println("FILE SIZE: "+f.length());
				System.out.println("FILE PATH: "+f.getPath());
			}
		}
	}
}


/* [root@localhost ~]# java fileDemo tybcs
	
	------------------------------    Directory  contain
	------------------------------
	0)A.java
	1)B.java
	2)Folder1
	3)Folder2
	4)C.java
	5)a.txt
	6)t.txt
	Total No of Directory: 2
	Total No of file       : 5
	a.txtFile you want to delete. ( y / n)
	y
	a.txt is Deleted
	t.txtFile you want to delete. ( y / n)
	y
	t.txt is Deleted
	
*/