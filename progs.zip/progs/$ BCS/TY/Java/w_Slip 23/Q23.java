import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;

public class Q23 extends JFrame implements ActionListener
{
	JTextField t1,t2,t3,t4;
	JLabel l1,l2,l3,l4;
	JButton b1,b2,b3;
	JLabel ll;
	
	Q23()
	{
		setLayout(null);
		
		ll = new JLabel("Find & Replace");
		Font f1 = new Font("Times New Roman",Font.BOLD,20);
		ll.setFont(f1);
		ll.setBounds(300,10,200,50);
		
		l1 = new JLabel("Enter Text");
		l2 = new JLabel("Text To Find");
		l3 = new JLabel("Text To Replace");
		l4 = new JLabel("No of Occurence");
		
		
		t1 = new JTextField();
		t2 = new JTextField();
		t3 = new JTextField();
		t4 = new JTextField();
		t4.setEditable(false);	
		
		b1 = new JButton("Find");
		b2 = new JButton("Replace");	
		b3 = new JButton("Clear");
		
		l1.setBounds(150,30,300,300);	// setbounds(x,y,width,height)= setsize() & setlocation()
		t1.setBounds(300,170,300,30);
		
		l2.setBounds(150,150,300,300);
		t2.setBounds(300,290,300,30);		
		
		l3.setBounds(150,270,300,300);
		t3.setBounds(300,410,300,30);		
		
		l4.setBounds(150,390,300,300);
		t4.setBounds(310,530,300,30);		
		
		b1.setBounds(150,600,100,30);
		b2.setBounds(350,600,100,30);
		b3.setBounds(550,600,100,30);
		
		add(l1);	add(t1);
		add(l2);	add(t2);
		add(l3);	add(t3);
		add(l4);	add(t4);
		
		add(b1);   add(b2); add(b3);	
		
		add(ll);
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		setSize(1000,718);
		setTitle("Replace & Find");
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String args[])
	{
		new Q23();
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton b = (JButton)ae.getSource();
		int cnt=0;
		
		String org = t1.getText();
		String search  = t2.getText();
		String rep=t3.getText();
		if(b==b1)	
		{	cnt=0;
			for(int j = 0;j<org.length();j++ )
			{			  
				
				int p = org.indexOf(search,j); 	
				
				if(p!=-1)
				{			
					cnt++;	
					j=p;
				}
				
			}
			t4.setText(Integer.toString(cnt));
		}
		
		if(b==b2)
		{
			String str=org.replaceAll(search,rep);
			JOptionPane.showMessageDialog(null,"See Contents of TextField 1 ");
			t1.setText(str);
		}											
		
		if(b == b3)
		{
			t1.setText("");
			t2.setText("");
			t3.setText("");
			t4.setText("");
		}	
		
	}
}