/*     
	1. 
	Create a class Student with attributes roll no, name, age and CLASS. Initialize values through parameterized constructor. If age of student is not in between 15 and 21 then generate user-defined exception 
	“AgeNotWithinRangeException”. If name contains numbers or special symbols raise exception “NameNotValidException”. Define the two exception classes.
	
*/

import java.io.*;

class AgeNotWithinRangeException extends Exception
{
	AgeNotWithinRangeException(String msg)
	{
		super(msg);
	}
}
class NameNotValidException extends Exception
{
	NameNotValidException(String msg)
	{
		super(msg);
	}
}
class student
{
	int rno,age;
	String name,CLASS;
	
	student(int rno,String name,int age,String CLASS)
	{
		this.rno   =  rno;
		this.name  =  name;
		this.age   =  age;
		this.CLASS = CLASS;
	}
	void display()
	{
		System.out.println(rno+"\t"+name+"\t"+age+"\t"+CLASS);
	}
}
public class StudentDemo
{
	public static void main(String args[])
	{
	    try
	    {
			BufferedReader dis = new BufferedReader(new InputStreamReader(System.in));
			
			System.out.print("\n Enter How Many Object:\t");
	        int n = Integer.parseInt(dis.readLine());
			
			student s[] = new student[n];	
			int rno = 0,age = 0;
			String name = " ",CLASS=" ";
			
			for(int i=0;i<n;i++)
			{
				System.out.println("Accepting Info Of"+(i+1)+"Student");
				System.out.print("\n Enter RollNo:\t");
				rno = Integer.parseInt(dis.readLine());
				try
				{
					System.out.print("\n Enter Name:\t");
					name = dis.readLine();
					
					for(int j=0;j<name.length();j++)
					{
						if(!(Character.isLetter(name.charAt(j))))
						{
							NameNotValidException e = new NameNotValidException(name);
							throw e;
						}
					}
					System.out.print("\n Enter Age:\t");
					age = Integer.parseInt(dis.readLine());
					
					if(age<15||age>21)
					{
						AgeNotWithinRangeException e = new AgeNotWithinRangeException("Given Age Invalid:"+age);
						throw e;
					}
				}
				catch(NameNotValidException e)
				{
					System.out.println("User define Exception"+e.getMessage());
					i--;
					continue;
				}
				catch(AgeNotWithinRangeException e)
				{
					System.out.println("USER DEFIND Exception="+e.getMessage());
					i--;
					continue;
				}
				System.out.print("\n Enter CLASS:\t ");
				CLASS = dis.readLine();
				
				s[i] = new student(rno,name,age,CLASS);
			}//for
			System.out.print("RNO\tNAME\tAGE\tCLASS\n");
			for(int i=0;i<n;i++)
			{
				s[i].display();
			}
			
		}//tryout	
		
		catch(IOException e)
		{
			System.out.println("I|O ERROR"+e.getMessage());
		}
		catch(Exception e)
		{
			System.out.println("UNKNOWN ERROR"+e.getMessage());
		}
	}
	
}


/* output 1 :
	
	
	Enter How Many Object: 2
	
	Accepting Info Of 1 Student
	
	Enter RollNo :  1
	
	Enter Name  : Sachin Dhane
	
	User define Exception
	
	Accepting Info Of 1 Student
	
	Enter RollNo:  2
	
	Enter Name:    Sourabh Deo
	
	Enter Age:     22
	
	USER DEFIND Exception = Given Age Invalid : 22
	
	Accepting Info Of 1 Student
	
	Enter RollNo:  1
	
	Enter Name:   Sachin Dhane
	
	Enter Age:     17
	
	Enter CLASS:   BCS
	
	Accepting Info Of 2 Student
	
	Enter RollNo:  2
	
	Enter Name:    Sourabh Deo
	
	User define Exception!
	
	Accepting Info Of 2 Student
	
	Enter RollNo:  2
	
	Enter Name:   Sourabh Deo
	
	Enter Age:     18
	
	Enter CLASS:   BCA
	
	
	
	RNO     NAME    	AGE     CLASS
	
	1       Sachin Dhane 	17      BCS
	
	2       Sourabh Deo	 18      BCA
	
	----------------------------------------------------------------------------
*/