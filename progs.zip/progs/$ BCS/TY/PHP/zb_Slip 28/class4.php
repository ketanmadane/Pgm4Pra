<?
	class account
	{
		private $acc_no,$cust_name;
		function __construct($acc_no,$cust_name)
		{
			$this->acc_no = $acc_no;
			$this->cust_name = $cust_name;
		}
		function get_acc_no()
		{
			return $this->acc_no;
		}
		function disp()
		{
			echo "<b>Account No:</b>".$this->acc_no."<br>".
			"<b>Customer Name:</b>".$this->cust_name."<br>";
		}
	}
	class saving_acc extends account
	{
		private $balance,$min_amount;
		function __construct($acc_no,$cust_name,$balance,$min_amount)
		{
			parent::__construct($acc_no,$cust_name);
			$this->balance = $balance;
			$this->min_amount = $min_amount;
		}
		function disp()
		{
			parent::disp();
			echo "<br>Balance:</b>".$this->balance."<br>".
			"<br>Min Amount:</b>".$this->min_amount."<br>";
		}
		
		function get_bal()
		{
			return $this->balance;
		}
		
		function get_min_amount()
		{
			return $this->min_amount;
		}
		
		function withdraw($amt)
		{
			$this->balance-=$amt;
		}
		
		function deposit($amt)
		{
			$this->balance+=$amt;
		}
	}
	
	class current_acc extends account
	{
		private $balance,$min_amount;
		
		function __construct($acc_no,$cust_name,$balance,$min_amount)
		{
			parent::__construct($acc_no,$cust_name);
			$this->balance = $balance;
			$this->min_amount = $min_amount;
		}
		
		function disp()
		{
			prarent::disp();
			echo "<br>Balance:</b>".$this->balance."<br>".
			"<br>Min Amount:</b>".$this->min_amount."<br>";
		}
		
		function get_bal()
		{
			return $this->balance;
		}
		
		function get_min_amount()
		{
			return $this->min_amount;
		}
		
		function withdraw($amt)
		{
			$this->balance-=$amt;
		}
		
		function deposit($amt)
		{
			$this->balance+=$amt;
		}
	}
	
	$accno = $_POST['accno'];
	$cname = $_POST['cname'];
	$acc_type = $_POST['acc_type'];
	$trans_type = $_POST['trans_type'];
	$amt = $_POST['amt'];
	$fname = "$acc_type.dat";
	
	switch($trans_type)
	{
		case 'create':
			$fp = fopen($fname,"a");
			if($acc_type === 'saving')
				$e = new saving_acc($accno,$cname,$amt,500);
			else
				$e = new current_acc($accno,$cname,$amt,0);
			$encode = serialize($e);
			fwrite($fp,$encode);
			fwrite($fp,"\n");
			fclose($fp);
			echo "Account created successfully.";
			break;
		case 'withdraw':
			$fp = fopen($fname,"r");
			$fp1 = fopen("temp.dat","w");
			$flag = 0;
			while($encode = fgets($fp,200))
			{
				$e = unserialize($encode);
				if($e->get_acc_no() === $accno)
				{
					$e->disp();
					$flag=1;
					if($e->get_bal()-$amt >= $e->get_min_amount())
					{
						$e->withdraw($amt);
						echo "Amount withdrawn successfully.";
					}
					else
					{
						echo "Insufficient fund.";
					}
				}	
				$encode = serialize($e);
				fwrite($fp1,$encode);
				fwrite($fp1,"\n");
			}
			fclose($fp);
			fclose($fp1);
			if(!$flag)
			echo "Account no $accno not found.";
			unlink($fname);
			rename("temp.dat",$fname);		
			break;
		case 'deposit':
			$fp = fopen($fname,"r");
			$fp1 = fopen("temp.dat","w");
			$flag = 0;
			while($encode = fgets($fp,200))
			{
				$e = unserialize($encode);
				if($e->get_acc_no() === $accno)
				{
					$e->disp();
					$flag=1;
					$e->deposit($amt);
					echo "Amount deposited successfully.";
				}
				$encode = serialize($e);
				fwrite($fp1,$encode);
				fwrite($fp1,"\n");
			}
			fclose($fp);
			fclose($fp1);
			if(!$flag)
				echo "Account no $accno not found.";
			unlink($fname);
			rename("temp.dat",$fname);
			
			break;
	}
?>