<?php
	define('PI',3.14);
	
	interface shape
	{
		function area();
		function volume();
	}
	
	class cylinder implements shape
	{
		private $r;
		private $h;
		
		function __construct($r,$h)
		{
			$this->r = $r;
			$this->h = $h;
		}
		
		function area()
		{
			return 2*PI*$this->r*($this->r+$this->h);
		}
		
		function volume()
		{
			return PI*$this->r*$this->r*$this->h;
		}
	}
	
	class cube implements shape
	{
		private $s;
		
	function __construct($s)
	{
	$this->s = $s;
	}
	
	function area()
	{
	return 6*$this->s*$this->s;
	}
	
	function volume()
	{
	return $this->s*$this->s*$this->s;
	}
	}
	
	$obj = null;
	
	$r = $_POST['radius'];
	$h = $_POST['height'];
	$s = $_POST['side'];	
	$op = $_POST['op'];
	
	switch($op)
	{
	case 'cylinder':
	$obj=new cylinder($r,$h);
	printf("Area of cylinder = %f<br>Volume of cylinder = %f",$obj->area(),$obj->volume());
	break;
	case 'cube':
	$obj=new cube($s);
	printf("Area of cube = %f<br>Volume of cube = %f",$obj->area(),$obj->volume());
	}
	?>
		