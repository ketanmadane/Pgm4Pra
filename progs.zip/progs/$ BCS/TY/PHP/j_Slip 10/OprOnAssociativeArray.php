<?php
	
	$arr=array('rno'=>1,'name'=>'sachin dhane','city'=>'Pune');
	$choice=$_POST['op1'];
	switch($choice)
	{
		case 1:	
			echo "<br>Before Adding element array is ";
			print_r($arr);
			$element=$_POST['e'];
			$arr[]=$element;
			echo "<br><br>After Adding element array is ";
			print_r($arr);
			break;
		
		case 3:	echo "<br>DISPALYING ELEMENTS ALONG WITH KEYS";
			echo "<br><table border=1><tr><td>KEY</td><td>VALUE</td></tr>";
			foreach($arr as $key => $value)
			{
				echo "<tr><td>$key</td><td> $value</td>";
			}
			echo "</table>";
			break;
		/*---------------------------------------------------------------------------------------*/
		case 2:	$index=$_POST['index'];;
			echo "<br>before deleting elements from index $index array is  : ";
			print_r($arr);
			array_splice($arr,$index,1);
			echo "<br>After deleting elements from index $index array is   : ";
			print_r($arr);
			break;
		/*-----------------------------------------------------------------------------------------*/
	}
?>