<?php
	
	setCookie('fstyle',$_POST['options']);
	setCookie('fsize',$_POST['options1']);
	setCookie('fcolor',$_POST['options2']);
	setCookie('fbcolor',$_POST['options3']);
	
	$fs=$_POST['options'];
	$fz=$_POST['options1'];
	$fc=$_POST['options2'];
	$fb=$_POST['options3'];
	
	echo"<form action=p141.php method=POSt>"; 
	echo"Entered References : ";
	echo"<br>";
	echo"Font Style:  ".$fs;
	echo"<br>";
	echo"Font Size:  ".$fz;
	echo"<br>";
	echo"Font color:  ".$fc;
	echo"<br>";
	echo"Background Color :  ".$fb;
	echo"<br>";
	
	echo"<br><input type='submit' value='submit'>";
?>


