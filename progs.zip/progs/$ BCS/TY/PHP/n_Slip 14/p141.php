<?php
	
	echo"<font style=$_COOKIE[fstyle]>";
	echo"<br>";
	echo"<font size=$_COOKIE[fsize]>";
	echo"<br>";
	
	echo"<font color=$_COOKIE[fcolor]>";
	echo"<br>";
	
	echo"<body bgcolor=$_COOKIE[fbcolor]>";
	
	echo"Entered References:";
	echo"<br>";
	echo"Font Style:  ".$_COOKIE['fstyle'];
	echo"<br>";
	echo"Font Size:  ".$_COOKIE['fsize'];
	echo"<br>";
	echo"Font color:  ".$_COOKIE['fcolor'];
	echo"<br>";
	echo"Background Color :  ".$_COOKIE['fbcolor'];
	echo"<br>";
	
?>

