<html>
	<head>
		<script type="text/javascript">
			function displayContents()
			{
				var xmlHttp;
				if(window.XMLHttpRequest)
				xmlHttp = new XMLHttpRequest();
				else
				xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
				xmlHttp.onreadystatechange = function()
				{
					if(xmlHttp.readyState == 4 && xmlHttp.status==200)
					{
						document.getElementById("myDiv").innerHTML = xmlHttp.responseText;
					}
				}
				xmlHttp.open("POST","ajax_read.php",true);
				xmlHttp.send();
			}
		</script>
	</head>
	<body>
		<h2>After clicking the print button, contents will be displayed from contact.dat file</h2>
		<div id="myDiv"></div>
		<input type="button" onclick="displayContents()" value="Print"/>
		
	</body>
</html>

