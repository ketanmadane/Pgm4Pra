<?php
	function printtable($sql, $head)
	{
		$q = mysql_query($sql);
		echo '<table border=1>';
		echo "<tr bgcolor='red'>";
		foreach($head as $val)
		{
			echo "<td>$val</td>";
		}
		echo "</tr>";
		while($row = mysql_fetch_array($q,MYSQL_NUM))
		{
			echo '<tr>';
			foreach($row as $val)
			{
				echo "<td>$val</td>";
			}
		}
		echo "</table>";
		mysql_free_result($q);
	}
	
	mysql_connect("localhost","root","") or die('Could not connect: ' . mysql_error());
	mysql_select_db("tybcs1");
	
	$op=$_POST['op'];
	
	switch($op)
	{
		case 'Print Movies':
		$an =  $_POST['actor'];
		$sql = "select MOVIE.movie_no,movie_name,release_year
		from MOVIE,ACTOR,MA
		where MOVIE.movie_no = MA.movie_no and ACTOR.actor_no = MA.actor_no and actor_name = '$an'";     
	$head = array('movie no','name','release year');
	printtable($sql,$head);
	break;
	case 'Update Movies':
	$mn = $_POST['movie'];
	$yr = $_POST['yr'];
	$sql = "update MOVIE set release_year=$yr WHERE movie_name='$mn'";
	mysql_query($sql);
	echo "Movie updated successfully.";
	}		
	mysql_close();
	?>
	
		