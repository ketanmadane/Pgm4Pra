<?php
	if(isset($_POST['submit']))
	{
		$email = $_POST['email'];
		// $pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$"; 
		$pattern = "^[_a-z]+(\.[_a-z0-9-]+)*@[a-z]+(\.[a-z]+)*(\.[a-z]{2,3})$"; 
		
		if (eregi($pattern, $email))
		echo "This email is valid.";
		else
		echo "This email is Invalid";
	}
?>