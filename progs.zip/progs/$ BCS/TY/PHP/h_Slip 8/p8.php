<?php
	
	$dir=$_POST['d'];
	$ext=$_POST['e'];
	
	if(is_dir($dir)!=false)
	{
		echo "Directory: $dir is exist...";	
		echo "<br>  following file are specified extension : $ext";
		$handle=opendir($dir);
		while (($contents=readdir($handle))!==false)
		{
			if(ereg($ext,$contents))
			{
				echo "<br>$content";
			}
			
		}
		fclose($handle);
	}
	else
	echo "<h1> Sorry,It is NOT Valid directory..</h1>";
	
?>

