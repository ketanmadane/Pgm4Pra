<?php
	$w = 400;
	$h = 400;
	$img = imagecreatetruecolor($w,$h);
	$color = imagecolorallocate($img,255,255,255);
	imageellipse($img,$w/2,$h/2,100,100,$color);
	imagerectangle($img,$w/2-50,$h/2-50,$w/2+50,$h/2+50,$color);
	imageellipse($img,$w/2,$h/2,150,150,$color);
	imagerectangle($img,$w/2-75,$h/2-75,$w/2+75,$h/2+75,$color);
	imageellipse($img,$w/2,$h/2,220,220,$color);
	header('Content-Type: image/png');
	imagepng($img);
	imagedestroy($img);
?>
