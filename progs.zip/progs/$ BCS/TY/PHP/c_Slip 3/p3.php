<?php
	
	$dir=$_POST['d'];
	$letter=$_POST['letter'];
	
	if(is_dir($dir)!=false)
	{
		echo "Directory<font color='red'> <blink>\" $dir \"</blink> </font> is exist...";	
		echo "<br>  following file are begining with given \" $letter \"letters :  ";
		$handle=opendir($dir);
		while (($contents=readdir($handle))!==false)
		{
			if(ereg($letter,$contents))
			{
				echo "$contents<br>";
			}
		}
		fclose($handle);
	}
	else
	echo "It is NOT Valid directory...<br>";
	
?>

