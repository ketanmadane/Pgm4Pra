<?php
	$names=array('SachinDhane'=>45,'Sourabh'=>40,'Nana'=>50,'Shashi'=>48,'Avinash'=>56);

	$key=$_POST['key'];
	$val=$_POST['value'];
	$op=$_POST['op'];

	switch($op)
	{
	case 'add':
		echo 'Before:<br>';
		print_r($names);
		$names[$key]=$val;
		echo '<br>After:<br>';
		print_r($names);
		break;
	case 'remove':
		echo 'Before:<br>';
		print_r($names);
		unset($names[$key]);
		echo '<br>After:<br>';
		print_r($names);
		break;
	case 'disp';
		echo "<table border=1><tr><th>Name</th><th>Age</th></tr>";
		foreach($names as $k=>$v)
			echo "<tr><td>$k</td><td>$v</td></tr>";
		echo "</table>";
	}
?>


