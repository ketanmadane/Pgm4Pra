<?php      
	
	require "b1_fun.php";	 
	
	$num1 = $_POST['num1'];
	$num2 = $_POST['num2'];
	
	$oper = $_POST['oper'];
	
	operation($oper,$num1,$num2);
?>
