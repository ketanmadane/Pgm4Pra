<?php
	
	function operation($oper,$num1=0,$num2=0)
	{
        echo "<u>RESULT:<br></u><br>";
        switch($oper)
        {
			case '+':$n =$num1+$num2;
			echo $num1." + ".$num2." = ".$n;
			break;
			
			case '-':$n = $num1 - $num2;
			echo  $num1." - ".$num2." = ".$n;
			break;
			
			case '*':echo  $num1." * ".$num2." = ".$num1*$num2;
			break;
			
			case '/':echo  $num1." / ".$num2." = ".$num1/$num2;
			break;
			
			case '%':echo  $num1." % ".$num2." = ".$num1%$num2;
			break;
		}
	}
?>
