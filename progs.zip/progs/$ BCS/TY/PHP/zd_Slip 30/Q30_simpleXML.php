<?php
	if(file_exists('Movie.xml'))
	{
		$xml=simplexml_load_file('Movie.xml');
		
		echo "<TABLE border=1>";
		echo "<TR><TD>Movie Name</TD><TD>Actor Name</TD><TD>Release Year</TD><TD>Producer</TD></TR>";
		foreach($xml->Movie as $m)
		{	echo "<TR>";
			echo "<TD>".$m->MovieName."</TD>";
			echo "<TD>".$m->ActorName."</TD>";
			echo "<TD>".$m->ReleaseYear."</TD>";
			echo "<TD>".$m->Producer."</TD>";
			echo "</TR>";
		}
		echo "</TABLE>";
	}
	else
	echo "<h1>FILE IS NOT EXISTS</h1>";
?>

