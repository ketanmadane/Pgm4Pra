<?
	class Player
	{
		private $code,$name,$runs,$inngs,$no,$avg;
		
		function __construct($code,$name,$runs,$inngs,$no)
		{
			$this->code = $code;
			$this->name = $name;
			$this->runs = $runs;
			$this->inngs = $inngs;
			$this->no = $no;
			$this->avg = $this->runs/($this->inngs-$this->no);
		}
		
		function put_player()
		{
			printf("<tr><td>%d</td><td>%s</td><td>%d</td><td>%d</td><td>%d</td><td>%f</td></tr>",
			$this->code,$this->name,$this->runs,$this->inngs,$this->no,$this->avg);
		}
		
		function get_code()
		{
			return $this->code;
		}
		
		function get_runs()
		{
			return $this->runs;
		}
		
		function get_avg()
		{
			return $this->avg;
		}
		
		function get_name()
		{
			return $this->name;
		}
	}
	
	$code = $_POST['code'];
	$name = $_POST['name'];
	$runs = $_POST['runs'];
	$inngs = $_POST['inngs'];
	$no = $_POST['no'];
	$op = $_POST['op'];
	
	switch($op)
	{
		case 1: 
			$fp = fopen("player.dat","a");
			$p = new Player($code,$name,$runs,$inngs,$no);
			$encode = serialize($p);
			fwrite($fp,$encode);
			fwrite($fp,"\n");
			fclose($fp);
			echo "Record saved successfully.";
			break;
		case 2:
			$fp = fopen("player.dat","r");
			while($encode = fgets($fp,200))
			{
				$p = unserialize($encode);
				if($p->get_code()===$code)
				{
					printf("Average runs = %f",$p->get_avg());
					break;
				}
			}
			if(feof($fp))
				printf("Player code %d not found.",$code);
			fclose($fp);
			break;
		case 3:
			echo "<table border=1>";
			echo "<tr><th>Code</th><th>Name</th><th>Avg</th></tr>";
			$fp = fopen("player.dat","r");
			while($encode = fgets($fp,200))
			{
				$p = unserialize($encode);
				printf("<tr><td>%d</td><td>%s</td><td>%f</td></tr>",
				$p->get_code(),$p->get_name(),$p->get_avg());
			}
			fclose($fp);
			echo "</table>";
			break;
		case 4:
			$fp = fopen("player.dat","r");
			$records = array();
			while($encode = fgets($fp,200))
			{
				$p = unserialize($encode);
				$records[] = $p;
			}
			fclose($fp);
		
			$n = count($records);
			for($i=0;$i<$n-1;$i++)
			{
				for($j=0;$j<$n-$i-1;$j++)
				{
					if($records[$j]->get_runs() < $records[$j+1]->get_runs())
					{
						$t = $records[$j];
						$records[$j] = $records[$j+1];
						$records[$j+1] = $t;
					}
				}
			}
		
			echo "<table border=1>";
			echo "<tr><th>Code</th><th>Name</th><th>Total Runs</th><th>Innings Played</th><th>Times Not Out</th><th>Avg</th></tr>";
			for($i=0; $i<$n; $i++)
				$records[$i]->put_player();
			echo "</table>";
			break;
	}
?>
