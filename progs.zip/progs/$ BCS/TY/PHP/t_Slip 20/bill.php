<?php
	$bno=$_POST['bno'];
	mysql_connect("localhost","root","") or die("UNABLE TO CONNECT TO SERVER : ".mysql_error());
	mysql_select_db("tybcs")or die("UNABLE TO FIND DATABASE".mysql_error());
	
	$result=mysql_query("select * from billmaster where billno=$bno") or die(mysql_error()) ;
	
	$rec=mysql_fetch_array($result);
	
	echo "Bill No:$bno &nbsp &nbsp &nbsp &nbsp";
	echo "Bill Date:".$rec['billdate'];
	echo "<br>Customer Name:".$rec['custname'];
	
	$result=mysql_query("select * from billdetails where billno=$bno")or die(mysql_error()) ;
	
	$srno=1;
	$gamt=0;
	$totaldiscount=0;
	$netbill=0;
	echo "<TABLE border=1>";
	echo "<TR><TD>Sr.No.</TD><TD>Particular</TD><TD>Quantity</TD><TD>Rate</TD><TD>Total</TD></TR>";
	while($rec=mysql_fetch_array($result))
	{
		echo "<TR>";
		echo "<TD>".$cnt."</TD>";
		echo "<TD>".$rec['itemname']."</TD>";
		echo "<TD>".$rec['qty']."</TD>";
		echo "<TD>".$rec['rate']."</TD>";
		echo "<TD>".$rec['qty']*$rec['rate']."</TD>";
		echo "</TR>";
		
		$gamt=$gamt+$rec['qty']*$rec['rate'];
		$totaldiscount=$totaldiscount+$rec['total_discount'];
		$cnt++;
		
	}
	
	echo "</table>";
	echo "Gross Amount=$gamt<br>";
	echo "Total DisCount=$totaldiscount<br>";
	echo "Net Bill=".($gamt-$totaldiscount);
	?>
		