<?php
	header('Content-Type: image/jpeg');
	$img = imagecreate(400,200);
	$red = imagecolorallocate($img,255,0,0);
	
	$black = imagecolorallocate($img,0,0,0);
	
	imagestring($img,10,100,20,"MY COMPUTER",$black);
	
	imagerectangle($img,100,50,200,100,$black);
	
	imagerectangle($img,50,120,250,150,$black);
	
	imagerectangle($img,270,50,330,150,$black);
	
	imagejpeg($img,'comp.jpeg');
	imagedestroy($img);
	
?>