<?php
	
	$img = imagecreatefromjpeg("ty.jpg");
	
	$water_mark= imagecreatefromjpeg("comp.jpg");
	
	$dest_width=imagesx($img);
	$dest_height=imagesy($img);
	
	$src_width=imagesx($water_mark);
	$src_height=imagesy($water_mark);
	
	imagecopy($img,$water_mark,320,550,0,0,$src_width,$src_height);
	
	header('Content-Type:image/jpeg');
	imagejpeg($img);
	
?>

