<?php
	include("p5.inc");
	$num1=$_GET['num1'];
	$num2=$_GET['num2'];
	
	gcd_lcm($num1,$num2);
?>
