<?php
	
	$large = $_POST['large'];
	$small = $_POST['small'];
	$repl =  $_POST['repl'];
	
	echo "Larger String is 		:".$large;	
	echo "<br>Smaller String is	:".$small;	
	echo "<br>String For Replace	:".$repl;	
	
	$pos1 = strpos($large,$small);
	echo "<br> smaller String appears at starting $pos1 position in larger string ";
	
	$pos = strrpos($large,$small);
	echo "<br> smaller String appears at End $pos";
	//echo $pos2;
	
	$ls= str_replace($small,$repl,$large);
	echo "After Replacing small string The String will be $ls";
	
?>








