<?php
	
	$tno = $_REQUEST['tno'];
	if($tno == '')
	die("<b>Please enter Teacher No.!!!</b>");
	
	mysql_connect('localhost','root','')or die('Unable to Connect');
	
	mysql_select_db('tybcs')or die('Unable to Select Database');
	
	$sql= "Select * from teacher where tno = '$tno'";
	
	$resultSet = mysql_query($sql);
	
	$noOfRows  = mysql_num_rows($resultSet);
	
	if($noOfRows)
	{
		echo '<b>Teacher Information is :</b>';
		$row = mysql_fetch_row($resultSet);
		echo "<br>Teacher Number : $row[0]<br> Teacher Name : $row[1]<br>Subject : $row[2]<br>Research Area : $row[3]";
	}
	else
	{
		echo "<b>Sorry: There is no teacher information for teacher no. $tno!!!</b>";
	} 
?>
