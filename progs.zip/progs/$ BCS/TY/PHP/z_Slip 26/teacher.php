<html>
	<head>
	</head>
	<body>
		<h2>Please add Teacher Number in the textbox and press display button to get teacher information</h2>
		<input type="text" name="tno" id="tno" value=""/>
		<input type="button" onclick="displayTeacherInfo()" value="Print"/>
		
		<h1 id="show"></h1>
		
		<script type="text/javascript">
			function displayTeacherInfo()
			{
				
				var x= new XMLHttpRequest();
				var tno = document.getElementById("tno").value;
				x.open("POST","get_data.php?tno="+tno,true);
				x.send();
				
				x.onreadystatechange = function()
				{
					if(x.readyState == 4 && x.status==200)
					{
						document.getElementById("show").innerHTML = x.responseText;
					}
				}
			}
		</script>
		
	</body>
</html>

