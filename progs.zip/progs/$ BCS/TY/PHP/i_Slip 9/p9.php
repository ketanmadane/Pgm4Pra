<?php
	include("p9.inc");
	$s=$_GET['s'];
	$s1=strlen($s);
	$ch=$_GET['str'];
	$a=0;
	switch($ch)
	{
		case 'cnt':
		echo"Accepted String is $s";
		for($i=0;$i<$s1;$i++)
		{
			$k=$s[$i];
		    $m=vowels($k);
			
			if($m>0)
			{
				$a=$a+1;
			}
		}
		if($a!=0)
		{
			echo" <br>No of vowels Found in $s is  $a";
		}
		else
		echo"<br>Sorry........!<br>not Vowels found";
		break;
		
		case 'vol':
		
		for($i=0;$i<$s1;$i++)
		{
			$k=$s[$i];
			no_vowels($s,$k);
		}
		break;
		case 'pal':
		
		echo"Given String is $s<br>";
		for($j=$s1;$j>=0;$j--)
		{
			$str=$s[$j];
		}
		for($i=0;$i<$s1;$i++)
		{
			$str1=$s[$i];
		}
		
		if($str!=$str1)
		{
			echo"<br>Sorry...!<br>String is Not palinedrome <br>";
		}
		else
		{
			echo"<br>String is Palinedrome<br>";
		}
	}
?>