<?php
	$fname = "student.dat";
	$fp = fopen($fname,"r");
	
	echo"<table border=1>";
	
	echo "<tr> <th>RollNo</th> <th>Name</th> <th>M1</th> <th>M2</th> <th>M3</th> <th>Total</th> <th>per</th><tr>";
	
	while(($ch=fgets($fp))!=false)
	{
		$a = explode(" ",$ch);
		
		$Total = $a[2]+ $a[3] + $a[4];
		$per =  $Total / 3; 
		
		echo "<tr><td>";
		echo $a[0];
		echo "</td><td>";
		
		//echo"<tr>";
		echo $a[1];
		echo "</td><td>";
		
		echo $a[2];
		echo "</td><td>";
		
		echo $a[3];
		echo "</td><td>";
		
		echo $a[4];
		echo "</td><td>";
		
		echo $Total;
		echo "</td><td>";
		
		echo $per;
		echo "</td>";
		
		echo"</tr>";
	}
	echo"</table>";
	fclose($fp);
?>








