<?php
	
	session_start();
	$t = $_SESSION['t'];
	$new_time = $t + 60;
	if($new_time < time())
	{
		echo " Sorry you are late.<br><You had only 60 seconds to enter the info... be quick next time ";
	}
	else
	{
		echo "Name:$_GET[name]<br>";
		echo "City:$_GET[city]<br>";
		echo "Phone No:$_GET[pno]<br>";
	}
	session_destroy();
?>


