<html>
	<script>
		alert("You have only 60 seconds to enter the info... be quick.")
	</script>
</html>


<?php
	$user = $_POST['user'];
	$pass = $_POST['pass'];
	if($user != $pass)
	{
		die("<h1>Login failed. . .<br><br>Username & Password must be same.</h1>
		<h2><br><br><b><a href=\"expire_session_1.html\">Go Back</a></b><h2>");
	}
	session_start();
	$_SESSION['t']=time();
?>

<html>
	<form method='GET' action='display_info_3.php'>
		<pre>
			Name         :<input type='text' name='name'><br>
			City         :<input type='text' name='city'><br>
			Phone No     :<input type='text' name='pno'><br>
			<input type='submit'><input type='reset'>
		</pre>
	</form>
</html>
