<?php
	$dom=new DomDocument();
	$dom->load("Book.xml");
	echo "File IS Loaded<br>";
	
	echo "<br>Book Name<br>";
	$bname=$dom->getElementsByTagName("BookName");
	foreach($bname as $data)
	{
		print $data->textContent."<br>";
	}
	
	echo "<br>Author Names<br>";
	$btitle=$dom->getElementsByTagName("AuthorName");
	foreach($btitle as $data)
	{
		print $data->textContent."<br>";
	}
	
	echo "<br>Book Price<br>";
	$bprice=$dom->getElementsByTagName("Price");
	foreach($bprice as $data)
	{
		print $data->textContent."<br>";
	}
	
	echo "<br>Book Publication Year<br>";
	$byear=$dom->getElementsByTagName("Year");
	foreach($byear as $data)
	{
		print $data->textContent."<br>";
	}	
	
?>
