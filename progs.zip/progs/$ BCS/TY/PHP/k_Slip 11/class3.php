<?
	$side = $_POST['side'];
	$radius = $_POST['radius'];
	$length = $_POST['length'];
	$breadth = $_POST['breadth'];
	
	interface AreaMethod
	{
		function area();
	}
	
	class Rectangle implements AreaMethod
	{
		protected $length,$breadth;
		
		function __construct($l,$b)
		{
			$this->length = $l;
			$this->breadth = $b;
		}
		
		function area()
		{
			return $this->length*$this->breadth;
		}
	}
	
	class Circle implements AreaMethod
	{
		private $radius;
		
		function __construct($r)
		{
			$this->radius = $r;
		}
		
		function area()
		{
			return M_PI*$this->radius*$this->radius;
		}
	}
	
	class Square extends Rectangle implements AreaMethod
	{
		function __construct($s)
		{
			$this->length = $this->breadth = $s;		
		}
		
		function area()
		{
			return parent::area();
		}
	}
	
	$sq_obj = new Square($side);
	
	$rect_obj = new Rectangle($length,$breadth);
	
	$cir_obj = new Circle($radius);
	
	printf("Area of square = %f<br>",$sq_obj->area());
	printf("Area of rectangle = %f<br>",$rect_obj->area());
	printf("Area of circle = %f<br>",$cir_obj->area());
?>