<?php
	
	$r1=$_POST["r3"];
	$r2=$_POST["h3"];
	
	interface shape
	{
		function area();
		function volume();
	}
	
	class cylinder implements shape
	{
		
		public function  area()
		{
			global $r1,$r2;
			define('PI',"3.14");
			$area=(2*PI*$r1*($r1+$r2));
	        echo "area of cylinder=".$area."<br>";
		}
		
		public function volume()
		{
			global $r1,$r2;
			define('PI',"3.14");
			$v=(2*PI*$r1*$r2);
			echo "volume of cylinder=".$v."<br>";
		}
	}
	
	class sphere implements shape
	{
		public function  area()
		{
			global $r1,$r2;
			define('PI',"3.14");
			$area=(4*PI*$r1*$r1);        
			echo "area of sphere=".$area."<br>";
		}
		
		public function volume()
		{
			global $r1,$r2;
			define('PI',"3.14");
			$v=(4/3*PI*$r1*$r1*$r1); 
			echo "volume of sphere=".$v."<br>";
		}
	}         
	
	$s=new cylinder();
	$s->area();
	$s->volume();
	
	$sa=new sphere();
	$sa->area();
	$sa->volume();
?>