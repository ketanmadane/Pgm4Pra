<?php
	$fp=fopen('transaction.date','r');
	
	$date = $_POST['date'];
	
	$dr_total=0;
	$cr_total=0;
	
	echo "<table border=1>".
	"<tr><th>Tr.No</th><th>Acc No</th><th>Amt</th><th>Type</th><th>Date</th></tr>";
	
	while($row=fscanf($fp,"%d %d %d %s %s"))
	{
		if($row[4]==$date)
		{
			if($row[3]=='DR') $dr_total+=$row[2];
			if($row[3]=='CR') $cr_total+=$row[2];
			
			echo "<tr>";
			foreach($row as $v)
			echo "<td>$v</td>";
			echo "</tr>";
		}
	}
	echo "</table><br>";
	echo "Debit Total:Rs.$dr_total/-<br>Credit Total:Rs.$cr_total/-";
	fclose($fp);
?>

