<?php
	$hit_cnt=$_COOKIE['accesses'];
	if(isset($hit_cnt))
	echo "<br>page is viewed $hit_cnt times";
	if($hit_cnt==10)
	{
		$val=setcookie('accesses',++$hit_cnt,time()-1);// destroying cookie
		//echo "return val:$val";
	}
	else
	setcookie('accesses',++$hit_cnt);
?>