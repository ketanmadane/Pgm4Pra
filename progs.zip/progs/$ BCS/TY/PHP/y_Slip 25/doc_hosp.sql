
DROP TABLE DOC_HOSP;
DROP TABLE HOSPITAL;
DROP TABLE DOCTOR;


CREATE TABLE DOCTOR(doc_no integer primary key, doc_name varchar(30), address varchar(30), city varchar(30), area varchar(30));
CREATE TABLE HOSPITAL(hosp_no integer primary key, hosp_name varchar(30), hosp_city varchar(30));
CREATE TABLE DOC_HOSP(doc_no integer, hosp_no integer, primary key(doc_no,hosp_no));
                                                                                                 
INSERT INTO DOCTOR VALUES(1,'Joshi','Pimpri','Pune','Rural');
INSERT INTO DOCTOR VALUES(2,'Deodhar','Mulund','Mumbai','Urban');
INSERT INTO DOCTOR VALUES(3,'Kale','Dadar','Mumbai','Urban');
INSERT INTO DOCTOR VALUES(4,'Patil','Chinchwad','Pune','Rural');
INSERT INTO DOCTOR VALUES(5,'Pethe','Chinchwad','Pune','Rural');
                                                                                                 
INSERT INTO HOSPITAL VALUES(1,'INLAK','Pune');
INSERT INTO HOSPITAL VALUES(2,'Nair','Mumbai');
INSERT INTO HOSPITAL VALUES(3,'Mehta','Mumbai');
INSERT INTO HOSPITAL VALUES(4,'Poona','Pune');
INSERT INTO HOSPITAL VALUES(5,'Ruby','Pune');
                                                                                                 
INSERT INTO DOC_HOSP VALUES(1,1);
INSERT INTO DOC_HOSP VALUES(1,2);
INSERT INTO DOC_HOSP VALUES(1,5);
INSERT INTO DOC_HOSP VALUES(3,1);
INSERT INTO DOC_HOSP VALUES(3,4);
INSERT INTO DOC_HOSP VALUES(5,1);
INSERT INTO DOC_HOSP VALUES(5,2);
INSERT INTO DOC_HOSP VALUES(4,1);
INSERT INTO DOC_HOSP VALUES(4,2);

