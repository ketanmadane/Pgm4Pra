<?php
	mysql_connect("localhost","root","") or die('Could not connect: ' . mysql_error());
	mysql_select_db("tybcs1");
	
	$hn = $_POST['hosp'];
	$sql = "SELECT DOCTOR.DOC_NO,DOC_NAME,ADDRESS,CITY,AREA
				FROM DOCTOR,HOSPITAL,DOC_HOSP
				WHERE DOCTOR.DOC_NO = DOC_HOSP.DOC_NO AND
				HOSPITAL.HOSP_NO = DOC_HOSP.HOSP_NO and HOSP_NAME = '$hn'";      
	
	$result = mysql_query($sql) or die('Query failed:'.mysql_error());
	$head = array('Doctor No','Name','Address','City','Area');
	echo '<table border=1>';
	echo "<tr bgcolor='red'>";
	foreach($head as $val)
	{
		echo "<th>$val</th>";
	}
	echo "</tr>";
	while($row = mysql_fetch_array($result,MYSQL_NUM))
	{
		echo '<tr>';
		foreach($row as $val)
		{
			echo "<td>$val</td>";
		}
	}
	echo "</table>";
	mysql_free_result($result);
	mysql_close();
?>

