#include<iostream>
#include<string>

using namespace std;


class Bank
{
	int ano;
	string type;
	float amount;
	string ownerName;
	
	public :
	void set(int a,string t,float amt,string oname)
	{
		ano=a;
		type=t;
		amount=amt;
		ownerName=oname;
	}
	void display()
	{

		cout<<ano<<"\t"<<type<<"\t"<<amount<<"\t"<<ownerName<<endl;
	}

};

int main()
{
	Bank ob[5];
	int tano=820001;;
	string t,oname;
	float amt;
	
	for(int i=0;i<5;i++)
	{
		cout<<"ENter account type :";
		cin>>t;
		cout<<"Enter amount:";
		cin>>amt;
		cout<<"Enter Owner Name:";
		cin>>oname;		
		ob[i].set(tano,t,amt,oname);
		tano++;
	}

	 cout<<"ANO\tTYPE\tAMOUNT\tOWNER\n";
		
	for(int i=0;i<5;i++)
	{
		ob[i].display();
	}
}
