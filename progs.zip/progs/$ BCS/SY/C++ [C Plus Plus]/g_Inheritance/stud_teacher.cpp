#include<iostream>

using namespace std;

class Person
{
	char fname[10],lastname[10];

	public :
	void accept()
	{
		cout<<"Enter First Name:";
		cin>>fname;
		cout<<"Enter Last Name: ";
		cin>>lastname;
	}
	void display()
	{
		cout<<fname<<"\t"<<lastname<<"\t";
	}
};

class Student: virtual public Person
{
	char course[10];
	public:
	void accept()
	{
	//	Person::accept();
		cout<<"Eneter course :";
		cin>>course;
	}
	void display()
	{
	//	Person::display();
		cout<<course<<"\t";
	}

};

class Teacher : virtual public Person
{
	char dept[10];
	public:
	void accept()
	{
		//Person::accept();
		cout<<"Enter dept : ";
		cin>>dept;

	}
	void display()
	{
	//	Person::display();
		cout<<dept<<"\t";
	}

};

class Teaching_Assistant : public Student,public Teacher
{
	public :
	void accept()
	{
		Person::accept();
		Student::accept();
		Teacher::accept();	
	}
	void display()
	{
		Person::display();
		Student::display();
		Teacher::display();
		cout<<endl;
	}

};

int main()
{
	int n;
	cout<<"How many Objects :";
	cin>>n;

	Teaching_Assistant ob[n];

	for(int i=0;i<n;i++)
	{
		ob[i].accept();
	}
	cout<<"FNAME\tLNAME\tCOURSE\tDEPT\n";
	for(int i=0;i<n;i++)
	{
		ob[i].display();
	}

}
