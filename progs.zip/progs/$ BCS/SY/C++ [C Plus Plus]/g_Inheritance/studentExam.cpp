#include<iostream>
#include<string.h>
using namespace std;

class Student
{
	int id;
	char name[10];
	
	public:
/*	Student(int i=0,char *p='\0')
	{
		id=i;
		strcpy(name,p);
	}
*/
	void accept()
	{
		cout<<"Enter Id:";
		cin>>id;
		cout<<"Enter name:";
		cin>>name;
	}
	void display()
	{
		cout<<id<<"\t"<<name<<"\t";
	}

};
class StudentExam:public Student
{
	int nos;
	int *sub;
	
	public:
/*	StudentExam(int i=0,char *p='\0',int n=0)
	{
		Student(i,p);
		nos=n;
		sub=new int[nos];
	}
*/
	void accept()
	{
		Student::accept();
		cout<<"How many subjects :";
		cin>>nos;
		sub=new int[nos];
		
		for(int i=0;i<nos;i++)
		{
			cout<<"Eneter marks :";	
			cin>>sub[i];
		}
	
	}
	void display()
	{
		Student::display();
		
		for(int i=0;i<nos;i++)
		{
			cout<<sub[i]<<"\t";
		}
		
	}
	float getPer()
	{
		int sum=0;
		for(int i=0;i<nos;i++)
			sum=sum+sub[i];
		
		return (float)sum/nos;
	}
	
	
};

class StudentResult : public StudentExam
{
	float per;
	char grade;
	
	public :
/*	StudentResult(int i=0,char *p='\0',int n=0,float pr=0.0,char g='\0')
	{
		StudentExam(i,p,n);
		per=pr;
		grade=g;

	}
	*/
	void accept()
	{
		StudentExam::accept();
		per=StudentExam::getPer();
		if(per>=70)
			grade='A';
		else if(per>=60)
			grade='B';
		else if(per>=50)
			grade='C';
		else if(per>=40)
			grade='D';
		else 
			grade='F';
		
	}
	void display()
	{
		StudentExam::display();
		cout<<per<<"\t"<<grade<<endl;
	}

};

int main()
{
	int n;
	cout<<"How many Objects :";
	cin>>n;
	
	StudentResult ob[n];	//=new StudentResult[n];

	for(int i=0;i<n;i++)
	{
		ob[i].accept();
		
	}

	for(int i=0;i<n;i++)
	{
		ob[i].display();
	}
}
