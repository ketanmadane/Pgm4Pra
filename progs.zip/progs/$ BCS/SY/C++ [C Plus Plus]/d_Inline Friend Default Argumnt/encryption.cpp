#include<iostream>
#include<string.h>
using namespace std;

class Key;

class Message
{
	char *msg;
	int lenMsg;
	
	public:
	Message(char *m=NULL)
	{
		lenMsg=strlen(m);
		msg=new char[lenMsg];
		strcpy(msg,m);
	}
	void display()
	{
		cout<<"Message:"<<msg<<endl;
	}
	
	friend void encrypt_decrypt(Message &,Key &);
};

class Key
{
	char k[30];
	int lenKey;
	
	public:
	Key(char *ky)
	{
		strcpy(k,ky);
		lenKey=strlen(k);
	}

	bool check()
	{
		bool Cflag=false,Dflag=false;
		if(lenKey>30 ||lenKey<8)
			return false;
		
		for(int i=0;k[i]!='\0';i++)
		{
			if(k[i]>='A' && k[i]<='Z')
			{
				Cflag=true;
				break;
			}
		}
		for(int i=0;k[i]!='\0';i++)
                {
                        if(k[i]>='0' && k[i]<='9')
                        {       
                                Dflag=true;
                                break;
                        }
                }
		
		if(Cflag==true && Dflag==true)
			return true;
		else
			return false;
			
	}

	void display()
	{
		cout<<"Key:"<<k<<endl;
	}

	friend void encrypt_decrypt(Message &,Key &);
};

void encrypt_decrypt(Message &mob,Key &kob)
{
	int j=0;
	cout<<"Encripted Message :";
	for(int i=0;i<mob.msg[i]!='\0';i++)
	{
		char ch=mob.msg[i]^kob.k[j];
		cout<<ch;
		j=(j+1)%kob.lenKey;
	}
	cout<<endl;
}

int main()
{
	char str[80],key[80];
	cout<<"Eneter messge :";
	cin.getline(str,80);
	
	Message mob(str);

	while(true)	
	{
		cout<<"Enter Key:";
		cin.getline(key,80);
		
		Key kob(key);
		if(kob.check())
		{
			mob.display();
			kob.display();
			encrypt_decrypt(mob,kob);
			break;
		}
		cout<<"You have entered wrong key !!! It must be minimum Length 8 & have atleast one Captial & digit lettter...\n";		
	}
	
}

