#include<iostream>

using namespace std;

class Emp
{
	char name[20];
	public:

	friend class TakingInterface;
};
class TakingInterface
{
	private:
	
	void greet()
	{
		Emp ob;
		cout<<"Enter Name:";
		cin>>ob.name;
		
		cout<<"Hi,"<<ob.name<<endl;
	}

	void greet(char msg[])
        {
                Emp ob;
                cout<<"Enter Name:";
                cin>>ob.name;

                cout<<msg<<"\t"<<ob.name<<endl;
        }     	
	void greet(char msg[],int cnt)
        {
                Emp ob;
                cout<<"Enter Name:";
                cin>>ob.name;
		
		for(int i=1;i<=cnt;i++)
		{
                	cout<<msg<<"\t"<<ob.name<<endl;
		}
        }     
	
	public :
	
	void display()
	{
		greet();
		
		greet("Namaste");
		
		greet("Hello",10);
	}
};

int main()
{

	TakingInterface tob;
	
	tob.display();

}
