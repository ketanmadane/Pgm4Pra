/*	Techno-Comp Academy,Old Sangvi,Pune.
		BCS/BCA/MCS/MCA
	Sachin Dhane : 9028282629
	This demo explains main function can also be declared as friend fucntion some class
*/

#include<iostream>


using namespace std;

class A
{
	int i;

	friend int main(void);	
};
int main(void)
{
	A ob;
	cout<<"Enter value of i=";
	cin>>ob.i;

	cout<<"Value of i="<<ob.i<<endl;


}
