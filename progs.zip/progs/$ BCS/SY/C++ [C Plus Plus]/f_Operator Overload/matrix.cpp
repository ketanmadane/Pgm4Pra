#include<iostream>

using namespace std;

class Matrix
{
	int **p,m,n;

	public :
	Matrix(int x=5,int y=5)
	{
		m=x;
		n=y;
		p=new int* [m];
		
		for(int i=0;i<m;i++)
			p[i]=new int[n];
	}
	~Matrix()
	{
		for(int i=0;i<m;i++)
			delete p[i];
		delete p;
	}

	void accept()
	{
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<n;j++)
			{
				cout<<"Enter Data :";
				cin>>p[i][j];
			}
		}
	}	

	void display()
        {
                for(int i=0;i<m;i++)
                {
                        for(int j=0;j<n;j++)
                        {
                                cout<<p[i][j]<<" ";
                        }
			cout<<endl;
			
                }
        } 


	
	

};

int main()
{
	Matrix ob(2,3);
	ob.accept();
	ob.display();	

}
