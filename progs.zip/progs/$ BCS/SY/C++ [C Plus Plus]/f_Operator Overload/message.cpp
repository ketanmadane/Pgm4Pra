#include<iostream>
#include<string.h>

using namespace std;

class Message
{
	char *s;
	int length;

	public :
	Message(int sz=10)
        {
                s=new char[sz];
                length=sz;
        }
        Message(char *str)
        {
                length=strlen(str);
                s=new char [length];
                strcpy(s,str);
        }
        Message(Message &t)
        {
                length=t.length;
                s=new char[length];
                strcpy(s,t.s);
        }

	void display()
        {
                cout<<s<<endl;
        }



        Message operator +(Message &ob2)
        {
                Message temp(length+ob2.length);
                strcpy(temp.s,s);
                strcat(temp.s,ob2.s);
                return temp;
        }

	void operator = (Message &ob2)
	{
		length=ob2.length;
		s=new char[length];
		strcpy(s,ob2.s);	
	//	return *this;
	}

	char operator [](int index)
	{
		if(index>length)
			return '\0';
		else
		{
			return s[index];
		}
	}

};

int main()
{
	Message ob1("India"),ob2("Australia"),ob3;

	 cout<<"String of ob1 :";
        ob1.display();

        cout<<"String of ob2 :";
        ob2.display();

	cout<<"Concatenation of ob1 & ob2 = ";
	(ob1+ob2).display();
	//ob3.display();


	cout<<"Contents of ob3 after copying ob1 =";
	ob3=ob1;
	ob3.display();

	int index;
	cout<<"Enter index to see character in ob1 =";
	cin>>index;

	char ch=ob1[index];
	if(ch=='\0')
	{
		cout<<"Invalid index !!!"<<endl;
	}
	else
	{
		cout<<"Character at index "<<index<<"  ="<<ch<<endl;
	}
}
