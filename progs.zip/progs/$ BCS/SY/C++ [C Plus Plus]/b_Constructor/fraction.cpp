/*
	SETA : 1
	Define a class Fraction having integer data member numerator and denominator.
	Define parameterized and default constructor(default values 0 and 1).
	Parameterized constructor should store the fraction in reduced form after dividing both numerator and denominator by gcd.
	Write a private member fucntion to compute gcd of two numbers;

	write 4 member functions for addition, subtraction, multiplication and division of fraction objects.
	Each function will have two fraction objects as arguments. 
	
	write a main fucntion to illustrate the use of the class.
*/
#include<iostream>
using namespace std;

class Fraction
{
	int num,den;
	
	int gcd(int n,int d)
	{
		while(n!=d)
		{
			if(n>d)
				n=n-d;

			else
				d=d-n;
		}
		return n;
	}

	public :
	Fraction()
	{	
		num=0;
		den=1;
	}
	Fraction(int n,int d)
	{
		num=n;
		den=d;
		
		int ans=gcd(num,den);
		num=num/ans;	//reducing numerator
		den=den/ans;	//reducing denomenator
	}
	
	Fraction add(Fraction & tob)
	{
		Fraction t;
		t.num=(num*tob.den)+(tob.num*den);
		t.den=den*tob.den;
		
		int ans=gcd(t.num,t.den);
		t.num=t.num/ans;
		t.den=t.den/ans;
		
		return t;
	}	

	 Fraction sub(Fraction & tob)
        {
                Fraction t;
                t.num=(num*tob.den)-(tob.num*den);
                t.den=den*tob.den;
       		if(t.num!=0)
		{ 
                	int ans=gcd(t.num,t.den);
                	t.num=t.num/ans;
                	t.den=t.den/ans;
		}
                return t;
        }

	 Fraction mult(Fraction & tob)
        {
                Fraction t;
                t.num=num*tob.num;
                t.den=den*tob.den;
        
                int ans=gcd(t.num,t.den);
                t.num=t.num/ans;
                t.den=t.den/ans;

                return t;
        }

	 Fraction div(Fraction & tob)
        {
                Fraction t;
                t.num=num*tob.den;
                t.den=den*tob.num;
        
                int ans=gcd(t.num,t.den);
                t.num=t.num/ans;
                t.den=t.den/ans;

                return t;
        }

	void display()
	{
		cout<<num<<"/"<<den<<endl;
	}	

};

int main()
{

	Fraction ob1(1,4),ob2(2,8),ob3;

	cout<<"First Object:";
	ob1.display();
	
	cout<<"Second Object :";
	ob2.display();

	ob3=ob1.add(ob2);
	cout<<"Sum:";
	ob3.display();

	ob3=ob1.sub(ob2);
	cout<<"Sub:";
	ob3.display();

	ob3=ob1.mult(ob2);
	cout<<"Mult:";
	ob3.display();
	
	ob3=ob1.div(ob2);
	cout<<"Div:";
	ob3.display();
	
	

}
