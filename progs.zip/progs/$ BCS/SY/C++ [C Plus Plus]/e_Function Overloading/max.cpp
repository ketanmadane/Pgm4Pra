#include<iostream>

using namespace std;

class MaxData
{

	public:
	int maximum(int n1,int n2)
	{
		if(n1>=n2)
			return n1;
		else
			return n2;
	}
	
	int maximum(int *p,int n)
	{
		int max=p[0];
		
		for(int i=1;i<n;i++)
		{
			if(p[i]>max)
				max=p[i];
		}
		return max;
	}
};


int main()
{
	int n1,n2,max;
	MaxData ob;

	cout<<"Enter num1:";
	cin>>n1;
	cout<<"Enter Num2:";
	cin>>n2;
	
	max=ob.maximum(n1,n2);
	cout<<"Maximum= "<<max<<" Between "<<n1<<" and "<<n2<<endl;

	int n,*p;
	cout<<"How many numbers you want to accept into the array:";
	cin>>n;

	p=new int[n];
	
	for(int i=0;i<n;i++)
	{
		cout<<"Enter Data:";
		cin>>p[i];
	}
	
	max=ob.maximum(p,n);
	
	cout<<"maximum from an array: "<<max<<endl;
	
	delete []p;
}
