#include<iostream>

using namespace std;

class InvertData
{
	public:

	int invert(int num)
	{
		int rev=0;
		while(num>0)
		{
			rev=(rev*10)+(num%10);
			num=num/10;
		}
		return rev;	
	}
	
	char * invert(char *p)
	{
		int i,j;
		for(j=0;p[j]!='\0';j++);
		
		j--;
		for(i=0;i<j;i++,j--)
		{
			char temp=p[i];
			p[i]=p[j];
			p[j]=temp;
		}
		return p;
	}
	
	void invert(int *p,int n)
	{
		int temp,i,j;
		
		for(i=0,j=n-1;i<j;i++,j--)
		{
			temp=p[i];
			p[i]=p[j];
			p[j]=temp;
		}
	}
};

int main()
{
	InvertData ob;
	int rev,num;
	char str[80];
	
	cout<<"Enter Num:";
	cin>>num;
	rev=ob.invert(num);
	
	cout<<"Reverse of given num:  "<<rev<<endl;	

	cout<<"Enter String:";
	cin>>str;
	char *s=ob.invert((char *)str);	
	cout<<"Reverse of string : "<<s<<endl;

	int n,*p;
        cout<<"How many numbers you want to accept into the array:";
        cin>>n;

        p=new int[n];

        for(int i=0;i<n;i++)
        {
                cout<<"Enter Data:";
                cin>>p[i];
        }

        ob.invert(p,n);

        cout<<"REverse of an array: ";
	for(int i=0;i<n;i++)
	{
		cout<<p[i]<<"  ";
	}
	
	delete []p;
	
}
