#include<iostream>

using namespace std;

class PrintData
{
	public:
	
	void print(int num)
	{
		cout<<"Data:"<<num<<endl;
	}
	void print(int n1, int n2)
	{
		cout<<"Data:["<<n1<<","<<n2<<"]"<<endl;
	}
	void print(const char *p)
	{
		cout<<"Data :\""<<p<<"\""<<endl;
	}

};

int main()
{
	PrintData ob;
	ob.print(11);
	ob.print(11,12);
	ob.print("Hello");
}
