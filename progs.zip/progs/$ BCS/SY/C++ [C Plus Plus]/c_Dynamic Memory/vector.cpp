#include<iostream>

using namespace std;

class Vector
{
	int *v;
	int maxsize;
	int size;
	
	public :
	Vector()
	{
		v=new int[10];
		maxsize=10;
		size=0;
	}
	Vector(int n)
	{
		v=new int[n];
		maxsize=n;
		size=0;
	}
	
	Vector(Vector &t)
	{
		v=new int[t.maxsize];
		maxsize=t.maxsize;
		size=t.size;
	
		for(int i=0;i<maxsize;i++)
		{
			v[i]=t.v[i];
		}
	}
	~Vector()
	{
		delete []v;
	}
	void display()
	{
		for(int i=0;i<size;i++)
		{
			cout<<v[i]<<endl;
		}
	}
	void set(int data)
	{
		int i,j;
		if(size==maxsize)
		{
			cout<<"Can't add element: Vector is full"<<endl;	
			return;
		}
		for(i=0;i<size;i++)
		{
			if(data < v[i])		
				break;
		}
		
		for(j=size;j!=i;j--)
		{
			v[j]=v[j-1];
		}
		v[i]=data;
		size++;
	}
	
	void vunion(Vector &t)
	{
	
		Vector temp(maxsize+t.maxsize);
		int i,j;
		for(i=0;i<size;i++)
		{
			temp.set(v[i]);
		}
		for(j=0;j<t.size;j++)
		{
			temp.set(t.v[j]);
		}
		
		cout<<"Union:";
		temp.display();
	}

	void vintersection(Vector &t)
	{
		Vector temp(maxsize);
		
		int i,j,data;
		
		for(i=0;i<size;i++)
		{
			data=v[i];
			for(j=0;j<t.size;j++)
			{
				if(data==t.v[j])
				{
					temp.set(data);
					break;
				}	
			}
		}
		cout<<"InterSection:";
		temp.display();
	}
};

int main()
{
	
	int n;

	cout<<"How many elements in first vector=";
	cin>>n;
	Vector ob1(n);
	for(int i=0;i<n;i++)
	{
		int data;
		cout<<"Enter data:";
		cin>>data;
		ob1.set(data);
	}
	
	cout<<"How many elements in Second vector=";
        cin>>n;
        Vector ob2(n);
        for(int i=0;i<n;i++)
        {
                int data;
                cout<<"Enter data:";
                cin>>data;
                ob2.set(data);
        }

	cout<<"FIRST VECTOR:"<<endl;
	ob1.display();
	
	cout<<"SECOND VECTOR:"<<endl;
	ob2.display();

	ob1.vunion(ob2);
	ob1.vintersection(ob2);
	
	return 0;
}
