#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<string.h>

using namespace std;
class City
{
    char name[10];
    int code;
    public:

    void save(char v1[],char v2[])
    {
	strcpy(name,v1);
	code=atoi(v2);
    }
    void display()
    {
	cout<<name<<"\t"<<code<<endl;
    }

};
int main()
{
    ifstream inf;
    char val1[10],val2[10];
    City ob[100];
    int i,n;

    inf.open("city.txt",ios::in);
    i=0;
    while(inf)
    {
	inf>>val1;	//reading city name from file
	inf>>val2;	//reading code from file
	if(inf)
	{   ob[i].save(val1,val2);
	    i++;
	}
    }
    n=i;    //tells u no. of records in your file
    
    cout<<"City\tCode"<<endl;
    for(i=0;i<n;i++)
    {
	ob[i].display();
    }
}
