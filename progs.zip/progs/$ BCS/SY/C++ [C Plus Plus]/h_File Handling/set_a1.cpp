#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;

class File 
{
    char fname[10];
    int ccnt,wcnt,lcnt;

    public:
    
    File(const char fn[]=NULL)
    {
	strcpy(fname,fn);   //copying sent name to member

	ifstream inf;
	inf.open(fname,ios::in);
	if(!inf)
	{
	    ofstream fout(fname);
	    ccnt=0;
	    wcnt=0;
	    lcnt=0;
	    fout.close();
	}
	else
	{
	    ccnt=0;
	    wcnt=0;
	    lcnt=0;
	    cout<<"File is present "<<endl;
	    char ch;
	    while((ch=inf.get())!=EOF)
	    {
		ccnt++;

		if(ch==' ' || ch=='\t')
		    wcnt++;
		else if(ch=='\n')
		{
		    lcnt++;
		    wcnt++;
		}
	    }//while
	 
	       
	}//else
    }//cnstr

    int getCharCnt()
    {
	return ccnt;
    }
    
    int getWordCnt()
    {
	return wcnt;
    }
    int getLineCnt()
    {
	return lcnt;
    }

    void occurance( const char word[])
    {
	
	    int ocnt=0;
	    ifstream inf;
	    inf.open(fname,ios::in);
    

	    char line[80];
	    while(inf)
	    {
		    inf.getline(line,sizeof(line),'\n');
		    char *p=line;
		    while(p)
		    {
			if(p=strstr(p,word))
			{
				ocnt++;
				p++;
			}
		    }//while
		
	    }

	inf.close();	    
	cout<<"No. of times "<<word<<" occurs="<<ocnt<<endl;

    }
    void countBlankLines()
    {
	ifstream inf;
	inf.open(fname,ios::in);
	char line[80];
	int cnt=0;

	while(inf)
	{
	    inf.getline(line,sizeof(line),'\n');
	    if(inf)
	    {
		if(strlen(line)==0)
		cnt++;
	    }
	}
	inf.close();

	cout<<"No. of blank lines : "<<cnt<<endl;
    }
};

int main()
{
    File ob("a.txt");

    cout<<"No. of chars :"<<ob.getCharCnt()<<endl;
    cout<<"No. of Words :"<<ob.getWordCnt()<<endl;
    cout<<"No. Of Lines :"<<ob.getLineCnt()<<endl;


    char word[10];
    cout<<"Enter word that you want to search in file :";
    cin>>word;

    ob.occurance(word);

    ob.countBlankLines();
    return 0;
}
