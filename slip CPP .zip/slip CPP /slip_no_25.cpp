#include<iostream>

using namespace std;

class report

{

int adno;
char name[30];
float m1,m2,m3,m4,m5,avg;

void getavg()
{
	avg=((m1+m2+m3+m4+m5)/5);
}
public:	void readinfo()
	{
		cout<<"\nAccept Admission number :- ";
		cin>>adno;
		cout<<"\nAccept name :- ";
		cin>>name;
		cout<<"\nAccept 5 subjects marks :- ";
		cin>>m1>>m2>>m3>>m4>>m5;
		getavg();
	}
	
	void dispinfo()
	{
		cout<<"\nAdmission number :-		"<<adno<<"\nName :-				"<<name;
		cout<<"\n\t\t\t\t( "<<m1<<"+"<<m2<<"+"<<m3<<"+"<<m4<<"+"<<m5<<" ) / 5"<<"\nAverage is :-			"<<avg<<endl;
	}
};
int main()
{
report r;
r.readinfo();
r.dispinfo();
return 0;
}
