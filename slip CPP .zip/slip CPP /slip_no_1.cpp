#include<iostream>

using namespace std;

class fraction
{
	private:	int num,den;
	public:	fraction()
				{
					num=0;
					den=0;
				}
				fraction(int n,int d)
				{
					num=n;
					den=d;
				}
				void display()
				{
					cout<<num<<"/"<<den;
				}
				friend ostream &operator << (ostream &output,fraction &z)
				{
					output<<z.num<<"/"<<z.den;
					return output;
				}
				friend istream &operator >> (istream &input,fraction &z)
				{
					input>>z.num>>z.den;
					return input;
				}

};

int main()
{

	fraction f(10,20);
	cout<<"fraction with default value\n";
	cout<<f;
	cout<<"Enter value : ";
	cin>>f;
	cout<<"You entered fraction was : ";
	cout<<f;
	cout<<"\n";
}
