#include<iostream>
using namespace std;
class complex
{
private:int real,img,a,b,i;
public: complex()
	{}
	complex(int x, int y)

	{
	real=x;
	img=y;
	}
void display()
	{
	cout<<"\n"<<real<<"+"<<img<<"i";
	}
friend complex operator +(complex z1,complex z2)
	{
	complex t;
	t.real=z1.real+z2.real;
	t.img=z1.img+z2.img;
	return t;
	}
friend complex operator -(complex z1,complex z2)
	{
	complex t;
	t.real=z1.real-z2.real;
	t.img=z1.img-z2.img;
	return t;
	}
friend complex operator *(complex z1,complex z2)
	{
	complex t;
	t.real=z1.real*z2.real;
	t.img=z1.img*z2.img;
	return t;
	}

};
int main()
{
int a,b;
cout<<"Enter complex number";
cin>>a>>b;
complex c1(a,b);
//c1.display();

cout<<"Enter complex number";
cin>>a>>b;
complex c2(a,b),c3,c4,c5;
//c2.display();
c3=c1+c2;
c3.display();

c4=c1-c2;
c4.display();

c5=c1*c2;
c5.display();
return 0;
}
