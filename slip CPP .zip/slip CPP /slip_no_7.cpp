#include<iostream>

using namespace std;

class airport
{
public:	struct airline_reservation
	{
		int fno;
	char origin[20],desti[20];
	float dtime,atime;
	}ar1;
	void airaccept()
	{
		cout<<"\nAccept\n";
		cout<<"\nFlight number = ";
		cin>>ar1.fno;
		cout<<"\nOriginating airport code(3 characters) = ";
		cin>>ar1.origin;
		cout<<"\nDestination airport code(3 characters) = ";
		cin>>ar1.desti;
		cout<<"\nDeparture time = ";
		cin>>ar1.dtime;
		cout<<"\nArrival time = ";
		cin>>ar1.atime;
	}

	void airdisplay()
	{
		cout<<"\nDisplay\n";
		cout<<"\nFlight number = "<<ar1.fno<<"\nOriginating airport code = "<<ar1.origin<<"\nDestination airport code = "<<ar1.desti<<"\nDept time = "<<ar1.dtime<<"\nArrival time = "<<ar1.atime<<endl;
	}
};
int main()
{
airport a1[5];
int i,n;
cout<<"Accept how many airports you want : ";
cin>>n;
for(i=0;i<n;i++)
{
	a1[i].airaccept();
}
for(i=0;i<n;i++)
{
	a1[i].airdisplay();
}
}
