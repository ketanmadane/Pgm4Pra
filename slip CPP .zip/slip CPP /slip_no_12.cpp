#include<iostream>
using namespace std;

class person
{
int phno;
char addr[40],name[40];
public:	void paccept()
	{
		cout<<"\nIn person\nEnter name = ";
		cin>>name;
		cout<<"\nEnter address = ";
		cin>>addr;
		cout<<"\nEntr phone_number = ";
		cin>>phno;
	}
	void pdisplay()
	{
		cout<<"\nName = "<<name<<"\nAddress = "<<addr<<"\nPhone_number = "<<phno<<endl;
	}
};
class employee:public person
{
int e_no;
char ename[40];
public:	void eaccept()
	{
		paccept();
		cout<<"\nIn Employee\nEnter employee number = ";
		cin>>e_no;
		cout<<"\nEnter employee name = ";	
		cin>>ename;
	}
	void edisplay()
	{
		pdisplay();
		cout<<"\nEmployee number = "<<e_no<<"\nEmployee name = "<<ename<<endl;
	}
};
class manager:public employee
{
char desig[40],dept[40];
float bsal;
public:	void maccept()
	{
		eaccept();
		cout<<"\nIn Manager\nEnter Designation = ";
		cin>>desig;
		cout<<"\nEnter Department = ";
		cin>>dept;
		cout<<"\nEnter Basic salary = ";
		cin>>bsal;
	}
/*	void highestsal(manager m[i],no)
	{
		int i;
		for(i=0;i<no;i++)	
			if()
	}
*/	void mdisplay()
	{
		edisplay();
		cout<<"\nDesignation = "<<desig<<"\nDepartment = "<<dept<<"\nBasic salary = "<<bsal<<endl;
	}
};
int main()
{
	int no;
	manager m[20],m1;
	cout<<"Enter how many records you want :: ";
	cin>>no;
	for(int i=0;i<no;i++)
		m[i].maccept();
//	m1.highestsal(m,no);
	for(int i=0;i<no;i++)
		m[i].mdisplay();
	return 0;
}
