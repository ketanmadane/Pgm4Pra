#include<iostream>

using namespace std;

int main()
{
int n;
cout<<"enter the number ";
cin>>n;
try{
	if(n<0)
		throw "no is not positive";
 	else
		throw "no is positive";
  }
catch(const char *msg)
{
cerr<<msg<<endl;
}
return 0;
}
