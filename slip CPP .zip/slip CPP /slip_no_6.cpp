#include<iostream>
#include<string.h>
#include<fstream>
using namespace std;

int const MAXSIZE = 20;

class cfile
{
char fn[MAXSIZE];
fstream fp;

public:cfile()
		{
			strcpy(fn,"one.txt");
		}
		void operator -()
		{
			char ch;
			fp.open(fn,ios::in|ios::out);
			while(fp)
			{
				ch=fp.get();
				if(islower(ch))
					ch=toupper(ch);
				else if(isupper(ch))
					ch=tolower(ch);
				fp.seekp(-1,ios::cur);
				fp<<ch;
				fp.seekg(0,ios::cur);
			}
		fp.close();
		}
		void display()
		{
			char ch;
			fp.open(fn,ios::in);
			while(fp)
			{
				fp.get(ch);
				cout<<ch;
			}
		fp.close();
	}
};

int main()
{
	cfile f;
	cout<<"Original file : ";
	f.display();	
	-f;
	cout<<"Changing file :";
	f.display();
}
