#include<iostream>

using namespace std;

class student
{
int rno;
char classs[10],name[20];
public:	void saccept()
	{
		cout<<"Accept number, class and name : ";
		cin>>rno>>classs>>name;
	}
	void sdisplay()
	{
		cout<<"\nRoll number = "<<rno<<"\nClass = "<<classs<<"\nName = "<<name<<"\n\n";
	}
};
class marks
{
int i;
public:	int mark[4];
	void maccept()
	{
		for(i=0;i<3;i++)
		{
			cout<<"Accept 3 subject marks :";
			cin>>mark[i];
		}
	}
	void mdisplay()
	{
		for(i=0;i<3;i++)
		{
			cout<<" "<<mark[i];
		}
	}
};
class Result:public student,public marks
{
float per,total;
int i;
char grade;
public:	Result()
	{
		for(i=0;i<3;i++)
		{
			total=total+mark[i];
			per=total/3;
			if(per>=75)
				grade='O';
			else if(per>=60 && per<75)
				grade='A';
			else if(per>=50 && per<60)
				grade='B';
			else if(per>=40 && per<50)
				grade='C';
			else    
				grade='F';
		}
	}
};
int main()
{
int c,i,n;
Result r1[10],e;
do
{
	cout<<"\n1.Accept\n2.Display\n3.Exit\nEnter your Choice : ";
	cin>>c;
	switch(c)
	{
		case 1:	cout<<"Enter how many records you want : ";
			cin>>n;
			for(i=0;i<n;i++)
		{
			r1[i].saccept();
			r1[i].maccept();
		}
		break;
	case 2:	for(i=0;i<n;i++)
		{
			r1[i].sdisplay();
			r1[i].mdisplay();
		}
		break;
	case 3:	exit(0);
		break;
	}
}while(c!=3);
return 0;
}
