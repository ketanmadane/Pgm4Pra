#include<iostream>

using namespace std;

class competition
{
	int eventno,score,score1;
	char desc[30],quali;
public:	competition()
	{
		eventno=101;
		strcpy(desc,"state level");
		score=50;
		quali='N';
	}
	void input()
	{
		cout<<"Accept Event number & Description :\n";
		cin>>eventno>>desc;
		cout<<"Accept Score : "<<endl;
		cin>>score;
		if(score>39)
			quali='Y';
		else
			quali='N';
	}
	void show()
	{
		cout<<"\nEvent number = "<<eventno<<"\nDescription = "<<desc<<"\nScore = "<<score1<<"\nQualified = "<<quali<<endl;
	}
};
int main()
{
competition c1,c2;
c1.show();
c2.input();
c2.show();
return 0;
}
